import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, projectContext } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // Build system prompt with project context
    let systemPrompt = `You are an expert AI music assistant helping users create and refine their musical projects. You have deep knowledge of:

1. Music theory and composition
2. Instrumentation and arrangement
3. Lyrics writing and song structure
4. Music production and mixing
5. Genre-specific conventions and techniques

Your role is to provide helpful, actionable advice that enhances the user's creative vision. Be encouraging, specific, and practical in your suggestions.`;

    if (projectContext) {
      systemPrompt += `\n\nCurrent project context:`;
      if (projectContext.mood) systemPrompt += `\n- Mood: ${projectContext.mood}`;
      if (projectContext.genre) systemPrompt += `\n- Genre: ${projectContext.genre}`;
      if (projectContext.tempo) systemPrompt += `\n- Tempo: ${projectContext.tempo} BPM`;
      if (projectContext.instruments?.length > 0) {
        systemPrompt += `\n- Instruments: ${projectContext.instruments.join(", ")}`;
      }
      if (projectContext.hasLyrics) systemPrompt += `\n- The project includes lyrics`;
      if (projectContext.hasAudio) systemPrompt += `\n- The project includes audio input`;
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages
        ],
        stream: true,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits depleted. Please add credits to your workspace." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(
        JSON.stringify({ error: "AI gateway error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Return the streaming response directly
    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });

  } catch (error) {
    console.error("Error in ai-chat:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "Unknown error occurred" 
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
