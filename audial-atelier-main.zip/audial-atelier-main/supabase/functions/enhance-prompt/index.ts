import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { prompt, mood, genre, tempo, instruments, vocalsType } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = `You are an expert music producer and prompt engineer specializing in AI music generation. Your task is to enhance and refine music generation prompts to produce the best results. Focus on:

1. Musical structure (verse, chorus, bridge, etc.)
2. Instrumentation and sound design
3. Mood, emotion, and atmosphere
4. Technical specifications (tempo, key, time signature)
5. Production style and mixing suggestions

Provide a comprehensive, well-structured prompt that will guide the AI music generator effectively.`;

    const userPrompt = `Original prompt: "${prompt}"

Additional details:
- Mood: ${mood || "Not specified"}
- Genre: ${genre || "Not specified"}
- Tempo: ${tempo ? `${tempo} BPM` : "Not specified"}
- Instruments: ${instruments?.length > 0 ? instruments.join(", ") : "Not specified"}
- Vocals Type: ${vocalsType || "Not specified"}

Please enhance this prompt to create a detailed, professional music generation prompt. Structure it clearly with sections for style, instrumentation, mood, structure, and any technical details.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits depleted. Please add credits to your workspace." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const enhancedPrompt = data.choices?.[0]?.message?.content;

    if (!enhancedPrompt) {
      throw new Error("No response from AI");
    }

    return new Response(
      JSON.stringify({ 
        enhancedPrompt,
        tokenUsage: data.usage 
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error in enhance-prompt:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "Unknown error occurred" 
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
