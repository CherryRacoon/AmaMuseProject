import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { theme, mood, genre, style, existingLyrics } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = `You are a professional songwriter and lyricist. Your task is to create engaging, emotionally resonant lyrics that match the requested theme, mood, and genre. Consider:

1. Song structure (verses, chorus, bridge, pre-chorus if needed)
2. Rhyme schemes and meter
3. Imagery and metaphors
4. Emotional arc and storytelling
5. Singability and memorable hooks

Format the lyrics clearly with [Verse 1], [Chorus], [Bridge], etc. tags.`;

    let userPrompt = `Create lyrics for a song with the following specifications:

Theme: ${theme || "Love and relationships"}
Mood: ${mood || "Emotional"}
Genre: ${genre || "Pop"}
Style: ${style || "Contemporary"}`;

    if (existingLyrics) {
      userPrompt += `\n\nExisting lyrics to enhance or continue:\n${existingLyrics}`;
    }

    userPrompt += `\n\nProvide complete, structured lyrics with clear verse/chorus labels. Make them original, emotionally compelling, and appropriate for the specified genre.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.9, // Higher temperature for creative lyrics
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits depleted. Please add credits to your workspace." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const lyrics = data.choices?.[0]?.message?.content;

    if (!lyrics) {
      throw new Error("No response from AI");
    }

    return new Response(
      JSON.stringify({ 
        lyrics,
        tokenUsage: data.usage 
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error in generate-lyrics:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "Unknown error occurred" 
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
