
import { z } from 'zod';

// API Provider-Specific Schemas

export const CyaniteFeaturesSchema = z.object({
  moods: z.array(z.string()),
  genres: z.array(z.string()),
  instruments: z.array(z.string()),
  bpm: z.number(),
  moodOverTime: z.array(z.object({ time: z.number(), mood: z.string() })),
  movement: z.array(z.object({ time: z.number(), value: z.number() })),
});
export type CyaniteFeatures = z.infer<typeof CyaniteFeaturesSchema>;

export const SoundStatFeaturesSchema = z.object({
  tempo: z.number(),
  beat_confidence: z.number(),
  downbeats: z.array(z.number()),
  dynamic_range: z.number(),
  loudness_integrated: z.number(),
  spectral_balance: z.object({
    bass: z.number(),
    mid: z.number(),
    treble: z.number(),
  }),
  section_boundaries: z.array(z.number()),
});
export type SoundStatFeatures = z.infer<typeof SoundStatFeaturesSchema>;

export const SpotifyFeaturesSchema = z.object({
  danceability: z.number(),
  energy: z.number(),
  valence: z.number(),
  acousticness: z.number(),
  instrumentalness: z.number(),
  tempo: z.number(),
  loudness: z.number(),
});
export type SpotifyFeatures = z.infer<typeof SpotifyFeaturesSchema>;

export const ProviderFeaturesSchema = z.object({
  cyanite: CyaniteFeaturesSchema.optional(),
  soundstat: SoundStatFeaturesSchema.optional(),
  spotify: SpotifyFeaturesSchema.optional(),
});
export type ProviderFeatures = z.infer<typeof ProviderFeaturesSchema>;

// RateReport Schema

const ScoreDimensionSchema = z.object({
  score: z.number().min(0).max(10),
  explanation: z.string(),
  tips: z.array(z.string()),
});

export const RateReportSchema = z.object({
  structure: ScoreDimensionSchema,
  appeal: ScoreDimensionSchema,
  novelty: ScoreDimensionSchema,
  potential: ScoreDimensionSchema,
  ameiScore: z.number().min(0).max(10),
  conclusion: z.string(),
  threshold: z.enum(['Publish-ready', 'Good but polish hooks', 'OK but not memorable', 'Rework structure/mix']),
});

export type RateReport = z.infer<typeof RateReportSchema>;
export type ScoreDimension = z.infer<typeof ScoreDimensionSchema>;
