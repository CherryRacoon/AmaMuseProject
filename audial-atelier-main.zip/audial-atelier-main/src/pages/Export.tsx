import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useProjectStore, Track } from "@/stores/useProjectStore";
import { useNavigationStore } from "@/stores/useNavigationStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Share2,
  Download,
  Music,
  FileText,
  Archive,
  Instagram,
  Youtube,
  Cloud,
  Music2,
  CheckCircle,
  AlertCircle,
  Clock,
  Settings,
  Eye,
  Upload
} from "lucide-react";
import { AudioExportPanel } from "@/components/export/AudioExportPanel";
import { MetadataEditor } from "@/components/export/MetadataEditor";
import { SheetMusicExportPanel } from "@/components/export/SheetMusicExportPanel";
import { ProjectArchivePanel } from "@/components/export/ProjectArchivePanel";
import { SocialSharingPanel } from "@/components/export/SocialSharingPanel";
import { ExportPreview } from "@/components/export/ExportPreview";
import { ExportProgress } from "@/components/export/ExportProgress";

interface ExportData {
  format?: string;
  quality?: string;
  type?: string;
  projectId: string;
  projectName: string;
  fileName: string;
  tracks?: Track[];
  timestamp: string;
  platform?: string;
  shareData?: Record<string, unknown>;
  [key: string]: unknown;
}

interface PreviewData {
  projectName: string;
  estimatedSize?: string;
  trackCount?: number;
  duration?: string;
  sampleTracks?: Track[];
  format?: string;
  quality?: string;
  type?: string;
  [key: string]: unknown;
}

type ExportMode = "audio" | "sheet-music" | "archive" | "social";

interface ExportJob {
  id: string;
  type: ExportMode;
  status: "pending" | "processing" | "completed" | "failed";
  progress: number;
  fileName: string;
  fileSize?: string;
  error?: string;
  startTime: Date;
  endTime?: Date;
}

const Export = () => {
  const navigate = useNavigate();
  const { currentProject } = useProjectStore();
  const { setWorkflowPhase } = useNavigationStore();
  const { addLog } = useDebugLog();

  const [exportMode, setExportMode] = useState<ExportMode>("audio");
  const [exportJobs, setExportJobs] = useState<ExportJob[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [previewData, setPreviewData] = useState<PreviewData | null>(null);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    setWorkflowPhase("complete");

    // Allow access to all pages - removed redirect logic
    // if (!currentProject || !currentProject.selectedVersionId) {
    //   navigate("/edit");
    // }

    addLog("INFO", "System", "Page Load", "Export page loaded", {
      projectId: currentProject?.id,
      hasSelectedVersion: !!currentProject?.selectedVersionId
    });
  }, [currentProject, setWorkflowPhase, addLog]);

  const handleExportStart = useCallback(async (exportData: ExportData) => {
    setIsExporting(true);

    const jobId = `export-${Date.now()}`;
    const newJob: ExportJob = {
      id: jobId,
      type: exportMode,
      status: "pending",
      progress: 0,
      fileName: exportData.fileName || `export-${exportMode}-${Date.now()}`,
      startTime: new Date()
    };

    setExportJobs(prev => [...prev, newJob]);

    addLog("INFO", "System", "Export Started", `Started ${exportMode} export`, {
      projectId: currentProject?.id,
      jobId,
      exportData
    });

    // Simulate export process
    try {
      // Update to processing
      setExportJobs(prev => prev.map(job =>
        job.id === jobId ? { ...job, status: "processing" as const } : job
      ));

      // Simulate progress
      for (let progress = 0; progress <= 100; progress += 10) {
        await new Promise(resolve => setTimeout(resolve, 200));
        setExportJobs(prev => prev.map(job =>
          job.id === jobId ? { ...job, progress } : job
        ));
      }

      // Complete export
      const completedJob: ExportJob = {
        ...newJob,
        status: "completed",
        progress: 100,
        fileSize: `${Math.round(Math.random() * 50 + 10)}MB`,
        endTime: new Date()
      };

      setExportJobs(prev => prev.map(job =>
        job.id === jobId ? completedJob : job
      ));

      addLog("INFO", "System", "Export Completed", `Successfully exported ${exportMode}`, {
        projectId: currentProject?.id,
        jobId,
        fileName: completedJob.fileName,
        fileSize: completedJob.fileSize,
        duration: completedJob.endTime.getTime() - completedJob.startTime.getTime()
      });

    } catch (error) {
      const failedJob: ExportJob = {
        ...newJob,
        status: "failed",
        progress: 0,
        error: error instanceof Error ? error.message : "Unknown error",
        endTime: new Date()
      };

      setExportJobs(prev => prev.map(job =>
        job.id === jobId ? failedJob : job
      ));

      addLog("ERROR", "System", "Export Failed", `Failed to export ${exportMode}`, {
        projectId: currentProject?.id,
        jobId,
        error: failedJob.error
      });
    }

    setIsExporting(false);
  }, [exportMode, currentProject?.id, addLog]);

  const handlePreview = useCallback((data: PreviewData) => {
    setPreviewData(data);
    setShowPreview(true);

    addLog("INFO", "System", "Preview Opened", "Export preview opened", {
      projectId: currentProject?.id,
      previewType: exportMode
    });
  }, [exportMode, currentProject?.id, addLog]);

  const handleSocialShare = useCallback(async (platform: string, shareData: Record<string, unknown>) => {
    addLog("INFO", "System", "Social Share Started", `Sharing to ${platform}`, {
      projectId: currentProject?.id,
      platform,
      shareData
    });

    // Simulate social sharing
    setTimeout(() => {
      addLog("INFO", "System", "Social Share Completed", `Successfully shared to ${platform}`, {
        projectId: currentProject?.id,
        platform,
        postId: `post-${Date.now()}`
      });
    }, 2000);
  }, [currentProject?.id, addLog]);

  if (!currentProject) {
    return null;
  }

  const completedJobs = exportJobs.filter(job => job.status === "completed");
  const failedJobs = exportJobs.filter(job => job.status === "failed");

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card px-6 py-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
              <Share2 className="w-6 h-6 text-primary" />
              Export & Share
            </h1>
            <Badge variant="secondary">{currentProject.name}</Badge>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => navigate("/edit")}>
              ← Back to Edit
            </Button>
            <Button onClick={() => navigate("/")}>
              <Upload className="w-4 h-4 mr-2" />
              New Project
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 min-h-0">
        {/* Export Options */}
        <div className="flex-1 flex flex-col">
          <Tabs value={exportMode} onValueChange={(value) => setExportMode(value as ExportMode)} className="flex flex-col h-full">
            <div className="border-b border-border bg-card px-6 py-3 flex-shrink-0">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="audio" className="gap-2">
                  <Music className="w-4 h-4" />
                  Audio
                </TabsTrigger>
                <TabsTrigger value="sheet-music" className="gap-2">
                  <FileText className="w-4 h-4" />
                  Sheet Music
                </TabsTrigger>
                <TabsTrigger value="archive" className="gap-2">
                  <Archive className="w-4 h-4" />
                  Project
                </TabsTrigger>
                <TabsTrigger value="social" className="gap-2">
                  <Share2 className="w-4 h-4" />
                  Social
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="flex-1 overflow-auto">
              <TabsContent value="audio" className="m-0 h-full">
                <AudioExportPanel
                  project={currentProject}
                  onExport={handleExportStart}
                  onPreview={handlePreview}
                  isExporting={isExporting}
                />
              </TabsContent>

              <TabsContent value="sheet-music" className="m-0 h-full">
                <SheetMusicExportPanel
                  project={currentProject}
                  onExport={handleExportStart}
                  onPreview={handlePreview}
                  isExporting={isExporting}
                />
              </TabsContent>

              <TabsContent value="archive" className="m-0 h-full">
                <ProjectArchivePanel
                  project={currentProject}
                  onExport={handleExportStart}
                  onPreview={handlePreview}
                  isExporting={isExporting}
                />
              </TabsContent>

              <TabsContent value="social" className="m-0 h-full">
                <SocialSharingPanel
                  project={currentProject}
                  onShare={handleSocialShare}
                  onPreview={handlePreview}
                />
              </TabsContent>
            </div>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="w-80 border-l border-border bg-card flex flex-col flex-shrink-0">
          {/* Export History */}
          <div className="p-4 border-b border-border flex-shrink-0">
            <h3 className="font-semibold text-sm mb-3">Export History</h3>
            <ScrollArea className="h-48">
              <div className="space-y-2">
                {exportJobs.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No exports yet
                  </p>
                ) : (
                  exportJobs.slice(-5).reverse().map(job => (
                    <div key={job.id} className="flex items-center gap-2 p-2 rounded border">
                      {job.status === "completed" && <CheckCircle className="w-4 h-4 text-green-500" />}
                      {job.status === "failed" && <AlertCircle className="w-4 h-4 text-red-500" />}
                      {job.status === "processing" && <Clock className="w-4 h-4 text-blue-500" />}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{job.fileName}</p>
                        <p className="text-xs text-muted-foreground">
                          {job.status} • {job.fileSize || `${job.progress}%`}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </div>

          {/* Statistics */}
          <div className="p-4 border-b border-border flex-shrink-0">
            <h3 className="font-semibold text-sm mb-3">Statistics</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 border border-border rounded-lg">
                <div className="text-lg font-semibold text-green-600">{completedJobs.length}</div>
                <div className="text-xs text-muted-foreground">Completed</div>
              </div>
              <div className="text-center p-3 border border-border rounded-lg">
                <div className="text-lg font-semibold text-red-600">{failedJobs.length}</div>
                <div className="text-xs text-muted-foreground">Failed</div>
              </div>
            </div>
          </div>

          {/* Metadata Editor */}
          <div className="flex-1 overflow-auto p-4">
            <MetadataEditor project={currentProject} />
          </div>
        </div>
      </div>

      {/* Export Preview Modal */}
      {showPreview && previewData && (
        <ExportPreview
          data={previewData}
          type={exportMode}
          onClose={() => setShowPreview(false)}
          onConfirm={() => {
            if (previewData) {
              const exportData: ExportData = {
                ...previewData,
                projectId: currentProject?.id || "",
                fileName: `${previewData.projectName}_${previewData.quality || 'full'}_${previewData.format || 'mp3'}`,
                timestamp: new Date().toISOString()
              };
              handleExportStart(exportData);
            }
            setShowPreview(false);
          }}
        />
      )}

      {/* Export Progress Overlay */}
      {isExporting && (
        <ExportProgress
          jobs={exportJobs.filter(job => job.status === "processing")}
          onCancel={() => setIsExporting(false)}
        />
      )}
    </div>
  );
};

export default Export;
