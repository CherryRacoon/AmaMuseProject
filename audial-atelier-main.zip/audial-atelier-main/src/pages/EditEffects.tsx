import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useProjectStore } from "@/stores/useProjectStore";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Sliders, Plus, GripVertical, Trash2, Power, Settings } from "lucide-react";
// You may want to import a Knob or custom slider component for rotary controls

const FX_TYPES = [
	{ type: "eq", label: "EQ" },
	{ type: "compressor", label: "Compressor" },
	{ type: "reverb", label: "Reverb" },
	{ type: "delay", label: "Delay" },
	{ type: "limiter", label: "Limiter" },
	{ type: "noisegate", label: "Noise Gate" },
	{ type: "pitch", label: "Pitch/Time" }
];

export default function EditEffects() {
	const navigate = useNavigate();
	const { currentProject, addEffectToTrack, removeEffectFromTrack, updateEffectParams, reorderEffects, toggleEffectBypass, setEffectWet } = useProjectStore();

	// Assume latest render/track is "full-mix" or similar
	const trackId = currentProject?.tracks.find(t => t.type === "full")?.id || currentProject?.tracks[0]?.id;
	const fxChain = currentProject?.effectChains?.[trackId] || [];

	// For drag-and-drop reorder (not implemented here, but you can use a library or custom logic)
	// const [draggedIdx, setDraggedIdx] = useState<number | null>(null);

	const handleAddEffect = (type: string) => {
		const id = `${type}-${Date.now()}`;
		addEffectToTrack(currentProject.id, trackId, {
			id,
			type,
			bypass: false,
			wet: 1,
			params: {}, // Set sensible defaults per effect type
			order: fxChain.length
		});
	};

	const handleRemoveEffect = (effectId: string) => {
		removeEffectFromTrack(currentProject.id, trackId, effectId);
	};

	const handleBypass = (effectId: string) => {
		toggleEffectBypass(currentProject.id, trackId, effectId);
	};

	const handleWetChange = (effectId: string, wet: number) => {
		setEffectWet(currentProject.id, trackId, effectId, wet);
	};

	const handleParamChange = (effectId: string, param: string, value: number) => {
		updateEffectParams(currentProject.id, trackId, effectId, { [param]: value });
	};

	// ...implement drag-and-drop reorder logic and call reorderEffects...

	if (!currentProject) return null;

	return (
		<div className="container mx-auto px-2 py-8">
			<div className="max-w-7xl mx-auto">
				{/* Header */}
				<div className="mb-8 flex items-center gap-4">
					<Button variant="ghost" onClick={() => navigate("/edit")}>
						<ArrowLeft className="w-4 h-4" />
						Back to Editor
					</Button>
					<h1 className="text-2xl font-bold flex items-center gap-2">
						<Sliders className="w-6 h-6 text-primary" />
						Effects Editor
					</h1>
					<Badge variant="secondary">{currentProject.name}</Badge>
				</div>

				{/* Responsive grid: 1col on mobile, 3col on md+ */}
				<div className="grid gap-6 md:grid-cols-[280px_1fr_1fr]">
					{/* Left: Track Selector */}
					<div className="min-w-0">
						<Card className="h-full flex flex-col">
							<CardHeader>
								<CardTitle>Track</CardTitle>
							</CardHeader>
							<CardContent>
								<div className="space-y-2">
									<Badge variant="default">Current Render</Badge>
									<div className="text-xs text-muted-foreground break-all">{trackId}</div>
								</div>
							</CardContent>
						</Card>
					</div>

					{/* Center: FX Chain */}
					<div className="min-w-0">
						<Card className="h-full flex flex-col overflow-hidden">
							<CardHeader>
								<CardTitle>FX Chain</CardTitle>
							</CardHeader>
							<CardContent className="flex flex-col gap-4 p-6 overflow-hidden">
								<div className="space-y-3 min-w-0">
									{fxChain.length === 0 && (
										<div className="text-muted-foreground text-sm">No effects yet. Add one below.</div>
									)}
									{fxChain.map((fx, idx) => (
										<div key={fx.id} className="flex items-center gap-2 border rounded-lg p-3 bg-muted/50 min-w-0">
											<GripVertical className="w-4 h-4 cursor-move opacity-50 shrink-0" />
											<Badge variant={fx.bypass ? "outline" : "secondary"}>{FX_TYPES.find(t => t.type === fx.type)?.label || fx.type}</Badge>
											<Button
												variant={fx.bypass ? "outline" : "ghost"}
												size="icon"
												aria-label="Bypass"
												onClick={() => handleBypass(fx.id)}
												className="shrink-0"
											>
												<Power className={`w-4 h-4 ${fx.bypass ? "text-muted-foreground" : "text-green-500"}`} />
											</Button>
											<div className="flex-1 min-w-0" />
											<Button
												variant="ghost"
												size="icon"
												aria-label="Remove"
												onClick={() => handleRemoveEffect(fx.id)}
												className="shrink-0"
											>
												<Trash2 className="w-4 h-4 text-destructive" />
											</Button>
										</div>
									))}
								</div>
								{/* Add FX toolbar: wraps, scrolls on small screens, never overflows */}
								<div className="overflow-x-auto no-scrollbar px-2 -mx-2">
									<div className="flex flex-wrap gap-3 items-center content-start max-w-full">
										{FX_TYPES.map(fx => (
											<Button
												key={fx.type}
												variant="outline"
												size="sm"
												onClick={() => handleAddEffect(fx.type)}
												className="shrink-0 max-w-full whitespace-nowrap"
											>
												<Plus className="w-3 h-3 mr-1" />
												{fx.label}
											</Button>
										))}
									</div>
								</div>
							</CardContent>
						</Card>
					</div>

					{/* Right: Parameters Panel */}
					<div className="min-w-0">
						<Card className="h-full flex flex-col overflow-hidden">
							<CardHeader>
								<CardTitle>Parameters</CardTitle>
							</CardHeader>
							<CardContent className="flex flex-col gap-4 p-6 overflow-hidden">
								{fxChain.length === 0 ? (
									<div className="text-muted-foreground text-sm">Select or add an effect to edit parameters.</div>
								) : (
									fxChain.map(fx => (
										<div key={fx.id} className="mb-6 min-w-0">
											<div className="flex items-center gap-2 mb-2">
												<Badge variant={fx.bypass ? "outline" : "secondary"}>{FX_TYPES.find(t => t.type === fx.type)?.label || fx.type}</Badge>
												<span className="text-xs text-muted-foreground">Wet/Dry</span>
												<input
													type="range"
													min={0}
													max={1}
													step={0.01}
													value={fx.wet}
													onChange={e => handleWetChange(fx.id, Number(e.target.value))}
													aria-label="Wet/Dry"
													className="mx-2"
												/>
												<span className="text-xs">{Math.round(fx.wet * 100)}%</span>
											</div>
											{/* Render parameter controls per effect type */}
											<div className="space-y-2">
												{/* Example: For EQ */}
												{fx.type === "eq" && (
													<>
														<div>
															<label className="text-xs">Low Gain</label>
															<input
																type="range"
																min={-12}
																max={12}
																step={0.1}
																value={fx.params.low || 0}
																onChange={e => handleParamChange(fx.id, "low", Number(e.target.value))}
																aria-label="Low Gain"
															/>
															<span className="text-xs ml-2">{fx.params.low || 0} dB</span>
														</div>
														<div>
															<label className="text-xs">Mid Gain</label>
															<input
																type="range"
																min={-12}
																max={12}
																step={0.1}
																value={fx.params.mid || 0}
																onChange={e => handleParamChange(fx.id, "mid", Number(e.target.value))}
																aria-label="Mid Gain"
															/>
															<span className="text-xs ml-2">{fx.params.mid || 0} dB</span>
														</div>
														<div>
															<label className="text-xs">High Gain</label>
															<input
																type="range"
																min={-12}
																max={12}
																step={0.1}
																value={fx.params.high || 0}
																onChange={e => handleParamChange(fx.id, "high", Number(e.target.value))}
																aria-label="High Gain"
															/>
															<span className="text-xs ml-2">{fx.params.high || 0} dB</span>
														</div>
													</>
												)}
												{/* Add similar parameter controls for other effect types */}
												{/* ... */}
											</div>
											<Separator className="my-4" />
										</div>
									))
								)}
								{/* Add FX toolbar in parameters panel (optional, same style) */}
								<div className="overflow-x-auto no-scrollbar px-2 -mx-2">
									<div className="flex flex-wrap gap-3 items-center content-start max-w-full">
										{FX_TYPES.map(fx => (
											<Button
												key={fx.type}
												variant="outline"
												size="sm"
												onClick={() => handleAddEffect(fx.type)}
												className="shrink-0 max-w-full whitespace-nowrap"
											>
												<Plus className="w-3 h-3 mr-1" />
												{fx.label}
											</Button>
										))}
									</div>
								</div>
							</CardContent>
						</Card>
					</div>
				</div>
			</div>
		</div>
	);
}
