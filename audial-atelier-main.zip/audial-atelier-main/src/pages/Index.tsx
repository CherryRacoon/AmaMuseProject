import { useEffect } from "react";
import { ProjectDashboard } from "@/components/ProjectDashboard";
import { useNavigationStore } from "@/stores/useNavigationStore";

const Index = () => {
  const { setWorkflowPhase } = useNavigationStore();

  useEffect(() => {
    setWorkflowPhase("dashboard");
  }, [setWorkflowPhase]);

  return (
    <div className="container mx-auto px-6 py-8">
      <ProjectDashboard />
    </div>
  );
};

export default Index;
