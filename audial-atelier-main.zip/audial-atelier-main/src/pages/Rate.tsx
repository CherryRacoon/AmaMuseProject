
import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { scoreSong } from '@/lib/scoring';
import { getCyaniteFeatures } from '@/lib/providers/cyanite';
import { getSoundStatFeatures } from '@/lib/providers/soundstat';
import { getSpotifyFeatures } from '@/lib/providers/spotify';
import { ProviderFeatures, RateReport } from '@/types/rating';
import { ScoreBars } from '@/components/rate/ScoreBars';
import { MoodTimeline } from '@/components/rate/MoodTimeline';
import { DynamicsEnvelope } from '@/components/rate/DynamicsEnvelope';
import { PopularityRadar } from '@/components/rate/PopularityRadar';
import { ConclusionCard } from '@/components/rate/ConclusionCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Terminal } from 'lucide-react';
import { useNavigationStore } from '@/stores/useNavigationStore';
import { useDebugLog } from '@/hooks/useDebugLog';

export default function RatePage() {
  const location = useLocation();
  const { setWorkflowPhase } = useNavigationStore();
  const { addLog } = useDebugLog();
  const [report, setReport] = useState<RateReport | null>(null);
  const [providerFeatures, setProviderFeatures] = useState<ProviderFeatures | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const songId = location.state?.songId || 'mock_song_id';

  useEffect(() => {
    setWorkflowPhase("rating");

    addLog("INFO", "System", "Page Load", "Rate page loaded", {
      songId,
    });
  }, [setWorkflowPhase, addLog, songId]);

  useEffect(() => {
    const fetchAndScore = async () => {
      try {
        setLoading(true);
        const [cyanite, soundstat, spotify] = await Promise.all([
          getCyaniteFeatures(songId),
          getSoundStatFeatures(songId),
          getSpotifyFeatures(songId).catch(() => null), // Spotify is optional
        ]);

        const features: ProviderFeatures = { cyanite, soundstat };
        if (spotify) {
          features.spotify = spotify;
        }
        
        setProviderFeatures(features);
        const rateReport = scoreSong(features);
        setReport(rateReport);
      } catch (err) {
        setError('Failed to fetch song analysis data. Please check your API settings and try again.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchAndScore();
  }, [songId]);

  if (loading) {
    return (
      <div className="container mx-auto px-6 py-8 space-y-8">
        <Skeleton className="h-48 w-full" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Skeleton className="h-72 w-full" />
          <Skeleton className="h-72 w-full" />
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (error) {
    return (
        <div className="container mx-auto px-6 py-8">
            <Alert variant="destructive">
                <Terminal className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
            </Alert>
        </div>
    );
  }

  if (!report || !providerFeatures) {
    return null;
  }

  return (
    <div className="container mx-auto px-6 py-8 space-y-8">
        <h1 className="text-3xl font-bold">Song Analysis Report</h1>
        
        <ConclusionCard report={report} />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <ScoreBars structure={report.structure} appeal={report.appeal} novelty={report.novelty} potential={report.potential} />
            {providerFeatures.spotify && <PopularityRadar spotify={providerFeatures.spotify} />}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {providerFeatures.cyanite && <MoodTimeline cyanite={providerFeatures.cyanite} />}
            {providerFeatures.soundstat && <DynamicsEnvelope soundstat={providerFeatures.soundstat} />}
        </div>
    </div>
  );
}
