import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useProjectStore, PromptRefinement } from "@/stores/useProjectStore";
import { useNavigationStore } from "@/stores/useNavigationStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Wand2, Sparkles, CheckCircle, AlertCircle } from "lucide-react";
import { InspirationSummary } from "@/components/refine/InspirationSummary";
import { MusicalDetailsForm } from "@/components/refine/MusicalDetailsForm";
import { EnhancedLyricsEditor } from "@/components/refine/EnhancedLyricsEditor";
import { SongStructurePlanner } from "@/components/refine/SongStructurePlanner";
import { PromptComparison } from "@/components/refine/PromptComparison";
import { ValidationPanel } from "@/components/refine/ValidationPanel";

const Refine = () => {
  const navigate = useNavigate();
  const { currentProject, updateRefinement, addPromptVersion } = useProjectStore();
  const { setWorkflowPhase } = useNavigationStore();
  const { addLog } = useDebugLog();

  const [activeTab, setActiveTab] = useState("inspiration");
  const [isValid, setIsValid] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  const handleValidationComplete = useCallback((valid: boolean) => {
    setIsValid(valid);
    setValidationErrors(valid ? [] : ['Some required fields are missing or invalid']);
  }, []);

  useEffect(() => {
    setWorkflowPhase("refine");

    // Allow access to all pages - removed redirect logic
    // if (!currentProject || (!currentProject.audioInput && !currentProject.textPrompt && !currentProject.lyrics)) {
    //   navigate("/create");
    // }

    addLog("INFO", "System", "Page Load", "Refine page loaded", {
      projectId: currentProject?.id,
      hasAudio: !!currentProject?.audioInput,
      hasText: !!currentProject?.textPrompt,
      hasLyrics: !!currentProject?.lyrics,
    });
  }, [currentProject, navigate, setWorkflowPhase, addLog]);

  const handleSaveRefinement = (refinement: Partial<PromptRefinement>) => {
    if (!currentProject) return;

    updateRefinement(currentProject.id, refinement);
    if (refinement.enhancedPrompt) {
      addPromptVersion(currentProject.id, refinement.enhancedPrompt);
    }

    addLog("INFO", "System", "Refinement Saved", "Prompt refinement updated", {
      projectId: currentProject.id,
      updatedFields: Object.keys(refinement),
      structureLength:
        refinement.structure?.length ??
        currentProject.refinement?.structure?.length ??
        0,
    });
  };

  const handleContinue = () => {
    if (!isValid) return;

    addLog("INFO", "System", "Navigation", "Proceeding to generation phase", {
      projectId: currentProject?.id,
      validationPassed: isValid,
    });

    navigate("/generate");
  };

  if (!currentProject) {
    return null;
  }

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="max-w-7xl mx-auto">
        {/* Header (Generate button aligned with title/subtitle; hint below header) */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <Wand2 className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold text-foreground">Refine Prompt</h1>
              <p className="text-muted-foreground mt-1">AI-assisted prompt enhancement and structuring</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isValid ? (
              <CheckCircle className="w-5 h-5 text-green-500" />
            ) : (
              <AlertCircle className="w-5 h-5 text-yellow-500" />
            )}
            <Button onClick={handleContinue} disabled={!isValid} size="lg" className="gap-2">
              <Sparkles className="w-4 h-4" />
              Generate Music →
            </Button>
          </div>
        </div>

        {/* Validation hint below the header (keeps Generate aligned like Capture) */}
        <div className="mb-6">
          <div className="text-sm text-muted-foreground">
            {!isValid ? (
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-yellow-500 mt-0.5" />
                <div>
                  <div className="font-medium">Complete Required Fields</div>
                  {validationErrors.length > 0 && (
                    <div className="text-xs text-muted-foreground">{validationErrors[0]}</div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                <div className="font-medium">Ready for Generation</div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="inspiration">Inspiration</TabsTrigger>
                <TabsTrigger value="details">Musical Details</TabsTrigger>
                <TabsTrigger value="lyrics">Lyrics</TabsTrigger>
                <TabsTrigger value="compare">Compare</TabsTrigger>
              </TabsList>

              <TabsContent value="inspiration" className="mt-6">
                <InspirationSummary project={currentProject} />
              </TabsContent>

              <TabsContent value="details" className="mt-6">
                <MusicalDetailsForm
                  project={currentProject}
                  onSave={handleSaveRefinement}
                />
              </TabsContent>

              <TabsContent value="lyrics" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <EnhancedLyricsEditor
                    project={currentProject}
                    onSave={handleSaveRefinement}
                  />
                  <SongStructurePlanner
                    project={currentProject}
                    onSave={handleSaveRefinement}
                  />
                </div>
              </TabsContent>

              <TabsContent value="compare" className="mt-6">
                <PromptComparison project={currentProject} />
              </TabsContent>
            </Tabs>

            {/* Validation Panel */}
            <ValidationPanel
              project={currentProject}
              onValidationComplete={handleValidationComplete}
            />

            {/* Continue button moved to header; validation details remain in panel above */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Refine;
