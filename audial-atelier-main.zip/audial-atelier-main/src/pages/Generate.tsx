import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useProjectStore } from "@/stores/useProjectStore";
import { useNavigationStore } from "@/stores/useNavigationStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Zap,
  CheckCircle,
  AlertTriangle,
  Clock,
  RotateCcw,
  Settings,
  Activity,
  Server,
  Loader2,
  Star,
} from "lucide-react";
import { GenerationProgress } from "@/components/generate/GenerationProgress";
import { DebugLogPanel } from "@/components/generate/DebugLogPanel";
import { GeneratedVersionsGallery } from "@/components/generate/GeneratedVersionsGallery";
import { APIStatusIndicator } from "@/components/generate/APIStatusIndicator";
import { EnhancedPromptPanel } from "@/components/generate/EnhancedPromptPanel";

type GenerationStage = "validating" | "initializing" | "generating" | "postprocessing" | "ready";

interface GenerationState {
  stage: GenerationStage;
  progress: number;
  taskId?: string;
  apiProvider: "acestep" | "lyria" | "suno";
  queuePosition?: number;
  elapsedTime: number;
  estimatedTime?: number;
  error?: string;
  retryCount: number;
}

const Generate = () => {
  const navigate = useNavigate();
  const { currentProject, updateGenerationStatus, addGeneratedVersion } = useProjectStore();
  const { setWorkflowPhase } = useNavigationStore();
  const { addLog } = useDebugLog();
  const { toast } = useToast();

  const [generationState, setGenerationState] = useState<GenerationState>({
    stage: "validating",
    progress: 0,
    apiProvider: "acestep",
    elapsedTime: 0,
    retryCount: 0
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [startTime, setStartTime] = useState<Date | null>(null);
  useEffect(() => {
    setWorkflowPhase("generating");
    addLog("INFO", "System", "Page Load", "Generate page loaded", {
      projectId: currentProject?.id,
      hasRefinement: !!currentProject?.refinement
    });
  }, [currentProject, setWorkflowPhase, addLog]);

  // Timer for elapsed time
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isGenerating && startTime) {
      interval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTime.getTime()) / 1000);
        setGenerationState(prev => ({ ...prev, elapsedTime: elapsed }));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isGenerating, startTime]);

  const startGeneration = async (isRegenerate = false) => {
    if (!currentProject) return;

    setIsGenerating(true);
    setStartTime(new Date());
    setGenerationState(prev => ({
      ...prev,
      stage: "validating",
      progress: 0,
      elapsedTime: 0,
      error: undefined,
      retryCount: isRegenerate ? prev.retryCount + 1 : 0
    }));

    addLog("INFO", "System", isRegenerate ? "Regeneration Started" : "Started", isRegenerate ? "Music regeneration initiated" : "Music generation initiated", {
      projectId: currentProject.id,
      apiProvider: generationState.apiProvider,
      prompt: currentProject.refinement?.enhancedPrompt?.substring(0, 100) + "...",
      isRegeneration: isRegenerate,
      attempt: isRegenerate ? generationState.retryCount + 1 : 0
    });

    try {
      // Stage 1: Validation
      await simulateStage("validating", 20, 2000);

      // Stage 2: API Authentication
      await simulateStage("initializing", 40, 1500);

      // Stage 3: Generation
      await simulateStage("generating", 70, 8000);

      // Stage 4: Post-processing
      await simulateStage("postprocessing", 90, 3000);

      // Stage 5: Complete
      await simulateStage("ready", 100, 500);

      // Create mock versions for demonstration
      const mockVersions = [
        {
          id: `v${Date.now()}-1`,
          audioUrl: "/mock-audio-1.mp3",
          duration: 180,
          waveformData: Array.from({ length: 100 }, () => Math.random()),
          timestamp: new Date()
        },
        {
          id: `v${Date.now()}-2`,
          audioUrl: "/mock-audio-2.mp3",
          duration: 175,
          waveformData: Array.from({ length: 100 }, () => Math.random()),
          timestamp: new Date()
        }
      ];

      // Add generated versions to project
      mockVersions.forEach(version => {
        addGeneratedVersion(currentProject.id, version);
      });

      updateGenerationStatus(currentProject.id, {
        stage: "ready",
        progress: 100
      });

      addLog("INFO", "System", isRegenerate ? "Regeneration Completed" : "Completed", isRegenerate ? "Music regeneration finished successfully" : "Music generation finished successfully", {
        projectId: currentProject.id,
        versionsGenerated: mockVersions.length,
        totalDuration: generationState.elapsedTime,
        isRegeneration: isRegenerate
      });

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
      setGenerationState(prev => ({
        ...prev,
        error: errorMessage,
        stage: "validating"
      }));

      addLog("ERROR", "System", isRegenerate ? "Regeneration Failed" : "Failed", errorMessage, {
        projectId: currentProject?.id,
        stage: generationState.stage,
        retryCount: generationState.retryCount
      });

      toast({
        title: "Generation Failed",
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const simulateStage = (stage: GenerationStage, targetProgress: number, duration: number): Promise<void> => {
    return new Promise((resolve) => {
      const startProgress = generationState.progress;
      const progressDiff = targetProgress - startProgress;
      const steps = 20;
      const stepDuration = duration / steps;

      let currentStep = 0;

      const interval = setInterval(() => {
        currentStep++;
        const progress = startProgress + (progressDiff * (currentStep / steps));

        setGenerationState(prev => ({
          ...prev,
          stage,
          progress: Math.min(progress, targetProgress)
        }));

        if (currentStep >= steps) {
          clearInterval(interval);
          setTimeout(resolve, 200); // Small delay before next stage
        }
      }, stepDuration);
    });
  };

  const retryGeneration = () => {
    setGenerationState(prev => ({
      ...prev,
      retryCount: prev.retryCount + 1,
      error: undefined
    }));

    addLog("INFO", "System", "Retry", `Retrying generation (attempt ${generationState.retryCount + 1})`, {
      projectId: currentProject?.id,
      previousError: generationState.error
    });

    // mark as regeneration retry
    startGeneration(true);
  };

  const regenerateGeneration = () => {
    if (!currentProject || isGenerating) return;

    addLog("INFO", "System", "Regenerate Requested", "User requested regeneration of generated audio", {
      projectId: currentProject.id,
      previousVersions: currentProject.generatedVersions.length,
      attempt: generationState.retryCount + 1
    });

    startGeneration(true);
  };

  const switchAPI = () => {
    const nextApi = generationState.apiProvider === "acestep" 
      ? "lyria" 
      : generationState.apiProvider === "lyria" 
        ? "suno" 
        : "acestep";

    setGenerationState(prev => ({
      ...prev,
      apiProvider: nextApi,
      error: undefined
    }));

    addLog("INFO", "System", "API Switch", `Switched to ${nextApi} API`, {
      projectId: currentProject?.id,
      fromAPI: generationState.apiProvider,
      toAPI: nextApi
    });

    toast({
      title: "API Switched",
      description: `Now using ${nextApi.toUpperCase()} API`
    });
  };



  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!currentProject) {
    return null;
  }

  const isCompleted = generationState.stage === "ready" && !isGenerating;
  const hasError = !!generationState.error;

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
            <Zap className="w-8 h-8 text-primary" />
            Generate Music
          </h1>
          <p className="text-muted-foreground mt-2">
            AI-powered music generation with real-time progress monitoring
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Main Generation Panel */}
          <div className="xl:col-span-3 space-y-6">
            {/* Enhanced Prompt Display */}
            <EnhancedPromptPanel
              enhancedPrompt={currentProject.refinement?.enhancedPrompt}
              instruments={currentProject.refinement?.instruments}
              emotions={currentProject.refinement?.emotions}
            />

            {/* Generation Progress */}
            <GenerationProgress
              stage={generationState.stage}
              progress={generationState.progress}
              isGenerating={isGenerating}
              elapsedTime={generationState.elapsedTime}
              estimatedTime={generationState.estimatedTime}
            />

            {/* API Status & Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Server className="w-5 h-5" />
                    Generation Controls
                  </div>
                  <APIStatusIndicator
                    provider={generationState.apiProvider}
                    isActive={isGenerating}
                    taskId={generationState.taskId}
                    queuePosition={generationState.queuePosition}
                  />
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Badge variant="outline" className="gap-2">
                      <Activity className="w-3 h-3" />
                      {generationState.apiProvider.toUpperCase()} API
                    </Badge>
                    {generationState.taskId && (
                      <Badge variant="secondary">
                        Task: {generationState.taskId}
                      </Badge>
                    )}
                    {generationState.elapsedTime > 0 && (
                      <Badge variant="outline">
                        <Clock className="w-3 h-3 mr-1" />
                        {formatTime(generationState.elapsedTime)}
                      </Badge>
                    )}
                  </div>

                  <div className="flex gap-2">
                    {!isGenerating && !isCompleted && (
                      <Button onClick={() => startGeneration(false)} className="gap-2">
                        <Zap className="w-4 h-4" />
                        Start Generation
                      </Button>
                    )}

                    {isGenerating && (
                      <Button variant="outline" disabled className="gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Generating...
                      </Button>
                    )}

                    {hasError && (
                      <>
                        <Button onClick={switchAPI} variant="outline" className="gap-2">
                          <Settings className="w-4 h-4" />
                          Switch API
                        </Button>
                        <Button onClick={retryGeneration} variant="outline" className="gap-2">
                          <RotateCcw className="w-4 h-4" />
                          Retry
                        </Button>
                      </>
                    )}
                  </div>
                </div>

                {hasError && (
                  <Alert className="border-red-200 bg-red-50">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      {generationState.error}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Generated Versions Gallery */}
            {isCompleted && (
              <GeneratedVersionsGallery
                project={currentProject}
                onSelectVersion={(versionId) => {
                  // Handle version selection
                  addLog("INFO", "System", "Version Selected", `Selected version ${versionId}`, {
                    projectId: currentProject.id,
                    versionId
                  });
                }}
              />
            )}

            {/* Continue Button */}
            {isCompleted && (
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <div>
                      <p className="font-medium">Generation Complete</p>
                      <p className="text-sm text-muted-foreground">
                        {currentProject.generatedVersions.length} versions ready for editing
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        addLog("INFO", "System", "Navigation", "Proceeding to rate phase", {
                          projectId: currentProject.id,
                          fromStage: "generating"
                        });
                        navigate("/rate", { 
                          state: { 
                            songId: currentProject.generatedVersions[0]?.id 
                          }
                        });
                      }}
                      size="lg"
                      className="gap-2"
                    >
                      <Star className="w-4 h-4" />
                      Rate Music
                    </Button>

                    <Button
                      onClick={() => navigate("/edit")}
                      size="lg"
                      variant="outline"
                      className="gap-2"
                    >
                      Edit & Mix →
                    </Button>

                    <Button
                      onClick={regenerateGeneration}
                      size="lg"
                      variant="outline"
                      className="gap-2"
                      disabled={isGenerating}
                      title="Regenerate this project (create new versions)"
                    >
                      ↻ Regenerate
                    </Button>
                  </div>
                </div>
              </Card>
            )}
          </div>

          {/* Debug Log Panel */}
          <div className="xl:col-span-1">
            <DebugLogPanel
              projectId={currentProject.id}
              isActive={isGenerating}
              generationState={generationState}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Generate;
