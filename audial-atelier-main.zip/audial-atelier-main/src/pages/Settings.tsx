import { useEffect } from "react";
import { useNavigationStore } from "@/stores/useNavigationStore";
import { ApiSettings } from "@/components/ApiSettings";

const Settings = () => {
  const { setWorkflowPhase } = useNavigationStore();

  useEffect(() => {
    setWorkflowPhase("dashboard");
  }, [setWorkflowPhase]);

  return (
    <div className="container mx-auto px-6 py-8">
      <ApiSettings />
    </div>
  );
};

export default Settings;
