import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Music, FileAudio, FileText, Image as ImageIcon, Sparkles } from "lucide-react";
import { useProjectStore } from "@/stores/useProjectStore";
import { useNavigationStore } from "@/stores/useNavigationStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { AudioRecorder } from "@/components/create/AudioRecorder";
import { TextPromptEditor } from "@/components/create/TextPromptEditor";
import { LyricsEditor } from "@/components/create/LyricsEditor";
import { ImageUploader } from "@/components/create/ImageUploader";
import { PreviewPanel } from "@/components/create/PreviewPanel";
import { toast } from "sonner";

export default function CreateProject() {
  const navigate = useNavigate();
  const { currentProject, updateProject, createProject } = useProjectStore();
  const { setWorkflowPhase, setUnsavedChanges, hasUnsavedChanges } = useNavigationStore();
  const { addLog } = useDebugLog();
  const [activeTab, setActiveTab] = useState("audio");
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    setWorkflowPhase("input");

    if (!currentProject) {
      // Create a default project for unrestricted navigation
      const defaultProjectName = `Project ${Date.now()}`;
      const projectId = createProject(defaultProjectName);

      addLog("INFO", "System", "Default Project Created", "Created default project for navigation", {
        projectId,
        name: defaultProjectName,
      });

      toast.success(`Default project "${defaultProjectName}" created for navigation`);
      // Don't navigate - stay on the page and let the project be set
      return;
    }

    addLog("INFO", "System", "Page Load", "Capture (multi-modal input) page loaded", {
      projectId: currentProject.id,
    });
  }, [currentProject, createProject, addLog, setWorkflowPhase]);

  useEffect(() => {
    // Validate that at least one input method is complete
    if (!currentProject) return;

    const hasAudio = !!currentProject.audioInput;
    const hasText = !!currentProject.textPrompt?.text && currentProject.textPrompt.text.length > 0;
    const hasLyrics = !!currentProject.lyrics?.content && currentProject.lyrics.content.length > 0;
    const hasImage = Boolean(
      currentProject.imageInspiration?.analysis ||
      currentProject.imageInspiration?.extractedPrompt
    );

    const hasAnyInput = hasAudio || hasText || hasLyrics || hasImage;

    // Only update state if values have actually changed
    if (isValid !== hasAnyInput) {
      setIsValid(hasAnyInput);
    }
    if (hasUnsavedChanges !== hasAnyInput) {
      setUnsavedChanges(hasAnyInput);
    }
  }, [currentProject, isValid, hasUnsavedChanges, setUnsavedChanges]);

  const handleContinue = () => {
    if (!currentProject) return;

    addLog("INFO", "System", "Phase Transition", "Moving to Refine phase", {
      projectId: currentProject.id,
      hasAudio: !!currentProject.audioInput,
      hasText: !!currentProject.textPrompt,
      hasLyrics: !!currentProject.lyrics,
      hasImage: !!currentProject.imageInspiration,
    });

    updateProject(currentProject.id, { phase: "refine" });
    setUnsavedChanges(false);
    toast.success("Input captured! Moving to prompt refinement.");
    navigate("/refine");
  };

  if (!currentProject) {
    return null;
  }

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="space-y-4 mb-8">
        {/* Header with Title and Continue Button */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-glow">
              <Music className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">{currentProject.name}</h1>
              <p className="text-sm text-muted-foreground">Phase 1: Capture</p>
            </div>
          </div>

          <Button
            onClick={handleContinue}
            disabled={!isValid}
            className="gap-2"
            size="lg"
          >
            Continue to Refinement
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Input Status Bar */}
        <div className="flex items-center justify-between p-4 bg-muted/40 rounded-lg border border-border/60">
          <div className="flex gap-2">
            {currentProject.audioInput && (
              <Badge variant="default">Audio ✓</Badge>
            )}
            {currentProject.textPrompt?.text && (
              <Badge variant="default">Text ✓</Badge>
            )}
            {currentProject.lyrics?.content && (
              <Badge variant="default">Lyrics ✓</Badge>
            )}
            {(currentProject.imageInspiration?.analysis || currentProject.imageInspiration?.extractedPrompt) && (
              <Badge variant="default">Image ✓</Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground">
            {isValid ? "Ready to continue" : "Add at least one input to proceed"}
          </p>
        </div>
      </div>

      {/* Main Content - Split Screen */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left: Input Tabs */}
          <Card className="bg-card/50 backdrop-blur-sm border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                Creative Input
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="audio" className="gap-2">
                    <FileAudio className="w-4 h-4" />
                    Audio
                  </TabsTrigger>
                  <TabsTrigger value="text" className="gap-2">
                    <FileText className="w-4 h-4" />
                    Text
                  </TabsTrigger>
                  <TabsTrigger value="lyrics" className="gap-2">
                    <Music className="w-4 h-4" />
                    Lyrics
                  </TabsTrigger>
                  <TabsTrigger value="image" className="gap-2">
                    <ImageIcon className="w-4 h-4" />
                    Image
                  </TabsTrigger>
                </TabsList>

                <div className="mt-6">
                  <TabsContent value="audio" className="mt-0">
                    <AudioRecorder projectId={currentProject.id} />
                  </TabsContent>

                  <TabsContent value="text" className="mt-0">
                    <TextPromptEditor projectId={currentProject.id} />
                  </TabsContent>

                  <TabsContent value="lyrics" className="mt-0">
                    <LyricsEditor projectId={currentProject.id} />
                  </TabsContent>

                  <TabsContent value="image" className="mt-0">
                    <ImageUploader projectId={currentProject.id} />
                  </TabsContent>
                </div>
              </Tabs>
            </CardContent>
          </Card>

          {/* Right: Live Preview */}
          <PreviewPanel projectId={currentProject.id} />
      </div>
    </div>
  );
}
