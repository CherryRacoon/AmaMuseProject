import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useProjectStore, Track } from "@/stores/useProjectStore";
import { useNavigationStore } from "@/stores/useNavigationStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Sliders,
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Redo,
  Save,
  Share2,
  Music,
  Mic,
  Drum,
  Guitar,
  Piano,
  Users,
  FileText,
  Eye,
  EyeOff
} from "lucide-react";
import { Timeline } from "@/components/edit/Timeline";
import { TrackSidebar } from "@/components/edit/TrackSidebar";
import { EffectsRack } from "@/components/edit/EffectsRack";
import { LyricsEditor } from "@/components/edit/LyricsEditor";
import { SheetMusicViewer } from "@/components/edit/SheetMusicViewer";
import EnhancedEffectsEditor from "@/components/edit/EnhancedEffectsEditor";
import EnhancedLyricsEditor from "@/components/edit/EnhancedLyricsEditor";
import EnhancedSheetMusicEditor from "@/components/edit/EnhancedSheetMusicEditor";
import { AudioControls } from "@/components/edit/AudioControls";
import ExternalSheetMusicSheet from "@/components/edit/ExternalSheetMusicSheet";
import { SHEET_MUSIC_URL } from "@/config/external";

type EditMode = "arrange" | "effects" | "lyrics" | "sheet-music";

interface PlaybackState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
}

const Edit = () => {
  const navigate = useNavigate();
  const { currentProject, updateTrack, updateTracks } = useProjectStore();
  const { setWorkflowPhase } = useNavigationStore();
  const { addLog } = useDebugLog();

  const [editMode, setEditMode] = useState<EditMode>("arrange");
  const [playbackState, setPlaybackState] = useState<PlaybackState>({
    isPlaying: false,
    currentTime: 0,
    duration: 180, // 3 minutes default
    volume: 0.8,
    isMuted: false
  });
  const [zoomLevel, setZoomLevel] = useState(1);
  const [showSheetMusic, setShowSheetMusic] = useState(false);
  const [selectedTrackId, setSelectedTrackId] = useState<string | null>(null);
  const [undoStack, setUndoStack] = useState<unknown[]>([]);
  const [redoStack, setRedoStack] = useState<unknown[]>([]);
  const [externalSheetOpen, setExternalSheetOpen] = useState(false);

  useEffect(() => {
    setWorkflowPhase("editing");

    // Allow access to all pages - removed redirect logic
    // if (!currentProject || currentProject.generatedVersions.length === 0) {
    //   navigate("/generate");
    // }

    addLog("INFO", "System", "Page Load", "Edit page loaded", {
      projectId: currentProject?.id,
      tracksCount: currentProject?.tracks.length || 0
    });
  }, [currentProject, setWorkflowPhase, addLog]);

  // Initialize default tracks if none exist
  useEffect(() => {
    if (currentProject && currentProject.tracks.length === 0) {
      const defaultTracks: Track[] = [
        {
          id: "vocals",
          name: "Vocals",
          type: "vocals" as const,
          audioUrl: "/mock-vocals.mp3",
          volume: 0.8,
          pan: 0,
          muted: false,
          soloed: false,
          color: "#ff6b6b"
        },
        {
          id: "drums",
          name: "Drums",
          type: "drums" as const,
          audioUrl: "/mock-drums.mp3",
          volume: 0.7,
          pan: 0,
          muted: false,
          soloed: false,
          color: "#4ecdc4"
        },
        {
          id: "bass",
          name: "Bass",
          type: "bass" as const,
          audioUrl: "/mock-bass.mp3",
          volume: 0.6,
          pan: 0,
          muted: false,
          soloed: false,
          color: "#45b7d1"
        },
        {
          id: "melody",
          name: "Melody",
          type: "melody" as const,
          audioUrl: "/mock-melody.mp3",
          volume: 0.75,
          pan: 0.2,
          muted: false,
          soloed: false,
          color: "#96ceb4"
        },
        {
          id: "harmony",
          name: "Harmony",
          type: "harmony" as const,
          audioUrl: "/mock-harmony.mp3",
          volume: 0.65,
          pan: -0.2,
          muted: false,
          soloed: false,
          color: "#feca57"
        },
        {
          id: "full-mix",
          name: "Full Mix",
          type: "full" as const,
          audioUrl: "/mock-full-mix.mp3",
          volume: 0.8,
          pan: 0,
          muted: false,
          soloed: false,
          color: "#ff9ff3"
        }
      ];

      updateTracks(currentProject.id, defaultTracks);

      addLog("INFO", "System", "Default Tracks Created", "Initialized default audio stems", {
        projectId: currentProject.id,
        tracksCount: defaultTracks.length
      });
    }
  }, [currentProject, updateTracks, addLog]);

  const handlePlayPause = useCallback(() => {
    setPlaybackState(prev => ({
      ...prev,
      isPlaying: !prev.isPlaying
    }));

    addLog("INFO", "System", "Playback Toggled", `Playback ${playbackState.isPlaying ? 'paused' : 'started'}`, {
      projectId: currentProject?.id,
      currentTime: playbackState.currentTime
    });
  }, [playbackState.isPlaying, playbackState.currentTime, currentProject?.id, addLog]);

  const handleStop = useCallback(() => {
    setPlaybackState(prev => ({
      ...prev,
      isPlaying: false,
      currentTime: 0
    }));

    addLog("INFO", "System", "Playback Stopped", "Playback stopped and reset to beginning", {
      projectId: currentProject?.id
    });
  }, [currentProject?.id, addLog]);

  const handleVolumeChange = useCallback((volume: number) => {
    setPlaybackState(prev => ({
      ...prev,
      volume,
      isMuted: volume === 0
    }));

    addLog("INFO", "System", "Volume Changed", `Volume set to ${Math.round(volume * 100)}%`, {
      projectId: currentProject?.id,
      volume
    });
  }, [currentProject?.id, addLog]);

  const handleMuteToggle = useCallback(() => {
    setPlaybackState(prev => ({
      ...prev,
      isMuted: !prev.isMuted
    }));

    addLog("INFO", "System", "Mute Toggled", `Audio ${playbackState.isMuted ? 'unmuted' : 'muted'}`, {
      projectId: currentProject?.id
    });
  }, [playbackState.isMuted, currentProject?.id, addLog]);

  const handleZoomIn = useCallback(() => {
    setZoomLevel(prev => Math.min(prev * 1.5, 10));
    addLog("INFO", "System", "Zoom In", "Timeline zoomed in", {
      projectId: currentProject?.id,
      newZoom: zoomLevel * 1.5
    });
  }, [zoomLevel, currentProject?.id, addLog]);

  const handleZoomOut = useCallback(() => {
    setZoomLevel(prev => Math.max(prev / 1.5, 0.1));
    addLog("INFO", "System", "Zoom Out", "Timeline zoomed out", {
      projectId: currentProject?.id,
      newZoom: zoomLevel / 1.5
    });
  }, [zoomLevel, currentProject?.id, addLog]);

  const handleUndo = useCallback(() => {
    if (undoStack.length > 0) {
      const lastAction = undoStack[undoStack.length - 1];
      setUndoStack(prev => prev.slice(0, -1));
      setRedoStack(prev => [...prev, lastAction]);

      // Apply undo logic here
      addLog("INFO", "System", "Undo", "Action undone", {
        projectId: currentProject?.id,
        action: lastAction
      });
    }
  }, [undoStack, currentProject?.id, addLog]);

  const handleRedo = useCallback(() => {
    if (redoStack.length > 0) {
      const action = redoStack[redoStack.length - 1];
      setRedoStack(prev => prev.slice(0, -1));
      setUndoStack(prev => [...prev, action]);

      // Apply redo logic here
      addLog("INFO", "System", "Redo", "Action redone", {
        projectId: currentProject?.id,
        action: action
      });
    }
  }, [redoStack, currentProject?.id, addLog]);

  const handleRegenerateSection = useCallback((startTime: number, endTime: number, instructions: string) => {
    addLog("INFO", "System", "Section Regeneration", "AI section regeneration requested", {
      projectId: currentProject?.id,
      startTime,
      endTime,
      instructions
    });

    // Mock regeneration - in real app, this would call AI API
    setTimeout(() => {
      addLog("INFO", "AI", "Section Regenerated", "Section regeneration completed", {
        projectId: currentProject?.id,
        startTime,
        endTime
      });
    }, 2000);
  }, [currentProject?.id, addLog]);

  const handleTrackUpdate = useCallback((trackId: string, updates: Partial<Track>) => {
    if (!currentProject) return;

    updateTrack(currentProject.id, trackId, updates);

    addLog("INFO", "System", "Track Updated", `Track ${trackId} updated`, {
      projectId: currentProject.id,
      trackId,
      updates
    });
  }, [currentProject, updateTrack, addLog]);

  if (!currentProject) {
    return null;
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
              <Sliders className="w-6 h-6 text-primary" />
              Multi-Track Editor
            </h1>
            <Badge variant="secondary">{currentProject.name}</Badge>
          </div>
          <div className="flex items-center gap-2">
            {/* Export */}
            <Button onClick={() => navigate("/export")} className="gap-2">
              <Share2 className="w-4 h-4" />
              Export
            </Button>
          </div>
        </div>
        {/* Tabs Navigation */}
        <Tabs value={editMode} onValueChange={(value) => setEditMode(value as EditMode)} className="mt-4">
          <TabsList>
            <TabsTrigger value="arrange">Arrange</TabsTrigger>
            <TabsTrigger value="effects">Effects</TabsTrigger>
            <TabsTrigger value="lyrics">Lyrics</TabsTrigger>
            <TabsTrigger value="sheet-music">Sheet Music</TabsTrigger>
          </TabsList>
        </Tabs>
      </header>
      {/* Main Editor Area */}
      <div className="flex-1 flex overflow-hidden">
        {editMode === "arrange" ? (
          <>
            {/* Track Sidebar */}
            <TrackSidebar
              tracks={currentProject.tracks}
              selectedTrackId={selectedTrackId}
              onTrackSelect={setSelectedTrackId}
              onTrackUpdate={handleTrackUpdate}
            />

            {/* Main Timeline Area */}
            <div className="flex-1 flex flex-col">
              {/* Timeline Controls */}
              <div className="border-b border-border bg-card px-4 py-2 flex items-center justify-between">
                <AudioControls
                  playbackState={playbackState}
                  onPlayPause={handlePlayPause}
                  onStop={handleStop}
                  onVolumeChange={handleVolumeChange}
                  onMuteToggle={handleMuteToggle}
                />

                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={handleZoomOut}>
                    <ZoomOut className="w-4 h-4" />
                  </Button>
                  <span className="text-sm text-muted-foreground min-w-[60px] text-center">
                    {Math.round(zoomLevel * 100)}%
                  </span>
                  <Button variant="outline" size="sm" onClick={handleZoomIn}>
                    <ZoomIn className="w-4 h-4" />
                  </Button>

                  <Separator orientation="vertical" className="h-6" />

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleUndo}
                    disabled={undoStack.length === 0}
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRedo}
                    disabled={redoStack.length === 0}
                  >
                    <Redo className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Timeline */}
              <div className="flex-1 overflow-hidden">
                <Timeline
                  tracks={currentProject.tracks}
                  zoomLevel={zoomLevel}
                  currentTime={playbackState.currentTime}
                  duration={playbackState.duration}
                  selectedTrackId={selectedTrackId}
                  onTrackSelect={setSelectedTrackId}
                  onRegenerateSection={handleRegenerateSection}
                  editMode={editMode}
                />
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col overflow-hidden">
            {editMode === "effects" && (
              <EnhancedEffectsEditor
                trackId={selectedTrackId}
                onEffectsChange={(effects) => {
                  addLog("INFO", "System", "Effects Changed", `Effects chain updated`, {
                    projectId: currentProject.id,
                    trackId: selectedTrackId,
                    effectCount: effects.length
                  });
                }}
              />
            )}

            {editMode === "lyrics" && (
              <EnhancedLyricsEditor
                initialLyrics={currentProject.lyrics?.content || ""}
                onLyricsChange={(lyrics) => {
                  addLog("INFO", "System", "Lyrics Modified", "Lyrics updated", {
                    projectId: currentProject.id,
                    lyricsLength: lyrics.length
                  });
                }}
              />
            )}

            {editMode === "sheet-music" && (
              <EnhancedSheetMusicEditor
                onNotesChange={(notes) => {
                  addLog("INFO", "System", "Sheet Music Edited", `Notes updated`, {
                    projectId: currentProject.id,
                    noteCount: notes.length
                  });
                }}
              />
            )}
          </div>
        )}
      </div>

      {/* External sheet music bottom panel */}
      <ExternalSheetMusicSheet
        open={externalSheetOpen}
        onOpenChange={setExternalSheetOpen}
        url={SHEET_MUSIC_URL}
        title="Sheet Music Editor"
      />
    </div>
  );
};

export default Edit;
