/**
 * Generates waveform data from an audio file
 * @param audioUrl URL of the audio file
 * @returns Array of waveform values (between 0 and 1)
 */
async function fetchWithRetry(
  url: string,
  retries: number = 3,
  delay: number = 1000
): Promise<ArrayBuffer> {
  let lastError: Error | null = null;

  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.arrayBuffer();
    } catch (error: any) {
      lastError = error;
      console.warn(`Attempt ${i + 1} failed:`, error);

      // Don't wait on the last retry
      if (i < retries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay * Math.pow(2, i)));
      }
    }
  }

  throw new Error(`Failed to fetch audio after ${retries} attempts: ${lastError?.message}`);
}

export async function generateWaveformData(audioUrl: string): Promise<number[]> {
  try {
    // Create AudioContext with more explicit type handling
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) {
      throw new Error('Web Audio API is not supported in this browser');
    }
    const audioContext = new AudioContextClass();
    
    // Fetch audio file with retry logic
    const arrayBuffer = await fetchWithRetry(audioUrl);
    
    // Decode audio data
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
    
    // Get waveform data from first channel
    const rawData = audioBuffer.getChannelData(0);
    
    // Sample size (100 points in the waveform)
    const blockSize = Math.floor(rawData.length / 100);
    const waveform: number[] = [];
    
    // Calculate the average amplitude for each block
    for (let i = 0; i < 100; i++) {
      const start = blockSize * i;
      const end = start + blockSize;
      let sum = 0;
      
      for (let j = start; j < end; j++) {
        sum += Math.abs(rawData[j]);
      }
      
      // Normalize value between 0 and 1
      waveform.push(sum / blockSize);
    }
    
    // Normalize values to maximum amplitude
    const maxAmplitude = Math.max(...waveform);
    return waveform.map(value => value / maxAmplitude);
    
  } catch (error) {
    console.error('Error generating waveform data:', error);
    // Return empty waveform in case of error
    return Array(100).fill(0);
  }
}