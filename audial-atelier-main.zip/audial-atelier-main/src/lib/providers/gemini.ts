import type { GeminiImageAnalysis } from "@/stores/useProjectStore";

export interface GeminiVisionOptions {
  apiKey: string;
  model: string;
  temperature?: number;
  topP?: number;
  maxOutputTokens?: number;
  mimeType?: string;
}

interface GeminiVisionPayload {
  description?: string;
  emotions?: string[] | string;
  style?: string[] | string;
  timing?: string;
  feeling?: string;
  colorPalette?: string[] | string;
  prompt?: string;
}

const DEFAULT_MAX_TOKENS = 1024;

export async function analyzeImageWithGemini(image: Blob, options: GeminiVisionOptions): Promise<GeminiImageAnalysis> {
  const {
    apiKey,
    model,
    temperature = 0.7,
    topP = 0.95,
    maxOutputTokens = DEFAULT_MAX_TOKENS,
    mimeType = image.type || "image/png",
  } = options;

  const targetMaxTokens =
    typeof maxOutputTokens === "number" && maxOutputTokens > 0 ? maxOutputTokens : DEFAULT_MAX_TOKENS;

  const base64Data = await blobToBase64(image);

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [
              {
                text: [
                  "You are assisting a music inspiration tool.",
                  "Analyze the attached image and respond with STRICT JSON (no markdown) using this schema:",
                  '{',
                  '  "description": string, // one vivid summary of what is happening in the image',
                  '  "emotions": string[],  // 2-5 primary feelings or moods evoked',
                  '  "style": string[],     // up to 4 stylistic descriptors (visual art or cinematic style)',
                  '  "timing": string,      // describe the time of day or temporal context briefly',
                  '  "feeling": string,     // single sentence capturing the overall vibe',
                  '  "colorPalette": string[], // 4-6 dominant HEX colors, uppercase, no extra text',
                  '  "prompt": string       // Creative text prompt (<= 3 sentences) to inspire music generation',
                  "}",
                  "Ensure the output is valid JSON. Do not include explanations or markdown.",
                ].join("\n"),
              },
              {
                inline_data: {
                  data: base64Data,
                  mime_type: mimeType,
                },
              },
            ],
          },
        ],
        generationConfig: {
          temperature,
          topP,
          maxOutputTokens: targetMaxTokens,
        },
      }),
    },
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Gemini API error: ${response.status} ${response.statusText} - ${errorText}`);
  }

  const data = await response.json();
  const textResponse = extractTextFromResponse(data);

  if (!textResponse) {
    throw new Error("Gemini API returned no analysis text");
  }

  const parsed = parseJsonPayload(textResponse);

  return normalizeAnalysis(parsed);
}

async function blobToBase64(blob: Blob): Promise<string> {
  const buffer = await blob.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  let binary = "";
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });
  return btoa(binary);
}

function extractTextFromResponse(response: any): string | null {
  const parts = response?.candidates?.[0]?.content?.parts;
  if (!Array.isArray(parts)) return null;

  for (const part of parts) {
    if (typeof part?.text === "string" && part.text.trim().length > 0) {
      return part.text.trim();
    }
  }
  return null;
}

function parseJsonPayload(raw: string): GeminiVisionPayload {
  try {
    return JSON.parse(raw);
  } catch {
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) {
      throw new Error("Gemini response could not be parsed as JSON");
    }
    try {
      return JSON.parse(match[0]);
    } catch (error) {
      throw new Error(`Gemini response JSON parse error: ${(error as Error).message}`);
    }
  }
}

function normalizeAnalysis(payload: GeminiVisionPayload): GeminiImageAnalysis {
  const toArray = (value: string[] | string | undefined): string[] => {
    if (Array.isArray(value)) {
      return value.map((entry) => entry.trim()).filter(Boolean);
    }
    if (typeof value === "string") {
      return value
        .split(/[,/]|(?:\band\b)/i)
        .map((entry) => entry.trim())
        .filter(Boolean);
    }
    return [];
  };

  const normalizeHex = (value: string): string => {
    const hexMatch = value.match(/[A-Fa-f0-9]{6}/);
    if (hexMatch) {
      return `#${hexMatch[0].toUpperCase()}`;
    }
    const hashHex = value.match(/#[A-Fa-f0-9]{6}/);
    if (hashHex) {
      return hashHex[0].toUpperCase();
    }
    return value.trim();
  };

  const description = (payload.description ?? "").trim();
  const emotions = toArray(payload.emotions);
  const style = toArray(payload.style);
  const timing = (payload.timing ?? "").trim();
  const feeling = (payload.feeling ?? "").trim();
  const prompt = (payload.prompt ?? description).trim();

  const colorPalette = toArray(payload.colorPalette)
    .map(normalizeHex)
    .filter((color) => /^#[0-9A-F]{6}$/.test(color));

  return {
    description: description || "Visual inspiration captured.",
    emotions,
    style,
    timing,
    feeling,
    colorPalette: colorPalette.length > 0 ? colorPalette : ["#6B7280"],
    prompt,
  };
}
