import { useApiStore } from '@/stores/useApiStore';

export interface UploadCoverParams {
  uploadUrl: string; // presigned URL to PUT the file
  prompt: string;
  style?: string;
  title?: string;
  customMode: boolean;
  instrumental: boolean;
  model: 'V3_5' | 'V4' | 'V4_5' | 'V4_5PLUS' | 'V5';
  negativeTags?: string;
  vocalGender?: 'm' | 'f';
  styleWeight?: number;
  weirdnessConstraint?: number;
  audioWeight?: number;
  callBackUrl?: string;
}

/**
 * Uploads a binary file (Blob/File) to a presigned uploadUrl (PUT).
 */
export async function uploadFileToUrl(uploadUrl: string, file: File | Blob): Promise<void> {
  const resp = await fetch(uploadUrl, {
    method: 'PUT',
    body: file,
    headers: {
      // Let the server infer content-type; some presigned urls require specific headers
    },
  });

  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`Upload failed: ${resp.status} ${text}`);
  }
}

/**
 * Calls Suno's upload-cover endpoint with provided params. Reads API key from store.
 */
export async function generateCoverFromUpload(params: UploadCoverParams): Promise<{ taskId: string }>{
  const store = useApiStore.getState();
  const apiKey = store.sunoApiKey;
  const baseUrl = store.sunoBaseUrl || 'https://api.sunoapi.org';
  const apiVersion = store.sunoApiVersion || 'v1';

  if (!apiKey) throw new Error('Suno API key not configured');

  const endpoint = `${baseUrl}/api/${apiVersion}/generate/upload-cover`;

  const resp = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify(params),
  });

  const data = await resp.json();
  if (!resp.ok) {
    throw new Error(data?.msg || `Suno API error: ${resp.status}`);
  }

  return { taskId: data?.data?.taskId };
}

export async function getSunoTaskStatus(taskId: string): Promise<any> {
  const store = useApiStore.getState();
  const apiKey = store.sunoApiKey;
  const baseUrl = store.sunoBaseUrl || 'https://api.sunoapi.org';
  const apiVersion = store.sunoApiVersion || 'v1';

  if (!apiKey) throw new Error('Suno API key not configured');

  // Best-effort status endpoint
  const endpoint = `${baseUrl}/api/${apiVersion}/generate/status?taskId=${encodeURIComponent(taskId)}`;
  const resp = await fetch(endpoint, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
    },
  });

  const data = await resp.json();
  if (!resp.ok) throw new Error(data?.msg || `Suno status error: ${resp.status}`);

  return data;
}
