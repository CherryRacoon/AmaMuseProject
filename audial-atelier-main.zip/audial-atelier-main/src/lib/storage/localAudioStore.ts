import localforage from 'localforage';

const store = localforage.createInstance({
  name: 'audial-atelier-audio',
});

export async function saveAudioBlob(blob: Blob): Promise<string> {
  const key = `audio-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  await store.setItem(key, blob);
  return key;
}

export async function getAudioBlob(key: string): Promise<Blob | null> {
  const item = await store.getItem<Blob | null>(key);
  return item ?? null;
}

export async function removeAudioBlob(key: string): Promise<void> {
  await store.removeItem(key);
}
