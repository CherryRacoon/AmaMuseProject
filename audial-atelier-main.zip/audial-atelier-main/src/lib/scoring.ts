
import { ProviderFeatures, RateReport, ScoreDimension } from '@/types/rating';
import { getDegradedSpotifyFeatures } from './providers/spotify';

const AMEI_THRESHOLDS = {
    'Publish-ready': 8.5,
    'Good but polish hooks': 7.0,
    'OK but not memorable': 5.5,
};

const POPULAR_BASELINE = {
    danceability: 0.65,
    energy: 0.7,
    valence: 0.5,
    tempo: 120,
    loudness: -8,
};

/**
 * Normalizes a value to a 0-10 scale.
 * @param value The input value.
 * @param min The expected minimum of the value.
 *p* @param max The expected maximum of the value.
 * @returns A number between 0 and 10.
 */
const normalize = (value: number, min: number, max: number): number => {
    const score = ((value - min) / (max - min)) * 10;
    return Math.max(0, Math.min(10, score));
};

/**
 * Calculates the Structure score.
 * Weights:
 * - 40% beat/downbeat stability
 * - 30% dynamic/loudness comfort
 * - 20% section–mood alignment
 * - 10% band-balance
 */
const scoreStructure = (features: ProviderFeatures): ScoreDimension => {
    const { soundstat, cyanite } = features;
    let score = 5; // Default score
    const tips: string[] = [];

    if (soundstat) {
        const beatScore = normalize(soundstat.beat_confidence, 0.5, 1.0);
        const dynamicScore = normalize(soundstat.dynamic_range, 8, 14);
        const loudnessScore = normalize(soundstat.loudness_integrated, -14, -7);
        const balanceScore = 10 - (Math.abs(soundstat.spectral_balance.bass - 0.5) + Math.abs(soundstat.spectral_balance.mid - 0.5) + Math.abs(soundstat.spectral_balance.treble - 0.5)) * 10;

        // Simplified section-mood alignment
        const sectionMoodScore = cyanite && cyanite.moodOverTime.length > 0 ? 7.5 : 5;

        score = beatScore * 0.4 + ((dynamicScore + loudnessScore) / 2) * 0.3 + sectionMoodScore * 0.2 + balanceScore * 0.1;
        
        if (beatScore < 6) tips.push("The beat isn't very stable. Consider quantizing or using a clearer rhythm.");
        if (dynamicScore < 5) tips.push("The track is overly compressed. Increase the dynamic range for more impact.");
        if (loudnessScore < 5) tips.push("The track is too quiet. Consider mastering to a competitive loudness level.");
    } else {
        tips.push("Structural analysis is limited without SoundStat data.");
    }

    return {
        score,
        explanation: "Structure evaluates the song's rhythmic stability, dynamic variation, and overall balance.",
        tips,
    };
};

/**
 * Calculates the Appeal score.
 * Weights:
 * - 40% energy/valence
 * - 30% hook delta (mood/movement peak near chorus)
 * - 30% groove consistency
 */
const scoreAppeal = (features: ProviderFeatures): ScoreDimension => {
    let { spotify, cyanite, soundstat } = features;
    let score = 5;
    const tips: string[] = [];

    if (!spotify && cyanite && soundstat) {
        spotify = getDegradedSpotifyFeatures(cyanite, soundstat);
    }

    if (spotify && soundstat) {
        const energyValenceScore = ((spotify.energy ?? 0.5) + (spotify.valence ?? 0.5)) / 2 * 10;
        
        // Simplified hook delta: peak movement value
        const hookDeltaScore = cyanite ? normalize(Math.max(...cyanite.movement.map(m => m.value)), 0.5, 1.0) : 5;
        const grooveScore = normalize(soundstat.beat_confidence, 0.5, 1.0);

        score = energyValenceScore * 0.4 + hookDeltaScore * 0.3 + grooveScore * 0.3;

        if (energyValenceScore < 6) tips.push("The song's energy and mood are a bit low. Try increasing the tempo or using brighter instruments.");
        if (hookDeltaScore < 7) tips.push("The chorus or main hook could be more impactful. Try to build more tension before it hits.");
    } else {
        tips.push("Appeal analysis is limited without Spotify or degraded feature data.");
    }

    return {
        score,
        explanation: "Appeal measures the song's emotional energy and rhythmic catchiness.",
        tips,
    };
};

/**
 * Calculates the Novelty score.
 * Weights:
 * - 50% tag-combo rarity
 * - 30% verse→chorus movement lift
 * - 20% rhythmic/harmonic atypicality
 */
const scoreNovelty = (features: ProviderFeatures): ScoreDimension => {
    const { cyanite } = features;
    let score = 5;
    const tips: string[] = [];

    if (cyanite) {
        const tagRarity = (cyanite.genres.length + cyanite.moods.length > 5) ? 8 : 4;
        const movementLift = normalize(Math.max(...cyanite.movement.map(m => m.value)) - Math.min(...cyanite.movement.map(m => m.value)), 0.3, 0.8);
        const atypicalityScore = 5; // Placeholder

        score = tagRarity * 0.5 + movementLift * 0.3 + atypicalityScore * 0.2;

        if (tagRarity < 6) tips.push("The genre and mood combination is quite common. Try blending in more unusual influences.");
    } else {
        tips.push("Novelty analysis requires Cyanite data.");
    }

    return {
        score,
        explanation: "Novelty assesses the uniqueness of the song's genre blend and dynamic shifts.",
        tips,
    };
};

/**
 * Calculates the Potential score.
 * Weights:
 * - 60% proximity to “popular cluster”
 * - 40% BPM/loudness coverage from comfort bands
 */
const scorePotential = (features: ProviderFeatures): ScoreDimension => {
    let { spotify, soundstat, cyanite } = features;
    let score = 5;
    const tips: string[] = [];

    if (!spotify && cyanite && soundstat) {
        spotify = getDegradedSpotifyFeatures(cyanite, soundstat);
    }

    if (spotify && soundstat) {
        const popularProximity = 10 - (
            Math.abs((spotify.energy ?? 0.5) - POPULAR_BASELINE.energy) +
            Math.abs((spotify.valence ?? 0.5) - POPULAR_BASELINE.valence)
        ) * 5;

        const bpmComfort = normalize(soundstat.tempo, 90, 140);
        const loudnessComfort = normalize(soundstat.loudness_integrated, -12, -7);

        score = popularProximity * 0.6 + ((bpmComfort + loudnessComfort) / 2) * 0.4;

        if (popularProximity < 6) tips.push("The song's vibe is outside of typical popular music. This can be good, but may limit mainstream appeal.");
        if (bpmComfort < 5 || loudnessComfort < 5) tips.push("The tempo or loudness is outside the typical 'comfort zone' for most listeners.");
    } else {
        tips.push("Potential analysis is limited without required provider data.");
    }

    return {
        score,
        explanation: "Potential estimates the song's mainstream appeal based on popular trends and listening comfort.",
        tips,
    };
};

/**
 * Generates a final conclusion based on the AMEI score.
 * @param ameiScore The final AMEI score.
 * @returns A conclusion string and a threshold category.
 */
const getConclusion = (ameiScore: number): { conclusion: string; threshold: RateReport['threshold'] } => {
    if (ameiScore >= AMEI_THRESHOLDS['Publish-ready']) {
        return {
            conclusion: "Exceptional work! This track has strong potential and is ready for an audience.",
            threshold: 'Publish-ready',
        };
    }
    if (ameiScore >= AMEI_THRESHOLDS['Good but polish hooks']) {
        return {
            conclusion: "This is a solid track. Focus on making the key moments (like the chorus) even more impactful.",
            threshold: 'Good but polish hooks',
        };
    }
    if (ameiScore >= AMEI_THRESHOLDS['OK but not memorable']) {
        return {
            conclusion: "A good start, but the track lacks a memorable hook or strong identity. Experiment with the structure and core ideas.",
            threshold: 'OK but not memorable',
        };
    }
    return {
        conclusion: "The fundamentals need work. Revisit the song's structure, rhythm, and core emotional message.",
        threshold: 'Rework structure/mix',
    };
};

/**
 * Analyzes a song's features from various providers and generates a comprehensive RateReport.
 *
 * @param features - An object containing feature data from Cyanite, SoundStat, and optionally Spotify.
 * @returns A `RateReport` object with scores for structure, appeal, novelty, and potential,
 *          along with an overall AMEI score and a final conclusion.
 */
export function scoreSong(features: ProviderFeatures): RateReport {
    const structure = scoreStructure(features);
    const appeal = scoreAppeal(features);
    const novelty = scoreNovelty(features);
    const potential = scorePotential(features);

    const ameiScore = (structure.score + appeal.score + novelty.score + potential.score) / 4;

    const { conclusion, threshold } = getConclusion(ameiScore);

    return {
        structure,
        appeal,
        novelty,
        potential,
        ameiScore,
        conclusion,
        threshold,
    };
}
