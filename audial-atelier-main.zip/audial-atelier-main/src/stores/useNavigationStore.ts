import { create } from "zustand";
import { persist } from "zustand/middleware";

export type WorkflowPhase = "dashboard" | "input" | "refine" | "generating" | "rating" | "editing" | "complete";
export type NavigationMethod = "click" | "shortcut" | "programmatic";

interface NavigationHistoryEntry {
  route: string;
  timestamp: Date;
}

interface NavigationStore {
  currentRoute: string;
  navigationHistory: NavigationHistoryEntry[];
  workflowPhase: WorkflowPhase;
  hasUnsavedChanges: boolean;
  generationInProgress: boolean;
  lastVisitedRoute: string | null;
  sidebarCollapsed: boolean;
  
  // Actions
  setCurrentRoute: (route: string) => void;
  addToHistory: (route: string) => void;
  setWorkflowPhase: (phase: WorkflowPhase) => void;
  setUnsavedChanges: (value: boolean) => void;
  setGenerationInProgress: (value: boolean) => void;
  setLastVisitedRoute: (route: string) => void;
  toggleSidebar: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
}

export const useNavigationStore = create<NavigationStore>()(
  persist(
    (set) => ({
      currentRoute: "/",
      navigationHistory: [],
      workflowPhase: "dashboard",
      hasUnsavedChanges: false,
      generationInProgress: false,
      lastVisitedRoute: null,
      sidebarCollapsed: false,
      
      setCurrentRoute: (route) =>
        set({ currentRoute: route }),
      
      addToHistory: (route) =>
        set((state) => ({
          navigationHistory: [
            ...state.navigationHistory,
            { route, timestamp: new Date() }
          ].slice(-10), // Keep last 10
        })),
      
      setWorkflowPhase: (phase) =>
        set({ workflowPhase: phase }),
      
      setUnsavedChanges: (value) =>
        set({ hasUnsavedChanges: value }),
      
      setGenerationInProgress: (value) =>
        set({ generationInProgress: value }),
      
      setLastVisitedRoute: (route) =>
        set({ lastVisitedRoute: route }),
      
      toggleSidebar: () =>
        set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
      
      setSidebarCollapsed: (collapsed) =>
        set({ sidebarCollapsed: collapsed }),
    }),
    {
      name: "navigation-storage",
      partialize: (state) => ({
        lastVisitedRoute: state.lastVisitedRoute,
        sidebarCollapsed: state.sidebarCollapsed,
      }),
    }
  )
);
