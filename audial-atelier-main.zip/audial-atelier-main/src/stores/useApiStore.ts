import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ApiStore {
  sunoApiKey: string | null;
  sunoBaseUrl: string;
  sunoApiVersion: string;
  geminiApiKey: string | null;
  geminiModel: string;
  geminiTemperature: number;
  geminiTopP: number;
  geminiMaxOutputTokens: number;
  setSunoApiKey: (key: string | null) => void;
  setSunoBaseUrl: (url: string) => void;
  setSunoApiVersion: (v: string) => void;
  setGeminiApiKey: (key: string | null) => void;
  setGeminiModel: (model: string) => void;
  setGeminiTemperature: (temp: number) => void;
  setGeminiTopP: (value: number) => void;
  setGeminiMaxOutputTokens: (tokens: number) => void;
}

export const useApiStore = create<ApiStore>()(
  persist(
    (set) => ({
      sunoApiKey: null,
      sunoBaseUrl: 'https://api.sunoapi.org',
      sunoApiVersion: 'v1',
      geminiApiKey: null,
      geminiModel: 'gemini-2.5-flash',
      geminiTemperature: 0.7,
      geminiTopP: 0.95,
      geminiMaxOutputTokens: 2048,
      setSunoApiKey: (key) => set({ sunoApiKey: key }),
      setSunoBaseUrl: (url) => set({ sunoBaseUrl: url }),
      setSunoApiVersion: (v) => set({ sunoApiVersion: v }),
      setGeminiApiKey: (key) => set({ geminiApiKey: key }),
      setGeminiModel: (model) => set({ geminiModel: model }),
      setGeminiTemperature: (temp) => set({ geminiTemperature: temp }),
      setGeminiTopP: (value) => set({ geminiTopP: value }),
      setGeminiMaxOutputTokens: (tokens) => set({ geminiMaxOutputTokens: tokens }),
    }),
    { name: 'api-store' }
  )
);
