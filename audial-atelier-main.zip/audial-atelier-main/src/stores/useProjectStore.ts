import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface AudioInput {
  type: "recording" | "upload" | "youtube";
  file?: File;
  url?: string;
  duration?: number;
  waveformData?: number[];
  // Optional selection within the audio (seconds)
  start?: number;
  end?: number;
  // Optional reference to a blob stored in IndexedDB
  blobKey?: string;
}

export interface TextPrompt {
  text: string;
  mood: string[];
  genre: string;
  tempo: "slow" | "medium" | "fast";
  style: string;
}

export interface PromptVersion {
  id: string;
  prompt: string;
  instruments?: string[];
  emotions?: string[];
  tempo?: number;
  vocalType?: string;
  createdAt: string; // ISO timestamp
  rating?: number;
  note?: string;
}

export interface LyricsData {
  content: string;
  structure: { type: "verse" | "chorus"; text: string }[];
}

export interface GeminiImageAnalysis {
  description: string;
  emotions: string[];
  style: string[];
  timing: string;
  feeling: string;
  colorPalette: string[];
  prompt: string;
}

export interface ImageInspiration {
  file?: File;
  url?: string;
  extractedPrompt?: string;
  colors?: string[];
  analysis?: GeminiImageAnalysis;
  analyzedAt?: string;
}

export interface AnalysisMetadata {
  key?: string;
  bpm?: number;
  mood?: string[];
  confidence?: number;
}

export interface PromptRefinement {
  enhancedPrompt: string;
  instruments: string[];
  vocalType: string;
  emotions: string[];
  structure: string[];
  negativePrompt: string;
  seed?: number;
  sampleCount: number;
}

export interface GeneratedVersion {
  id: string;
  audioUrl: string;
  duration: number;
  waveformData: number[];
  timestamp: Date;
}

export interface EffectInstance {
  id: string;
  type: string;
  bypass: boolean;
  wet: number;
  params: Record<string, number>;
  order: number;
}

export interface Track {
  id: string;
  name: string;
  type: "vocals" | "drums" | "bass" | "melody" | "harmony" | "full";
  audioUrl: string;
  volume: number;
  pan: number;
  muted: boolean;
  soloed: boolean;
  color: string;
  effects?: EffectInstance[];
}

export interface Project {
  id: string;
  name: string;
  createdAt: Date;
  updatedAt: Date;
  phase: "input" | "refine" | "generating" | "editing" | "complete";
  
  // Phase 1: Multi-modal Input
  audioInput?: AudioInput;
  textPrompt?: TextPrompt;
  lyrics?: LyricsData;
  imageInspiration?: ImageInspiration;
  analysisMetadata?: AnalysisMetadata;
  
  // Phase 2: Refinement
  refinement?: PromptRefinement;
  promptVersions: PromptVersion[];
  
  // Phase 3: Generation
  generationStatus?: {
    stage: "validating" | "initializing" | "generating" | "postprocessing" | "ready";
    progress: number;
    taskId?: string;
    error?: string;
  };
  generatedVersions: GeneratedVersion[];
  selectedVersionId?: string;
  
  // Phase 4: Editing
  tracks: Track[];
  
  // Phase 5: Export
  exportSettings?: {
    format: "mp3" | "wav" | "flac";
    quality: "high" | "medium" | "low";
    includeStems: boolean;
  };
  
  // Add effect chains per track (by track id)
  effectChains?: Record<string, EffectInstance[]>;
}

interface ProjectStore {
  projects: Project[];
  currentProject: Project | null;
  
  // Project Management
  createProject: (name: string) => string;
  getProject: (id: string) => Project | undefined;
  setCurrentProject: (id: string) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  
  // Phase Updates
  updateAudioInput: (projectId: string, audio: AudioInput) => void;
  updateTextPrompt: (projectId: string, prompt: TextPrompt) => void;
  updateLyrics: (projectId: string, lyrics: LyricsData) => void;
  updateImageInspiration: (projectId: string, image: ImageInspiration) => void;
  updateAnalysis: (projectId: string, metadata: AnalysisMetadata) => void;
  updateRefinement: (projectId: string, refinement: Partial<PromptRefinement>) => void;
  addPromptVersion: (projectId: string, prompt: PromptVersion | string) => void;
  updateGenerationStatus: (projectId: string, status: Partial<Project["generationStatus"]>) => void;
  addGeneratedVersion: (projectId: string, version: GeneratedVersion) => void;
  selectVersion: (projectId: string, versionId: string) => void;
  updateTracks: (projectId: string, tracks: Track[]) => void;
  updateTrack: (projectId: string, trackId: string, updates: Partial<Track>) => void;
  
  // Effect Management
  addEffectToTrack: (projectId: string, trackId: string, effect: EffectInstance) => void;
  removeEffectFromTrack: (projectId: string, trackId: string, effectId: string) => void;
  updateEffectParams: (projectId: string, trackId: string, effectId: string, params: Record<string, number>) => void;
  reorderEffects: (projectId: string, trackId: string, newOrder: EffectInstance[]) => void;
  toggleEffectBypass: (projectId: string, trackId: string, effectId: string) => void;
  setEffectWet: (projectId: string, trackId: string, effectId: string, wet: number) => void;
}

const migrateProject = (project: Project): Project => {
  // Ensure effectChains exists for all tracks
  if (!project.effectChains) {
    const effectChains: Record<string, EffectInstance[]> = {};
    for (const track of project.tracks) {
      effectChains[track.id] = [];
    }
    return { ...project, effectChains };
  }
  return project;
};

export const useProjectStore = create<ProjectStore>((set, get) => ({
  projects: [],
  currentProject: null,
  
  createProject: (name: string) => {
    const id = `project-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const newProject: Project = {
      id,
      name,
      createdAt: new Date(),
      updatedAt: new Date(),
      phase: "input",
      promptVersions: [],
      generatedVersions: [],
      tracks: [],
    };
    
    set((state) => ({
      projects: [...state.projects, newProject],
      currentProject: newProject,
    }));
    
    return id;
  },
  
  getProject: (id: string) => {
    return get().projects.find((p) => p.id === id);
  },
  
  setCurrentProject: (id: string) => {
    const project = get().projects.find((p) => p.id === id);
    if (project) {
      set({ currentProject: project });
    }
  },
  
  updateProject: (id: string, updates: Partial<Project>) => {
    set((state) => ({
      projects: state.projects.map((p) =>
        p.id === id ? { ...p, ...updates, updatedAt: new Date() } : p
      ),
      currentProject:
        state.currentProject?.id === id
          ? { ...state.currentProject, ...updates, updatedAt: new Date() }
          : state.currentProject,
    }));
  },
  
  deleteProject: (id: string) => {
    set((state) => ({
      projects: state.projects.filter((p) => p.id !== id),
      currentProject: state.currentProject?.id === id ? null : state.currentProject,
    }));
  },
  
  updateAudioInput: (projectId: string, audio: AudioInput) => {
    get().updateProject(projectId, { audioInput: audio });
  },
  
  updateTextPrompt: (projectId: string, prompt: TextPrompt) => {
    get().updateProject(projectId, { textPrompt: prompt });
  },
  
  updateLyrics: (projectId: string, lyrics: LyricsData) => {
    get().updateProject(projectId, { lyrics });
  },
  
  updateImageInspiration: (projectId: string, image: ImageInspiration) => {
    get().updateProject(projectId, { imageInspiration: image });
  },
  
  updateAnalysis: (projectId: string, metadata: AnalysisMetadata) => {
    get().updateProject(projectId, { analysisMetadata: metadata });
  },
  
  updateRefinement: (projectId: string, refinement: Partial<PromptRefinement>) => {
    const project = get().getProject(projectId);
    if (project) {
      get().updateProject(projectId, {
        refinement: { ...project.refinement, ...refinement } as PromptRefinement,
      });
    }
  },
  
  addPromptVersion: (projectId: string, prompt: PromptVersion | string) => {
    const project = get().getProject(projectId);
    if (!project) return;

    const versionObj: PromptVersion =
      typeof prompt === "string"
        ? {
            id: `v-${Date.now()}`,
            prompt,
            instruments: project.refinement?.instruments || [],
            emotions: project.refinement?.emotions || [],
            tempo: undefined,
            vocalType: project.refinement?.vocalType,
            createdAt: new Date().toISOString(),
          }
        : prompt;

    get().updateProject(projectId, {
      promptVersions: [...project.promptVersions, versionObj],
    });
  },
  
  updateGenerationStatus: (projectId: string, status: Partial<Project["generationStatus"]>) => {
    const project = get().getProject(projectId);
    if (project) {
      get().updateProject(projectId, {
        generationStatus: { ...project.generationStatus, ...status } as Project["generationStatus"],
      });
    }
  },
  
  addGeneratedVersion: (projectId: string, version: GeneratedVersion) => {
    const project = get().getProject(projectId);
    if (project) {
      get().updateProject(projectId, {
        generatedVersions: [...project.generatedVersions, version],
      });
    }
  },
  
  selectVersion: (projectId: string, versionId: string) => {
    get().updateProject(projectId, { selectedVersionId: versionId });
  },
  
  updateTracks: (projectId: string, tracks: Track[]) => {
    get().updateProject(projectId, { tracks });
  },
  
  updateTrack: (projectId: string, trackId: string, updates: Partial<Track>) => {
    const project = get().getProject(projectId);
    if (project) {
      get().updateProject(projectId, {
        tracks: project.tracks.map((t) => (t.id === trackId ? { ...t, ...updates } : t)),
      });
    }
  },
  
  addEffectToTrack: (projectId: string, trackId: string, effect: EffectInstance) => {
    set(state => {
      const project = state.projects[projectId];
      if (!project) return state;
      const effectChains = { ...project.effectChains };
      effectChains[trackId] = [...(effectChains[trackId] || []), effect];
      return {
        ...state,
        projects: {
          ...state.projects,
          [projectId]: { ...project, effectChains }
        }
      };
    });
  },
  removeEffectFromTrack: (projectId: string, trackId: string, effectId: string) => {
    set(state => {
      const project = state.projects[projectId];
      if (!project) return state;
      const effectChains = { ...project.effectChains };
      effectChains[trackId] = (effectChains[trackId] || []).filter(e => e.id !== effectId);
      return {
        ...state,
        projects: {
          ...state.projects,
          [projectId]: { ...project, effectChains }
        }
      };
    });
  },
  updateEffectParams: (projectId: string, trackId: string, effectId: string, params: Record<string, number>) => {
    set(state => {
      const project = state.projects[projectId];
      if (!project) return state;
      const effectChains = { ...project.effectChains };
      effectChains[trackId] = (effectChains[trackId] || []).map(e =>
        e.id === effectId ? { ...e, params: { ...e.params, ...params } } : e
      );
      return {
        ...state,
        projects: {
          ...state.projects,
          [projectId]: { ...project, effectChains }
        }
      };
    });
  },
  reorderEffects: (projectId: string, trackId: string, newOrder: EffectInstance[]) => {
    set(state => {
      const project = state.projects[projectId];
      if (!project) return state;
      const effectChains = { ...project.effectChains };
      effectChains[trackId] = newOrder;
      return {
        ...state,
        projects: {
          ...state.projects,
          [projectId]: { ...project, effectChains }
        }
      };
    });
  },
  toggleEffectBypass: (projectId: string, trackId: string, effectId: string) => {
    set(state => {
      const project = state.projects[projectId];
      if (!project) return state;
      const effectChains = { ...project.effectChains };
      effectChains[trackId] = (effectChains[trackId] || []).map(e =>
        e.id === effectId ? { ...e, bypass: !e.bypass } : e
      );
      return {
        ...state,
        projects: {
          ...state.projects,
          [projectId]: { ...project, effectChains }
        }
      };
    });
  },
  setEffectWet: (projectId: string, trackId: string, effectId: string, wet: number) => {
    set(state => {
      const project = state.projects[projectId];
      if (!project) return state;
      const effectChains = { ...project.effectChains };
      effectChains[trackId] = (effectChains[trackId] || []).map(e =>
        e.id === effectId ? { ...e, wet } : e
      );
      return {
        ...state,
        projects: {
          ...state.projects,
          [projectId]: { ...project, effectChains }
        }
      };
    });
  },
}));
