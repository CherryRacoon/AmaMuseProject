import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { NavigationShell } from "@/components/navigation/NavigationShell";
import Index from "./pages/Index";
import CreateProject from "./pages/CreateProject";
import Refine from "./pages/Refine";
import Generate from "./pages/Generate";
import Edit from "./pages/Edit";
import Export from "./pages/Export";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";
import RatePage from "./pages/Rate";
import EditEffects from "./pages/EditEffects";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <NavigationShell>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/create" element={<CreateProject />} />
            <Route path="/refine" element={<Refine />} />
            <Route path="/generate" element={<Generate />} />
            <Route path="/rate" element={<RatePage />} />
            <Route path="/edit" element={<Edit />} />
            <Route path="/edit/effects" element={<EditEffects />} />
            <Route path="/export" element={<Export />} />
            <Route path="/settings" element={<Settings />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </NavigationShell>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
