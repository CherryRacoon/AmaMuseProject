import axios from 'axios';

interface ACEStepConfig {
  checkpointPath: string;
  audioDuration: number;
  prompt: string;
  lyrics?: string;
  inferStep: number;
  guidanceScale: number;
  schedulerType: string;
  cfgType: string;
  omegaScale: number;
  actualSeeds: number[];
  guidanceInterval: number;
  guidanceIntervalDecay: number;
  minGuidanceScale: number;
  useErgTag: boolean;
  useErgLyric: boolean;
  useErgDiffusion: boolean;
  ossSteps: number[];
  guidanceScaleText: number;
  guidanceScaleLyric: number;
}

interface GenerationStatus {
  state: 'pending' | 'processing' | 'completed' | 'failed';
  progress?: number;
  error?: string;
  outputUrl?: string;
}

class ACEStepService {
  private apiUrl: string;
  private defaultConfig: Partial<ACEStepConfig>;

  constructor() {
    this.apiUrl = import.meta.env.VITE_ACESTEP_API_URL || 'http://localhost:8000';
    this.defaultConfig = {
      inferStep: 20,
      guidanceScale: 7.5,
      schedulerType: 'flowmatch_euler',
      cfgType: 'tag',
      omegaScale: 0.0,
      guidanceInterval: 1.0,
      guidanceIntervalDecay: 1.0,
      minGuidanceScale: 1.0,
      useErgTag: true,
      useErgLyric: true,
      useErgDiffusion: false,
      ossSteps: [5, 10, 15],
      guidanceScaleText: 7.5,
      guidanceScaleLyric: 7.5,
    };
  }

  /**
   * Start music generation using ACE-Step
   * @param config Configuration parameters for generation
   * @returns Task ID for tracking generation progress
   */
  private async retryRequest<T>(
    requestFn: () => Promise<T>,
    retries: number = 3,
    delay: number = 1000
  ): Promise<T> {
    let lastError: any;
    
    for (let i = 0; i < retries; i++) {
      try {
        return await requestFn();
      } catch (error: any) {
        lastError = error;
        
        // Check if it's a network error or 5xx server error
        const isNetworkError = !error.response;
        const isServerError = error.response?.status >= 500;
        
        if (!isNetworkError && !isServerError) {
          // If it's a different type of error (e.g., 400), don't retry
          throw error;
        }
        
        // On last retry, throw the error
        if (i === retries - 1) {
          throw new Error(
            `Request failed after ${retries} retries: ${error.message || 'Network error'}`
          );
        }
        
        // Wait before retrying
        await new Promise(resolve => setTimeout(resolve, delay * Math.pow(2, i)));
      }
    }
    
    throw lastError;
  }

  async generateMusic(config: Partial<ACEStepConfig>): Promise<string> {
    try {
      // Merge with default config
      const fullConfig = {
        ...this.defaultConfig,
        ...config,
      };

      // Make request to ACE-Step API with retry logic
      const response = await this.retryRequest(
        () => axios.post(`${this.apiUrl}/generate`, fullConfig, {
          headers: {
            'Content-Type': 'application/json',
          },
          timeout: 30000, // 30 second timeout
        })
      );

      if (response.data.status === 'success' && response.data.taskId) {
        return response.data.taskId;
      }

      throw new Error(response.data.message || 'Failed to start generation');
    } catch (error: any) {
      if (axios.isAxiosError(error)) {
        if (!error.response) {
          throw new Error('Network error: Unable to reach the ACE-Step API. Please check your internet connection.');
        }
        if (error.code === 'ECONNABORTED') {
          throw new Error('Request timed out. The server is taking too long to respond.');
        }
        if (error.response.status === 429) {
          throw new Error('Too many requests. Please wait a moment before trying again.');
        }
        if (error.response.status >= 500) {
          throw new Error('The ACE-Step service is currently experiencing issues. Please try again later.');
        }
      }
      console.error('ACE-Step generation error:', error);
      throw error;
    }
  }

  /**
   * Check the status of a generation task
   * @param taskId The ID of the generation task
   * @returns Current status of the generation
   */
  async checkGenerationStatus(taskId: string): Promise<GenerationStatus> {
    try {
      const response = await this.retryRequest(
        () => axios.get(`${this.apiUrl}/status/${taskId}`, {
          timeout: 10000, // 10 second timeout for status checks
        })
      );
      return response.data;
    } catch (error: any) {
      if (axios.isAxiosError(error)) {
        if (!error.response) {
          throw new Error('Network error: Unable to check generation status. Please check your connection.');
        }
        if (error.code === 'ECONNABORTED') {
          throw new Error('Status check timed out. The server is taking too long to respond.');
        }
      }
      console.error('Error checking generation status:', error);
      throw error;
    }
  }

  /**
   * Download the generated audio file
   * @param taskId The ID of the completed generation task
   * @returns URL of the generated audio file
   */
  async downloadGeneratedAudio(taskId: string): Promise<string> {
    try {
      const response = await this.retryRequest(
        () => axios.get(`${this.apiUrl}/download/${taskId}`, {
          timeout: 60000, // 60 second timeout for downloads
        })
      );
      
      if (response.data.url) {
        // Verify the URL is accessible
        try {
          const urlCheckResponse = await this.retryRequest(
            () => axios.head(response.data.url, { timeout: 5000 })
          );
          if (urlCheckResponse.status === 200) {
            return response.data.url;
          }
        } catch (urlError) {
          throw new Error('Generated audio file is not accessible');
        }
      }
      
      throw new Error('No download URL available');
    } catch (error: any) {
      if (axios.isAxiosError(error)) {
        if (!error.response) {
          throw new Error('Network error: Unable to download the generated audio. Please check your connection.');
        }
        if (error.code === 'ECONNABORTED') {
          throw new Error('Download timed out. The server is taking too long to respond.');
        }
      }
      console.error('Error downloading generated audio:', error);
      throw error;
    }
  }

  /**
   * Get default configuration parameters
   */
  getDefaultConfig(): Partial<ACEStepConfig> {
    return { ...this.defaultConfig };
  }
}

export const aceStepService = new ACEStepService();