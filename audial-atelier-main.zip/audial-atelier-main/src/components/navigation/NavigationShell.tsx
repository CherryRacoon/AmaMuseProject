import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { DesktopSidebar } from "./DesktopSidebar";
import { MobileNavigation } from "./MobileNavigation";
import { UnsavedChangesModal } from "./UnsavedChangesModal";
import { useNavigationStore } from "@/stores/useNavigationStore";
import { useNavigationGuard } from "@/hooks/useNavigationGuard";
import { useKeyboardShortcuts } from "@/hooks/useKeyboardShortcuts";
import { useDebugLog } from "@/hooks/useDebugLog";
import { DebugConsole } from "@/components/DebugConsole";
import { Home, Music, Wand2, Zap, Sliders, Share2, Settings, Star } from "lucide-react";
import { AIChatAssistantButton } from "@/components/AIChatAssistantButton";

const navigationItems = [
  {
    id: "dashboard",
    label: "Projects",
    icon: Home,
    route: "/",
    shortcut: "Ctrl+1",
    requiresProject: false,
    phase: null,
    description: "View all projects",
  },
  {
    id: "create",
    label: "Capture",
    icon: Music,
    route: "/create",
    shortcut: "Ctrl+2",
    requiresProject: true,
    phase: "input",
    description: "Multi-modal input",
  },
  {
    id: "refine",
    label: "Refine",
    icon: Wand2,
    route: "/refine",
    shortcut: "Ctrl+3",
    requiresProject: true,
    requiresInput: true,
    phase: "refine",
    description: "AI-assisted prompt",
  },
  {
    id: "generate",
    label: "Generate",
    icon: Zap,
    route: "/generate",
    shortcut: "Ctrl+4",
    requiresProject: true,
    requiresRefinedPrompt: true,
    phase: "generating",
    description: "Monitor generation",
  },
  {
    id: "rate",
    label: "Rate",
    icon: Star,
    route: "/rate",
    shortcut: "Ctrl+5",
    requiresProject: true,
    requiresGeneratedAudio: true,
    phase: "rating",
    description: "Evaluate generated song",
  },
  {
    id: "edit",
    label: "Edit",
    icon: Sliders,
    route: "/edit",
    shortcut: "Ctrl+6",
    requiresProject: true,
    requiresGeneratedAudio: true,
    phase: "editing",
    description: "Multi-track editor",
  },
  {
    id: "export",
    label: "Export",
    icon: Share2,
    route: "/export",
    shortcut: "Ctrl+7",
    requiresProject: true,
    requiresFinalizedAudio: true,
    phase: "complete",
    description: "Export and share",
  },
  {
    id: "settings",
    label: "Settings",
    icon: Settings,
    route: "/settings",
    shortcut: "Ctrl+,",
    requiresProject: false,
    phase: null,
    description: "API configuration",
  },
];

interface NavigationShellProps {
  children: React.ReactNode;
}

export const NavigationShell = ({ children }: NavigationShellProps) => {
  const location = useLocation();
  const { setCurrentRoute, setLastVisitedRoute, lastVisitedRoute, setUnsavedChanges } = useNavigationStore();
  const { showUnsavedModal, confirmNavigation, cancelNavigation, requestNavigation } = useNavigationGuard();
  const { addLog } = useDebugLog();
  const [debugOpen, setDebugOpen] = useState(false);

  // Update current route on location change
  useEffect(() => {
    // Only update if the route has actually changed
    const currentRoute = location.pathname;
    if (currentRoute !== lastVisitedRoute) {
      setCurrentRoute(currentRoute);
      setLastVisitedRoute(currentRoute);

      addLog("INFO", "System", "Route Changed", `Current route: ${currentRoute}`, {
        route: currentRoute,
      });
    }
  }, [location.pathname, lastVisitedRoute, setCurrentRoute, setLastVisitedRoute, addLog]);

  // Session restoration
  useEffect(() => {
    if (lastVisitedRoute && lastVisitedRoute !== location.pathname) {
      addLog("INFO", "System", "Session Restoration", `Attempting to restore last route: ${lastVisitedRoute}`, {
        lastRoute: lastVisitedRoute,
        currentRoute: location.pathname,
      });
    }
  }, [lastVisitedRoute, location.pathname, addLog]);

  // Keyboard shortcuts
  useKeyboardShortcuts({
    navigationItems,
    onNavigate: (route, shortcut) => requestNavigation(route, "shortcut", shortcut),
    onToggleDebug: () => setDebugOpen(!debugOpen),
    onSave: () => {
      setUnsavedChanges(false);
      addLog("INFO", "System", "Manual Save", "User saved work via Ctrl+S");
    },
  });

  return (
    <div className="min-h-screen flex w-full bg-background">
      {/* Desktop Sidebar */}
      <DesktopSidebar onDebugToggle={() => setDebugOpen(!debugOpen)} />

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {children}
      </main>

      {/* Mobile Navigation */}
      <MobileNavigation onDebugToggle={() => setDebugOpen(!debugOpen)} />

      {/* Unsaved Changes Modal */}
      <UnsavedChangesModal
        open={showUnsavedModal}
        onConfirm={confirmNavigation}
        onCancel={cancelNavigation}
      />

      {/* Debug Console */}
      <DebugConsole open={debugOpen} onOpenChange={setDebugOpen} />

      <AIChatAssistantButton />
    </div>
  );
};
