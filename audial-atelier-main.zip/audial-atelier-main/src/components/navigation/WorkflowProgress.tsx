import { CheckCircle, Circle } from "lucide-react";
import { cn } from "@/lib/utils";
import { WorkflowPhase } from "@/stores/useNavigationStore";

interface WorkflowStep {
  id: WorkflowPhase;
  label: string;
}

const workflowSteps: WorkflowStep[] = [
  { id: "dashboard", label: "Projects" },
  { id: "input", label: "Capture" },
  { id: "refine", label: "Refine" },
  { id: "generating", label: "Generate" },
  { id: "rating", label: "Rate" },
  { id: "editing", label: "Edit" },
  { id: "complete", label: "Export" },
];

interface WorkflowProgressProps {
  currentPhase: WorkflowPhase;
  completedPhases: WorkflowPhase[];
  collapsed?: boolean;
}

export const WorkflowProgress = ({
  currentPhase,
  completedPhases,
  collapsed = false,
}: WorkflowProgressProps) => {
  const currentIndex = workflowSteps.findIndex((step) => step.id === currentPhase);

  return (
    <div className="space-y-1">
      {!collapsed && (
        <p className="text-xs text-muted-foreground px-4 mb-3">Workflow Progress</p>
      )}
      
      {workflowSteps.map((step, index) => {
        const isComplete = completedPhases.includes(step.id);
        const isCurrent = step.id === currentPhase;
        const isUpcoming = index > currentIndex;

        return (
          <div
            key={step.id}
            className={cn(
              "flex items-center gap-3 px-4 py-2",
              collapsed && "justify-center"
            )}
          >
            <div className="relative">
              {isComplete ? (
                <CheckCircle className="w-4 h-4 text-success" />
              ) : (
                <Circle
                  className={cn(
                    "w-4 h-4",
                    isCurrent && "text-primary animate-pulse",
                    isUpcoming && "text-muted-foreground opacity-40"
                  )}
                />
              )}
              
              {isCurrent && (
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full animate-pulse" />
              )}
            </div>
            
            {!collapsed && (
              <span
                className={cn(
                  "text-xs transition-colors",
                  isComplete && "text-success line-through",
                  isCurrent && "text-primary font-medium",
                  isUpcoming && "text-muted-foreground opacity-40"
                )}
              >
                {step.label}
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
};
