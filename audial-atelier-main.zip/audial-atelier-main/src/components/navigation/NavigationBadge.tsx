import { cn } from "@/lib/utils";

interface NavigationBadgeProps {
  type: string;
  className?: string;
}

export const NavigationBadge = ({ type, className }: NavigationBadgeProps) => {
  if (!type) return null;

  return (
    <span
      className={cn(
        "absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full",
        type === "in-progress" && "bg-accent animate-pulse",
        type === "error" && "bg-destructive",
        type === "complete" && "bg-success",
        className
      )}
      aria-label={`Status: ${type}`}
    />
  );
};
