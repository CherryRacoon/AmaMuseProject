import { Home, Music, Wand2, Zap, Sliders, Share2, Settings, ChevronLeft, ChevronRight, Bug, Star, LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { NavigationItem } from "./NavigationItem";
import { WorkflowProgress } from "./WorkflowProgress";
import { useNavigationStore, WorkflowPhase } from "@/stores/useNavigationStore";
import { useProjectStore } from "@/stores/useProjectStore";
import { useNavigationGuard } from "@/hooks/useNavigationGuard";
import { cn } from "@/lib/utils";

interface NavItem {
  id: string;
  label: string;
  icon: LucideIcon;
  route: string;
  shortcut: string;
  requiresProject: boolean;
  requiresInput?: boolean;
  requiresRefinedPrompt?: boolean;
  requiresGeneratedAudio?: boolean;
  requiresFinalizedAudio?: boolean;
  phase: string | null;
  description: string;
}

const navigationItems: NavItem[] = [
  {
    id: "dashboard",
    label: "Projects",
    icon: Home,
    route: "/",
    shortcut: "Ctrl+1",
    requiresProject: false,
    phase: null,
    description: "View all projects and recent activity",
  },
  {
    id: "create",
    label: "Capture",
    icon: Music,
    route: "/create",
    shortcut: "Ctrl+2",
    requiresProject: true,
    phase: "input",
    description: "Multi-modal input: audio, text, lyrics, images",
  },
  {
    id: "refine",
    label: "Refine",
    icon: Wand2,
    route: "/refine",
    shortcut: "Ctrl+3",
    requiresProject: true,
    requiresInput: true,
    phase: "refine",
    description: "AI-assisted prompt enhancement and structuring",
  },
  {
    id: "generate",
    label: "Generate",
    icon: Zap,
    route: "/generate",
    shortcut: "Ctrl+4",
    requiresProject: true,
    requiresRefinedPrompt: true,
    phase: "generating",
    description: "Monitor music generation progress",
  },
  {
    id: "rate",
    label: "Rate",
    icon: Star,
    route: "/rate",
    shortcut: "Ctrl+5",
    requiresProject: true,
    requiresGeneratedAudio: true,
    phase: "rating",
    description: "Evaluate generated song",
  },
  {
    id: "edit",
    label: "Edit",
    icon: Sliders,
    route: "/edit",
    shortcut: "Ctrl+6",
    requiresProject: true,
    requiresGeneratedAudio: true,
    phase: "editing",
    description: "DAW-style multi-track editor with stems",
  },
  {
    id: "export",
    label: "Export",
    icon: Share2,
    route: "/export",
    shortcut: "Ctrl+7",
    requiresProject: true,
    requiresFinalizedAudio: true,
    phase: "complete",
    description: "Export audio, sheet music, and share socially",
  },
  {
    id: "settings",
    label: "API Settings",
    icon: Settings,
    route: "/settings",
    shortcut: "Ctrl+,",
    requiresProject: false,
    phase: null,
    description: "Configure Gemini, Lyria, and Suno APIs",
  },
];

interface DesktopSidebarProps {
  onDebugToggle: () => void;
}

export const DesktopSidebar = ({ onDebugToggle }: DesktopSidebarProps) => {
  const {
    sidebarCollapsed,
    toggleSidebar,
    workflowPhase,
    generationInProgress,
    currentRoute,
  } = useNavigationStore();
  const { currentProject } = useProjectStore();
  const { canNavigateTo, requestNavigation } = useNavigationGuard();

  const completedPhases: WorkflowPhase[] = [];
  if (currentProject?.audioInput || currentProject?.textPrompt || currentProject?.lyrics) {
    completedPhases.push("input");
  }
  if (currentProject?.refinement) {
    completedPhases.push("refine");
  }
  if (currentProject?.generatedVersions.length > 0) {
    completedPhases.push("generating");
  }
  if (currentProject?.tracks.length > 0) {
    completedPhases.push("editing");
  }

  const showWorkflowProgress = currentRoute !== "/settings";

  return (
    <aside
      className={cn(
        "hidden lg:flex flex-col border-r border-border bg-sidebar-background transition-all duration-300",
        sidebarCollapsed ? "w-[72px]" : "w-60"
      )}
    >
      {/* Logo */}
      <div className={cn("flex items-center gap-3 p-6 border-b border-border", sidebarCollapsed && "justify-center px-4")}>
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-glow flex-shrink-0">
          <Music className="w-5 h-5 text-primary-foreground" />
        </div>
        {!sidebarCollapsed && (
          <div>
            <h1 className="text-sm font-bold text-foreground">AI Music Studio</h1>
            <p className="text-xs text-muted-foreground">Collaborative Capture</p>
          </div>
        )}
      </div>

      {/* Navigation Items */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navigationItems.map((item) => {
          const [canAccess, blockReason] = canNavigateTo(item);
          const badge = item.id === "generate" && generationInProgress ? "in-progress" : null;

          return (
            <NavigationItem
              key={item.id}
              icon={item.icon}
              label={item.label}
              route={item.route}
              shortcut={item.shortcut}
              description={item.description}
              badge={badge}
              isDisabled={!canAccess}
              disabledReason={blockReason || undefined}
              onClick={() => canAccess && requestNavigation(item.route, "click")}
              collapsed={sidebarCollapsed}
            />
          );
        })}
      </nav>

      <div className="mt-auto w-full">
        {showWorkflowProgress && (
          <div className="border-t border-border p-4">
            <WorkflowProgress
              currentPhase={workflowPhase}
              completedPhases={completedPhases}
              collapsed={sidebarCollapsed}
            />
          </div>
        )}

        <div className="border-t border-border">
          <div className="p-4">
            <Button
              variant="ghost"
              onClick={onDebugToggle}
              className={cn("w-full gap-2", sidebarCollapsed && "px-2")}
            >
              <Bug className="w-4 h-4" />
              {!sidebarCollapsed && <span className="text-sm">Debug Console</span>}
            </Button>
          </div>

          {/* Collapse Toggle */}
          <div className="border-t border-border p-4">
            <Button
              variant="ghost"
              onClick={toggleSidebar}
              className={cn("w-full", sidebarCollapsed && "px-2")}
              aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {sidebarCollapsed ? (
                <ChevronRight className="w-4 h-4" />
              ) : (
                <>
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  <span className="text-sm">Collapse</span>
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </aside>
  );
};
