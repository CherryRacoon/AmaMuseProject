import { Link, useLocation } from "react-router-dom";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { NavigationBadge } from "./NavigationBadge";
import { NavigationTooltip } from "./NavigationTooltip";

interface NavigationItemProps {
  icon: LucideIcon;
  label: string;
  route: string;
  shortcut: string;
  description: string;
  badge?: string | null;
  isDisabled?: boolean;
  disabledReason?: string;
  onClick?: () => void;
  collapsed?: boolean;
}

export const NavigationItem = ({
  icon: Icon,
  label,
  route,
  shortcut,
  description,
  badge,
  isDisabled = false,
  disabledReason,
  onClick,
  collapsed = false,
}: NavigationItemProps) => {
  const location = useLocation();
  const isActive = location.pathname === route;

  const content = (
    <div
      className={cn(
        "relative flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200",
        "hover:bg-card/80",
        isActive && "bg-primary/20 border-l-4 border-primary shadow-glow",
        isDisabled && "opacity-40 grayscale cursor-not-allowed",
        !isDisabled && !isActive && "hover:scale-[1.02]",
        collapsed ? "justify-center px-2" : "justify-start"
      )}
      onClick={isDisabled ? undefined : onClick}
      role="button"
      aria-disabled={isDisabled}
      aria-current={isActive ? "page" : undefined}
      aria-describedby={isDisabled ? `${route}-disabled-reason` : undefined}
    >
      <div className="relative">
        <Icon
          className={cn(
            "w-5 h-5 transition-colors",
            isActive ? "text-primary" : "text-muted-foreground"
          )}
        />
        {badge && <NavigationBadge type={badge} />}
      </div>
      
      {!collapsed && (
        <span
          className={cn(
            "text-sm font-medium transition-colors",
            isActive ? "text-primary" : "text-foreground"
          )}
        >
          {label}
        </span>
      )}
      
      {!collapsed && isDisabled && disabledReason && (
        <span
          id={`${route}-disabled-reason`}
          className="sr-only"
        >
          {disabledReason}
        </span>
      )}
    </div>
  );

  const wrappedContent = isDisabled ? (
    <div className="relative">
      {content}
      {!collapsed && disabledReason && (
        <p className="text-xs text-muted-foreground mt-1 px-4">
          {disabledReason}
        </p>
      )}
    </div>
  ) : (
    <Link to={route} className="block">
      {content}
    </Link>
  );

  return (
    <NavigationTooltip
      content={collapsed ? `${label} (${shortcut})` : `${description} (${shortcut})`}
      disabled={!collapsed && !isDisabled}
    >
      {wrappedContent}
    </NavigationTooltip>
  );
};
