import { Home, Music, Zap, Sliders, Menu, Settings, Share2, Bug, Star, LucideIcon } from "lucide-react";
import { useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useNavigationGuard } from "@/hooks/useNavigationGuard";
import { useNavigationStore } from "@/stores/useNavigationStore";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { NavigationItem } from "./NavigationItem";
import { Button } from "@/components/ui/button";

interface NavItem {
  id: string;
  label: string;
  icon: LucideIcon;
  route: string;
  shortcut: string;
  requiresProject: boolean;
  requiresInput?: boolean;
  requiresRefinedPrompt?: boolean;
  requiresGeneratedAudio?: boolean;
  requiresFinalizedAudio?: boolean;
  phase: string | null;
  description: string;
}

const primaryNavItems = [
  { id: "dashboard", label: "Projects", icon: Home, route: "/" },
  { id: "create", label: "Capture", icon: Music, route: "/create" },
  { id: "generate", label: "Generate", icon: Zap, route: "/generate" },
  { id: "rate", label: "Rate", icon: Star, route: "/rate" },
  { id: "edit", label: "Edit", icon: Sliders, route: "/edit" },
];

const secondaryNavItems: NavItem[] = [
  {
    id: "settings",
    label: "API Settings",
    icon: Settings,
    route: "/settings",
    shortcut: "Ctrl+,",
    requiresProject: false,
    phase: null,
    description: "Configure APIs",
  },
  {
    id: "export",
    label: "Export",
    icon: Share2,
    route: "/export",
    shortcut: "Ctrl+6",
    requiresProject: true,
    requiresFinalizedAudio: true,
    phase: "complete",
    description: "Export and share",
  },
];

interface MobileNavigationProps {
  onDebugToggle: () => void;
}

export const MobileNavigation = ({ onDebugToggle }: MobileNavigationProps) => {
  const location = useLocation();
  const { generationInProgress } = useNavigationStore();
  const { requestNavigation, canNavigateTo } = useNavigationGuard();

  return (
    <>
      {/* Bottom Tab Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 pb-safe">
        <div className="flex items-center justify-around h-16">
          {primaryNavItems.map((item) => {
            const isActive = location.pathname === item.route;
            const badge = item.id === "generate" && generationInProgress;

            return (
              <button
                key={item.id}
                onClick={() => requestNavigation(item.route, "click")}
                className={cn(
                  "flex flex-col items-center justify-center gap-1 px-3 py-2 transition-all duration-200",
                  isActive && "scale-110"
                )}
                aria-label={item.label}
                aria-current={isActive ? "page" : undefined}
              >
                <div className="relative">
                  <item.icon
                    className={cn(
                      "w-6 h-6 transition-colors",
                      isActive ? "text-primary" : "text-muted-foreground"
                    )}
                  />
                  {badge && (
                    <span className="absolute -top-1 -right-1 w-2 h-2 bg-accent rounded-full animate-pulse" />
                  )}
                </div>
                <span
                  className={cn(
                    "text-xs transition-colors",
                    isActive ? "text-primary font-medium" : "text-muted-foreground"
                  )}
                >
                  {item.label}
                </span>
              </button>
            );
          })}

          {/* Menu Drawer */}
          <Sheet>
            <SheetTrigger asChild>
              <button
                className="flex flex-col items-center justify-center gap-1 px-3 py-2"
                aria-label="More options"
              >
                <Menu className="w-6 h-6 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Menu</span>
              </button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-[80vh]">
              <SheetHeader>
                <SheetTitle>More Options</SheetTitle>
              </SheetHeader>
              <div className="mt-6 space-y-2">
                {secondaryNavItems.map((item) => {
                  const [canAccess, blockReason] = canNavigateTo(item);
                  return (
                    <NavigationItem
                      key={item.id}
                      icon={item.icon}
                      label={item.label}
                      route={item.route}
                      shortcut={item.shortcut}
                      description={item.description}
                      isDisabled={!canAccess}
                      disabledReason={blockReason || undefined}
                      onClick={() => canAccess && requestNavigation(item.route, "click")}
                    />
                  );
                })}
                <Button
                  variant="ghost"
                  onClick={onDebugToggle}
                  className="w-full justify-start gap-2"
                >
                  <Bug className="w-4 h-4" />
                  <span>Debug Console</span>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>

      {/* Spacer to prevent content from being hidden behind tab bar */}
      <div className="lg:hidden h-16" />
    </>
  );
};
