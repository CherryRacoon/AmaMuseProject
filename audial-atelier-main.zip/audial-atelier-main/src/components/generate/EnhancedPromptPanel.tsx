import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wand2, AlertTriangle } from "lucide-react";

interface EnhancedPromptPanelProps {
  enhancedPrompt?: string;
  instruments?: string[];
  emotions?: string[];
}

export const EnhancedPromptPanel = ({ 
  enhancedPrompt,
  instruments = [],
  emotions = []
}: EnhancedPromptPanelProps) => {
  const hasPrompt = !!enhancedPrompt?.trim();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-primary" />
            Enhanced Prompt
          </div>
          {hasPrompt && <Badge variant="secondary">Ready</Badge>}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {hasPrompt ? (
          <div className="space-y-4">
            <div className="font-mono text-sm bg-muted/50 p-4 rounded-lg">
              {enhancedPrompt}
            </div>
            
            {(instruments.length > 0 || emotions.length > 0) && (
              <div className="flex flex-wrap gap-4">
                {instruments.length > 0 && (
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Instruments:</p>
                    <div className="flex flex-wrap gap-1">
                      {instruments.map(instrument => (
                        <Badge key={instrument} variant="outline">
                          {instrument}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                {emotions.length > 0 && (
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Emotions:</p>
                    <div className="flex flex-wrap gap-1">
                      {emotions.map(emotion => (
                        <Badge key={emotion} variant="outline">
                          {emotion}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-3 text-muted-foreground p-4 bg-muted/50 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            <p>No refined prompt available. Visit the Refine section to create one.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
