import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, Loader2, AlertCircle } from "lucide-react";

type GenerationStage = "validating" | "initializing" | "generating" | "postprocessing" | "ready";

interface GenerationProgressProps {
  stage: GenerationStage;
  progress: number;
  isGenerating: boolean;
  elapsedTime: number;
  estimatedTime?: number;
}

const stageConfig = {
  validating: {
    label: "Prompt Validation",
    description: "Validating prompt and parameters",
    icon: AlertCircle,
    color: "text-blue-500"
  },
  initializing: {
    label: "API Authentication",
    description: "Connecting to AI service",
    icon: Clock,
    color: "text-yellow-500"
  },
  generating: {
    label: "Generation in Progress",
    description: "AI creating your music",
    icon: Loader2,
    color: "text-purple-500"
  },
  postprocessing: {
    label: "Post-processing",
    description: "Formatting, conversion, and metadata",
    icon: Clock,
    color: "text-orange-500"
  },
  ready: {
    label: "Ready",
    description: "Generation completed successfully",
    icon: CheckCircle,
    color: "text-green-500"
  }
};

export const GenerationProgress = ({
  stage,
  progress,
  isGenerating,
  elapsedTime,
  estimatedTime
}: GenerationProgressProps) => {
  const currentStage = stageConfig[stage];
  const StageIcon = currentStage.icon;

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getRemainingTime = (): string => {
    if (!estimatedTime || !isGenerating) return "";
    const remaining = Math.max(0, estimatedTime - elapsedTime);
    return formatTime(remaining);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <StageIcon className={`w-5 h-5 ${currentStage.color} ${stage === 'generating' ? 'animate-spin' : ''}`} />
            Generation Progress
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline">
              {Math.round(progress)}%
            </Badge>
            {elapsedTime > 0 && (
              <Badge variant="secondary">
                {formatTime(elapsedTime)}
              </Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Overall Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>{currentStage.label}</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-3" />
          <p className="text-sm text-muted-foreground">{currentStage.description}</p>
        </div>

        {/* Stage Indicators */}
        <div className="grid grid-cols-5 gap-2">
          {Object.entries(stageConfig).map(([stageKey, config], index) => {
            const isActive = stageKey === stage;
            const isCompleted = getStageOrder(stageKey) < getStageOrder(stage) || stage === 'ready';
            const StageIconComponent = config.icon;

            return (
              <div
                key={stageKey}
                className={`flex flex-col items-center p-2 rounded-lg border ${
                  isActive
                    ? 'border-primary bg-primary/5'
                    : isCompleted
                    ? 'border-green-200 bg-green-50'
                    : 'border-muted bg-muted/50'
                }`}
              >
                <StageIconComponent
                  className={`w-4 h-4 mb-1 ${
                    isActive && stageKey === 'generating'
                      ? 'animate-spin text-primary'
                      : isActive
                      ? 'text-primary'
                      : isCompleted
                      ? 'text-green-500'
                      : 'text-muted-foreground'
                  }`}
                />
                <span className={`text-xs text-center leading-tight ${
                  isActive ? 'font-medium' : 'text-muted-foreground'
                }`}>
                  {config.label.split(' ')[0]}
                </span>
              </div>
            );
          })}
        </div>

        {/* Time Information */}
        {isGenerating && (
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Elapsed: {formatTime(elapsedTime)}</span>
            {estimatedTime && (
              <span>Remaining: {getRemainingTime()}</span>
            )}
          </div>
        )}

        {/* Completion Message */}
        {stage === 'ready' && (
          <div className="text-center py-4">
            <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="text-sm font-medium text-green-700">Generation Complete!</p>
            <p className="text-xs text-muted-foreground">Your music is ready for editing</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const getStageOrder = (stage: string): number => {
  const order = ['validating', 'initializing', 'generating', 'postprocessing', 'ready'];
  return order.indexOf(stage);
};