import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Server, Wifi, WifiOff, Users } from "lucide-react";

interface APIStatusIndicatorProps {
  provider: "acestep" | "lyria" | "suno";
  isActive: boolean;
  taskId?: string;
  queuePosition?: number;
}

export const APIStatusIndicator = ({
  provider,
  isActive,
  taskId,
  queuePosition
}: APIStatusIndicatorProps) => {
  const getProviderColor = (provider: string) => {
    switch (provider) {
      case "lyria":
        return "text-blue-600 bg-blue-100";
      case "suno":
        return "text-orange-600 bg-orange-100";
      case "acestep":
        return "text-purple-600 bg-purple-100";
      default:
        return "text-gray-600 bg-gray-100";
    }
  };

  const getStatusIcon = () => {
    if (isActive) {
      return <Wifi className="w-3 h-3" />;
    }
    return <WifiOff className="w-3 h-3" />;
  };

  const getStatusText = () => {
    if (isActive) {
      return "Active";
    }
    return "Inactive";
  };

  return (
    <TooltipProvider>
      <div className="flex items-center gap-2">
        <Tooltip>
          <TooltipTrigger>
            <Badge
              variant="outline"
              className={`gap-1 ${getProviderColor(provider)} border-current`}
            >
              <Server className="w-3 h-3" />
              {provider.toUpperCase()}
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <p>{provider.toUpperCase()} API Service</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger>
            <Badge
              variant={isActive ? "default" : "secondary"}
              className="gap-1"
            >
              {getStatusIcon()}
              {getStatusText()}
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <p>API Connection Status</p>
          </TooltipContent>
        </Tooltip>

        {taskId && (
          <Tooltip>
            <TooltipTrigger>
              <Badge variant="outline" className="gap-1">
                <Server className="w-3 h-3" />
                {taskId.slice(-6)}
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <p>Task ID: {taskId}</p>
            </TooltipContent>
          </Tooltip>
        )}

        {queuePosition && queuePosition > 0 && (
          <Tooltip>
            <TooltipTrigger>
              <Badge variant="outline" className="gap-1 text-yellow-600">
                <Users className="w-3 h-3" />
                #{queuePosition}
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <p>Queue Position: {queuePosition}</p>
            </TooltipContent>
          </Tooltip>
        )}
      </div>
    </TooltipProvider>
  );
};