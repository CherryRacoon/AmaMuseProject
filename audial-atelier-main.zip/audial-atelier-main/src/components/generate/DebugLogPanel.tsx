import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Activity, Trash2, Download, Eye, EyeOff } from "lucide-react";
import { useDebugLog } from "@/hooks/useDebugLog";

type GenerationStage = "validating" | "initializing" | "generating" | "postprocessing" | "ready";

interface GenerationState {
  stage: GenerationStage;
  progress: number;
  taskId?: string;
  apiProvider: "acestep" | "lyria" | "suno";
  queuePosition?: number;
  elapsedTime: number;
  estimatedTime?: number;
  error?: string;
  retryCount: number;
}

interface DebugLogPanelProps {
  projectId: string;
  isActive: boolean;
  generationState: GenerationState;
}

export const DebugLogPanel = ({
  projectId,
  isActive,
  generationState
}: DebugLogPanelProps) => {
  const { logs, clearLogs } = useDebugLog();
  const [isExpanded, setIsExpanded] = useState(true);
  const [autoScroll, setAutoScroll] = useState(true);

  // Filter logs for this project and generation-related logs
  const relevantLogs = logs.filter(log =>
    log.details?.projectId === projectId ||
    log.source === "ACE-Step" ||
    log.source === "Lyria" ||
    log.source === "Suno" ||
    log.source === "Network" ||
    (log.action && log.action.toLowerCase().includes('generation'))
  );

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (autoScroll && isExpanded) {
      const scrollArea = document.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollArea) {
        scrollArea.scrollTop = scrollArea.scrollHeight;
      }
    }
  }, [relevantLogs, autoScroll, isExpanded]);

  const getLogLevelColor = (level: string) => {
    switch (level) {
      case "ERROR":
        return "text-red-600 bg-red-100";
      case "WARN":
        return "text-yellow-600 bg-yellow-100";
      case "INFO":
        return "text-blue-600 bg-blue-100";
      case "DEBUG":
        return "text-gray-600 bg-gray-100";
      default:
        return "text-gray-600 bg-gray-100";
    }
  };

  const getSourceColor = (source: string) => {
    switch (source) {
      case "ACE-Step":
        return "text-purple-600 bg-purple-50";
      case "Lyria":
        return "text-blue-600 bg-blue-50";
      case "Suno":
        return "text-orange-600 bg-orange-50";
      case "Network":
        return "text-purple-600 bg-purple-50";
      case "System":
        return "text-green-600 bg-green-50";
      default:
        return "text-gray-600 bg-gray-50";
    }
  };

  const exportLogs = () => {
    const logData = relevantLogs.map(log => ({
      timestamp: log.timestamp,
      level: log.level,
      source: log.source,
      action: log.action,
      message: log.message,
      details: log.details
    }));

    const blob = new Blob([JSON.stringify(logData, null, 2)], {
      type: 'application/json'
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `generation-logs-${projectId}-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <Card className="h-fit">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Activity className={`w-4 h-4 ${isActive ? 'text-green-500' : 'text-muted-foreground'}`} />
            Debug Logs
            {relevantLogs.length > 0 && (
              <Badge variant="secondary" className="text-xs">
                {relevantLogs.length}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              className="h-6 w-6 p-0"
            >
              {isExpanded ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearLogs}
              className="h-6 w-6 p-0"
              disabled={relevantLogs.length === 0}
            >
              <Trash2 className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={exportLogs}
              className="h-6 w-6 p-0"
              disabled={relevantLogs.length === 0}
            >
              <Download className="w-3 h-3" />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>

      {isExpanded && (
        <CardContent className="pt-0">
          <ScrollArea className="h-96 w-full">
            <div className="space-y-2">
              {relevantLogs.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No logs yet</p>
                  <p className="text-xs">Generation activity will appear here</p>
                </div>
              ) : (
                relevantLogs.map((log, index) => (
                  <div
                    key={`${log.timestamp}-${index}`}
                    className="text-xs p-2 rounded border bg-muted/50"
                  >
                    <div className="flex items-start gap-2 mb-1">
                      <span className="text-muted-foreground font-mono">
                        {formatTimestamp(log.timestamp)}
                      </span>
                      <Badge
                        variant="outline"
                        className={`text-xs px-1 py-0 ${getLogLevelColor(log.level)}`}
                      >
                        {log.level}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={`text-xs px-1 py-0 ${getSourceColor(log.source)}`}
                      >
                        {log.source}
                      </Badge>
                    </div>

                    <div className="space-y-1">
                      <p className="font-medium">{log.action}</p>
                      <p className="text-muted-foreground">{log.message}</p>

                      {log.details && Object.keys(log.details).length > 0 && (
                        <details className="mt-1">
                          <summary className="cursor-pointer text-muted-foreground hover:text-foreground">
                            Details
                          </summary>
                          <pre className="mt-1 text-xs bg-background p-1 rounded border overflow-x-auto">
                            {JSON.stringify(log.details, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>

                    {index < relevantLogs.length - 1 && <Separator className="mt-2" />}
                  </div>
                ))
              )}
            </div>
          </ScrollArea>

          {relevantLogs.length > 0 && (
            <div className="flex items-center justify-between mt-3 pt-3 border-t">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Activity className="w-3 h-3" />
                Live monitoring active
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setAutoScroll(!autoScroll)}
                className={`text-xs h-6 ${autoScroll ? 'text-primary' : 'text-muted-foreground'}`}
              >
                Auto-scroll {autoScroll ? 'ON' : 'OFF'}
              </Button>
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
};