import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  RotateCcw,
  Download,
  Star,
  Music,
  Clock,
  BarChart3
} from "lucide-react";
import { Project } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";

interface GeneratedVersionsGalleryProps {
  project: Project;
  onSelectVersion: (versionId: string) => void;
}

interface AudioState {
  playing: boolean;
  volume: number;
  currentTime: number;
  duration: number;
}

export const GeneratedVersionsGallery = ({
  project,
  onSelectVersion
}: GeneratedVersionsGalleryProps) => {
  const { addLog } = useDebugLog();
  const [selectedVersion, setSelectedVersion] = useState<string | null>(null);
  const [audioStates, setAudioStates] = useState<Record<string, AudioState>>({});
  const [comparisonMode, setComparisonMode] = useState(false);

  const versions = project.generatedVersions || [];

  const initializeAudioState = (versionId: string) => {
    if (!audioStates[versionId]) {
      setAudioStates(prev => ({
        ...prev,
        [versionId]: {
          playing: false,
          volume: 0.7,
          currentTime: 0,
          duration: 0
        }
      }));
    }
  };

  const togglePlayback = (versionId: string) => {
    initializeAudioState(versionId);

    setAudioStates(prev => {
      const newStates = { ...prev };

      // Stop all other audio
      Object.keys(newStates).forEach(id => {
        if (id !== versionId) {
          newStates[id] = { ...newStates[id], playing: false };
        }
      });

      // Toggle current audio
      newStates[versionId] = {
        ...newStates[versionId],
        playing: !newStates[versionId].playing
      };

      return newStates;
    });

    addLog("INFO", "System", "Audio Playback", `Toggled playback for version ${versionId}`, {
      projectId: project.id,
      versionId,
      playing: !audioStates[versionId]?.playing
    });
  };

  const setVolume = (versionId: string, volume: number) => {
    setAudioStates(prev => ({
      ...prev,
      [versionId]: {
        ...prev[versionId],
        volume
      }
    }));
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const generateWaveformBars = (waveformData: number[], bars = 20) => {
    if (!waveformData || waveformData.length === 0) {
      return Array(bars).fill(0).map(() => Math.random() * 0.8 + 0.2);
    }

    const step = Math.floor(waveformData.length / bars);
    return Array(bars).fill(0).map((_, i) => {
      const start = i * step;
      const end = Math.min(start + step, waveformData.length);
      const slice = waveformData.slice(start, end);
      return slice.reduce((sum, val) => sum + val, 0) / slice.length;
    });
  };

  const WaveformVisualizer = ({ waveformData, isPlaying }: { waveformData: number[], isPlaying: boolean }) => {
    const bars = generateWaveformBars(waveformData);

    return (
      <div className="flex items-end gap-1 h-8">
        {bars.map((height, index) => (
          <div
            key={index}
            className={`bg-primary rounded-sm transition-all duration-200 ${
              isPlaying ? 'animate-pulse' : ''
            }`}
            style={{
              height: `${Math.max(height * 100, 10)}%`,
              width: '3px',
              opacity: isPlaying ? 0.8 : 0.6
            }}
          />
        ))}
      </div>
    );
  };

  if (versions.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <Music className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Generated Versions</h3>
          <p className="text-muted-foreground">
            Start generation to see your music versions here
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Music className="w-5 h-5 text-primary" />
              Generated Versions
              <Badge variant="secondary">{versions.length}</Badge>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setComparisonMode(!comparisonMode)}
            >
              {comparisonMode ? 'Exit Compare' : 'Compare Mode'}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {versions.map((version) => {
              const audioState = audioStates[version.id] || {
                playing: false,
                volume: 0.7,
                currentTime: 0,
                duration: version.duration
              };

              const isSelected = selectedVersion === version.id;

              return (
                <Card
                  key={version.id}
                  className={`cursor-pointer transition-all ${
                    isSelected ? 'ring-2 ring-primary' : 'hover:shadow-md'
                  }`}
                  onClick={() => {
                    setSelectedVersion(version.id);
                    onSelectVersion(version.id);
                  }}
                >
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      {/* Header */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Badge variant="outline">Version {version.id}</Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <Clock className="w-3 h-3" />
                            {formatTime(version.duration)}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              togglePlayback(version.id);
                            }}
                            className="gap-2"
                          >
                            {audioState.playing ? (
                              <Pause className="w-3 h-3" />
                            ) : (
                              <Play className="w-3 h-3" />
                            )}
                            {audioState.playing ? 'Pause' : 'Play'}
                          </Button>

                          <Button variant="outline" size="sm">
                            <Download className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>

                      {/* Waveform Visualizer */}
                      <div className="space-y-2">
                        <WaveformVisualizer
                          waveformData={version.waveformData}
                          isPlaying={audioState.playing}
                        />

                        {/* Progress Bar */}
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">
                            {formatTime(audioState.currentTime)}
                          </span>
                          <Progress
                            value={(audioState.currentTime / audioState.duration) * 100}
                            className="flex-1 h-1"
                          />
                          <span className="text-xs text-muted-foreground">
                            {formatTime(audioState.duration)}
                          </span>
                        </div>
                      </div>

                      {/* Controls */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              // Loop functionality would go here
                            }}
                          >
                            <RotateCcw className="w-3 h-3" />
                          </Button>

                          <div className="flex items-center gap-2">
                            {audioState.volume > 0 ? (
                              <Volume2 className="w-3 h-3" />
                            ) : (
                              <VolumeX className="w-3 h-3" />
                            )}
                            <input
                              type="range"
                              min="0"
                              max="1"
                              step="0.1"
                              value={audioState.volume}
                              onChange={(e) => setVolume(version.id, parseFloat(e.target.value))}
                              className="w-16 h-1"
                              onClick={(e) => e.stopPropagation()}
                            />
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              className="focus:outline-none"
                              onClick={(e) => {
                                e.stopPropagation();
                                // Rating functionality would go here
                              }}
                            >
                              <Star className={`w-3 h-3 ${
                                star <= 4 ? 'text-yellow-500 fill-current' : 'text-muted-foreground'
                              }`} />
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Metadata */}
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Generated {version.timestamp.toLocaleDateString()}</span>
                        <div className="flex items-center gap-3">
                          <span className="flex items-center gap-1">
                            <BarChart3 className="w-3 h-3" />
                            {version.waveformData.length} samples
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Comparison Mode */}
      {comparisonMode && selectedVersion && (
        <Card>
          <CardHeader>
            <CardTitle>A/B Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {versions
                .filter(v => v.id === selectedVersion || Math.random() > 0.7) // Mock comparison
                .slice(0, 2)
                .map((version) => (
                  <div key={version.id} className="space-y-2">
                    <div className="text-sm font-medium">Version {version.id}</div>
                    <WaveformVisualizer
                      waveformData={version.waveformData}
                      isPlaying={audioStates[version.id]?.playing || false}
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => togglePlayback(version.id)}
                      className="w-full"
                    >
                      {audioStates[version.id]?.playing ? 'Pause' : 'Play'} Version {version.id}
                    </Button>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};