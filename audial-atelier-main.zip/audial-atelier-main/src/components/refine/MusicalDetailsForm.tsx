import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Save, Music, Mic, Heart, Clock, Sparkles, Loader2 } from "lucide-react";
import { Project, PromptRefinement } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { useGeminiAI } from "@/hooks/useGeminiAI";

interface MusicalDetailsFormProps {
  project: Project;
  onSave: (refinement: Partial<PromptRefinement>) => void;
}

const INSTRUMENTS = [
  "Piano", "Guitar", "Bass", "Drums", "Violin", "Cello", "Flute", "Trumpet",
  "Saxophone", "Synthesizer", "Organ", "Harp", "Percussion", "Strings", "Brass", "Woodwinds"
];

const VOCAL_TYPES = ["Female", "Male", "Instrumental"];

const EMOTIONS = [
  "Happy", "Sad", "Energetic", "Calm", "Dark", "Bright", "Melancholic", "Uplifting",
  "Mysterious", "Romantic", "Aggressive", "Peaceful", "Nostalgic", "Hopeful"
];

export const MusicalDetailsForm = ({ project, onSave }: MusicalDetailsFormProps) => {
  const { addLog } = useDebugLog();
  const { enhancePrompt, isLoading: isEnhancing } = useGeminiAI();

  const [instruments, setInstruments] = useState<string[]>(project.refinement?.instruments || []);
  const [vocalType, setVocalType] = useState(project.refinement?.vocalType || "");
  const [emotions, setEmotions] = useState<string[]>(project.refinement?.emotions || []);
  const [tempo, setTempo] = useState([120]);
  const [negativePrompt, setNegativePrompt] = useState(project.refinement?.negativePrompt || "");
  const [enhancedPrompt, setEnhancedPrompt] = useState(project.refinement?.enhancedPrompt || "");

  useEffect(() => {
    // Auto-generate enhanced prompt based on selections
    const parts = [];

    if (instruments.length > 0) {
      parts.push(`Instrumental arrangement featuring ${instruments.join(", ")}`);
    }

    if (vocalType) {
      parts.push(vocalType === 'Instrumental' ? `Instrumental (no lead vocal)` : `${vocalType} lead vocal`);
    }

    if (emotions.length > 0) {
      parts.push(`Conveying ${emotions.join(", ")} emotions`);
    }

    const structureSequence = project.refinement?.structure ?? [];
    if (structureSequence.length > 0) {
      parts.push(`Song structure: ${structureSequence.join(" → ")}`);
    }

  parts.push(`Tempo: ${tempo[0]} BPM`);

    if (negativePrompt) {
      parts.push(`Avoid: ${negativePrompt}`);
    }

    setEnhancedPrompt(parts.join(". ") + ".");
  }, [
    instruments,
    vocalType,
    emotions,
    tempo,
    negativePrompt,
    project.refinement?.structure?.join("→") ?? "",
  ]);

  const handleEnhanceWithAI = async () => {
    const mood = Array.isArray(project.textPrompt?.mood) 
      ? project.textPrompt?.mood[0] 
      : project.textPrompt?.mood;

    const enhanced = await enhancePrompt({
      prompt: enhancedPrompt,
      mood: mood || emotions[0],
      genre: project.textPrompt?.genre,
      tempo: tempo[0],
      instruments,
      vocalsType: vocalType,
    });

    if (enhanced) {
      setEnhancedPrompt(enhanced);
    }
  };

  const handleSave = () => {
    const refinement: Partial<PromptRefinement> = {
      enhancedPrompt,
      instruments,
      vocalType,
      emotions,
      negativePrompt,
      seed: Math.floor(Math.random() * 1000000),
      sampleCount: 1,
      structure: project.refinement?.structure ?? [],
    };

    onSave(refinement);

    addLog("INFO", "System", "Musical Details Saved", "Refinement details updated", {
      instruments: instruments.length,
      vocalType,
      emotions: emotions.length,
      tempo: tempo[0],
      structure: (project.refinement?.structure ?? []).length,
    });
  };

  const toggleInstrument = (instrument: string) => {
    setInstruments(prev =>
      prev.includes(instrument)
        ? prev.filter(i => i !== instrument)
        : [...prev, instrument]
    );
  };

  const toggleEmotion = (emotion: string) => {
    setEmotions(prev =>
      prev.includes(emotion)
        ? prev.filter(e => e !== emotion)
        : [...prev, emotion]
    );
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Music className="w-5 h-5 text-primary" />
            Musical Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Instruments */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Instruments</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {INSTRUMENTS.map((instrument) => (
                <div key={instrument} className="flex items-center space-x-2">
                  <Checkbox
                    id={`instrument-${instrument}`}
                    checked={instruments.includes(instrument)}
                    onCheckedChange={() => toggleInstrument(instrument)}
                  />
                  <Label
                    htmlFor={`instrument-${instrument}`}
                    className="text-sm cursor-pointer"
                  >
                    {instrument}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Vocal Type */}
          <div className="space-y-3">
            <Label className="text-base font-medium flex items-center gap-2">
              <Mic className="w-4 h-4" />
              Vocal (choose one)
            </Label>
            <Select value={vocalType} onValueChange={setVocalType}>
              <SelectTrigger>
                <SelectValue placeholder="Select vocal option" />
              </SelectTrigger>
              <SelectContent>
                {VOCAL_TYPES.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Emotions */}
          <div className="space-y-3">
            <Label className="text-base font-medium flex items-center gap-2">
              <Heart className="w-4 h-4" />
              Emotions & Atmosphere
            </Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {EMOTIONS.map((emotion) => (
                <div key={emotion} className="flex items-center space-x-2">
                  <Checkbox
                    id={`emotion-${emotion}`}
                    checked={emotions.includes(emotion)}
                    onCheckedChange={() => toggleEmotion(emotion)}
                  />
                  <Label
                    htmlFor={`emotion-${emotion}`}
                    className="text-sm cursor-pointer"
                  >
                    {emotion}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Tempo and Length */}
          <div className="space-y-3">
            <Label className="text-base font-medium flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Tempo: {tempo[0]} BPM
            </Label>
            <Slider
              value={tempo}
              onValueChange={setTempo}
              min={60}
              max={200}
              step={5}
              className="w-full"
            />
            <div className="mt-2 text-sm text-muted-foreground">
              Not sure what BPM means? Try these simple guides:
              <ul className="mt-1 list-disc pl-5">
                <li><strong>Slow (60–80):</strong> calm, like a lullaby or a slow ballad.</li>
                <li><strong>Medium (90–120):</strong> steady, like walking pace — good for singer-songwriter and pop.</li>
                <li><strong>Fast (130–200):</strong> energetic or danceable — for upbeat, driving songs.</li>
              </ul>
            </div>
          </div>

          {/* Negative Prompt */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Negative Prompt (What to Avoid)</Label>
            <Textarea
              placeholder="Specify what you want to avoid in the music (e.g., no heavy distortion, avoid major key changes, etc.)"
              value={negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              rows={3}
            />
          </div>

          <Separator />

          {/* Enhanced Prompt Preview */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium">Enhanced Prompt Preview</Label>
              <Button
                onClick={handleEnhanceWithAI}
                variant="outline"
                size="sm"
                className="gap-2"
                disabled={isEnhancing || !enhancedPrompt}
              >
                {isEnhancing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Enhancing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Enhance with AI
                  </>
                )}
              </Button>
            </div>
            <Textarea
              value={enhancedPrompt}
              onChange={(e) => setEnhancedPrompt(e.target.value)}
              placeholder="Your enhanced prompt will appear here..."
              rows={6}
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Click "Enhance with AI" to use Gemini to refine and improve your prompt based on music production best practices.
            </p>
          </div>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button onClick={handleSave} className="gap-2">
              <Save className="w-4 h-4" />
              Save Refinement
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
