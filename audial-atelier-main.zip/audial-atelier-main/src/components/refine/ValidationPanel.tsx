import { useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  CheckCircle,
  AlertTriangle,
  Clock,
  Music,
  FileText,
  Mic,
  Image as ImageIcon,
  Zap
} from "lucide-react";
import { Project } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";

interface ValidationItem {
  id: string;
  label: string;
  status: 'valid' | 'invalid' | 'warning' | 'missing';
  message: string;
  icon: React.ReactNode;
  required: boolean;
}

interface ValidationPanelProps {
  project: Project;
  onValidationComplete?: (isValid: boolean) => void;
}

export const ValidationPanel = ({ project, onValidationComplete }: ValidationPanelProps) => {
  const { addLog } = useDebugLog();

  // Memoize validation items to prevent unnecessary recalculations
  const validationItems = useMemo((): ValidationItem[] => {
    const items: ValidationItem[] = [
      // Basic project info
      {
        id: 'project-name',
        label: 'Project Name',
        status: project.name.trim() ? 'valid' : 'missing',
        message: project.name.trim() ? 'Project has a name' : 'Project name is required',
        icon: <FileText className="w-4 h-4" />,
        required: true
      },

      // Inspiration sources
      {
        id: 'inspiration-audio',
        label: 'Audio Inspiration',
        status: project.audioInput ? 'valid' : 'missing',
        message: project.audioInput ? 'Audio inspiration provided' : 'Consider adding audio inspiration',
        icon: <Mic className="w-4 h-4" />,
        required: false
      },
      {
        id: 'inspiration-text',
        label: 'Text Inspiration',
        status: project.textPrompt ? 'valid' : 'missing',
        message: project.textPrompt ? 'Text inspiration provided' : 'Consider adding text inspiration',
        icon: <FileText className="w-4 h-4" />,
        required: false
      },
      {
        id: 'inspiration-lyrics',
        label: 'Lyrics Inspiration',
        status: project.lyrics ? 'valid' : 'missing',
        message: project.lyrics ? 'Lyrics inspiration provided' : 'Consider adding lyrics inspiration',
        icon: <Music className="w-4 h-4" />,
        required: false
      },
      {
        id: 'inspiration-image',
        label: 'Image Inspiration',
        status: project.imageInspiration ? 'valid' : 'missing',
        message: project.imageInspiration ? 'Image inspiration provided' : 'Consider adding image inspiration',
        icon: <ImageIcon className="w-4 h-4" />,
        required: false
      },

      // Refinement data
      {
        id: 'enhanced-prompt',
        label: 'Enhanced Prompt',
        status: project.refinement?.enhancedPrompt?.trim() ? 'valid' : 'missing',
        message: project.refinement?.enhancedPrompt?.trim()
          ? 'Enhanced prompt is ready'
          : 'Enhanced prompt is required for generation',
        icon: <Zap className="w-4 h-4" />,
        required: true
      },
      {
        id: 'instruments',
        label: 'Instruments',
        status: project.refinement?.instruments?.length ? 'valid' : 'warning',
        message: project.refinement?.instruments?.length
          ? `${project.refinement.instruments.length} instruments selected`
          : 'No instruments selected - using defaults',
        icon: <Music className="w-4 h-4" />,
        required: false
      },
      {
        id: 'emotions',
        label: 'Emotions',
        status: project.refinement?.emotions?.length ? 'valid' : 'warning',
        message: project.refinement?.emotions?.length
          ? `${project.refinement.emotions.length} emotions selected`
          : 'No emotions selected - using defaults',
        icon: <Music className="w-4 h-4" />,
        required: false
      },
      {
        id: 'tempo',
        label: 'Tempo',
        status: project.textPrompt?.tempo ? 'valid' : 'warning',
        message: project.textPrompt?.tempo
          ? `Tempo: ${project.textPrompt.tempo}`
          : 'Tempo not set - using default',
        icon: <Music className="w-4 h-4" />,
        required: false
      },
      {
        id: 'lyrics',
        label: 'Lyrics',
        status: project.lyrics?.content?.trim() ? 'valid' : 'missing',
        message: project.lyrics?.content?.trim()
          ? 'Lyrics are ready'
          : 'Lyrics are required for vocal generation',
        icon: <FileText className="w-4 h-4" />,
        required: true
      }
    ];

    return items;
  }, [project]);

  // Calculate validation result
  const validationResult = useMemo(() => {
    const requiredItems = validationItems.filter(item => item.required);
    const validRequired = requiredItems.every(item => item.status === 'valid');
    return { validRequired, totalRequired: requiredItems.length, requiredItems };
  }, [validationItems]);

  // Only call onValidationComplete when validation result changes
  useEffect(() => {
    if (onValidationComplete) {
      onValidationComplete(validationResult.validRequired);
    }

    // Only log when validation state actually changes
    addLog("INFO", "System", "Validation Complete", `Project validation: ${validationResult.validRequired ? 'Ready' : 'Incomplete'}`, {
      projectId: project.id,
      validRequired: validationResult.validRequired,
      totalItems: validationResult.totalRequired
    });
  }, [validationResult.validRequired, validationResult.totalRequired, project.id, onValidationComplete, addLog]);

  const requiredItems = validationResult.requiredItems;
  const validRequired = requiredItems.filter(item => item.status === "valid").length;
  const progressPercentage = requiredItems.length > 0 ? (validRequired / requiredItems.length) * 100 : 0;
  const isReady = validationResult.validRequired;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-primary" />
          Generation Readiness
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">Must-have checklist</p>
              <p className="text-xs text-muted-foreground">
                {validRequired} of {requiredItems.length} complete
              </p>
            </div>
            <Badge variant={isReady ? "secondary" : "outline"} className={isReady ? "bg-green-100 text-green-700" : undefined}>
              {isReady ? "Ready" : "In progress"}
            </Badge>
          </div>
          <Progress value={progressPercentage} className="h-2" />
        </div>

        <div className="space-y-3">
          {requiredItems.map((item) => {
            const isComplete = item.status === "valid";
            const Icon = isComplete ? CheckCircle : AlertTriangle;
            return (
              <div
                key={item.id}
                className="flex items-start gap-3 rounded-lg border border-border/60 bg-muted/40 p-3"
              >
                <Icon className={`w-4 h-4 mt-1 ${isComplete ? "text-green-600" : "text-yellow-600"}`} />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    {item.icon}
                    <p className="text-sm font-medium">{item.label}</p>
                  </div>
                  <p className={`text-xs mt-1 ${isComplete ? "text-muted-foreground" : "text-yellow-700"}`}>
                    {item.message}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {isReady ? (
          <Alert className="border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              All required items look good. Ready to move into generation whenever you are.
            </AlertDescription>
          </Alert>
        ) : (
          <Alert className="border-yellow-200 bg-yellow-50">
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              Finish the remaining must-haves to enable music generation.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
};
