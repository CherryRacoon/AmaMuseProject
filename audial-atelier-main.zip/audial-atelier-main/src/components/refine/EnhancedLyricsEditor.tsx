import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Music, Save, Hash, Zap } from "lucide-react";
import { Project, PromptRefinement } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";

interface EnhancedLyricsEditorProps {
  project: Project;
  onSave: (refinement: Partial<PromptRefinement>) => void;
}

export const EnhancedLyricsEditor = ({ project, onSave }: EnhancedLyricsEditorProps) => {
  const { addLog } = useDebugLog();

  const [lyrics, setLyrics] = useState(project.lyrics?.content || "");
  const [wordCount, setWordCount] = useState(0);
  const [syllableCount, setSyllableCount] = useState(0);
  const [lineCount, setLineCount] = useState(0);
  const [rhymeSuggestions, setRhymeSuggestions] = useState<string[]>([]);

  useEffect(() => {
    // Calculate statistics
    const lines = lyrics.split('\n').filter(line => line.trim());
    const words = lyrics.split(/\s+/).filter(word => word.trim());
    const syllables = words.reduce((total, word) => {
      // Simple syllable counting (approximate)
      const cleanWord = word.toLowerCase().replace(/[^a-z]/g, '');
      if (!cleanWord) return total;

      let count = 0;
      const vowels = 'aeiouy';
      let prevVowel = false;

      for (let i = 0; i < cleanWord.length; i++) {
        const isVowel = vowels.includes(cleanWord[i]);
        if (isVowel && !prevVowel) {
          count++;
        }
        prevVowel = isVowel;
      }

      // Ensure at least 1 syllable per word
      return total + Math.max(1, count);
    }, 0);

    setWordCount(words.length);
    setSyllableCount(syllables);
    setLineCount(lines.length);

    // Generate rhyme suggestions for the last line
    if (lines.length > 0) {
      const lastLine = lines[lines.length - 1].trim();
      const words = lastLine.split(/\s+/);
      if (words.length > 0) {
        const lastWord = words[words.length - 1].toLowerCase().replace(/[^a-z]/g, '');
        generateRhymeSuggestions(lastWord);
      }
    }
  }, [lyrics]);

  const generateRhymeSuggestions = (word: string) => {
    // Simple rhyme generation based on ending patterns
    const endings = ['ing', 'ed', 'er', 'ly', 'tion', 'ment', 'ness', 'ship', 'hood', 'ful'];
    const suggestions: string[] = [];

    // Add some common rhyme endings
    if (word.endsWith('ing')) {
      suggestions.push('ring', 'sing', 'wing', 'thing');
    } else if (word.endsWith('ed')) {
      suggestions.push('red', 'bed', 'said', 'head');
    } else if (word.endsWith('er')) {
      suggestions.push('her', 'sir', 'fur', 'blur');
    } else if (word.endsWith('ly')) {
      suggestions.push('fly', 'sky', 'high', 'why');
    } else {
      // Generic suggestions
      suggestions.push('love', 'heart', 'soul', 'dream', 'night', 'light', 'fire', 'desire');
    }

    setRhymeSuggestions(suggestions.slice(0, 6));
  };

  const handleSave = () => {
    // Create structure from lyrics
    const lines = lyrics.split('\n').filter(line => line.trim());
    const structure = lines.map((line, index) => {
      const lower = line.toLowerCase();
      if (lower.includes('[verse') || lower.includes('verse')) {
        return { type: "verse" as const, text: line };
      } else if (lower.includes('[chorus') || lower.includes('chorus')) {
        return { type: "chorus" as const, text: line };
      } else if (lower.includes('[bridge') || lower.includes('bridge')) {
        return { type: "verse" as const, text: line }; // Treat as verse for now
      }
      return { type: "verse" as const, text: line };
    });

    const refinement: Partial<PromptRefinement> = {
      enhancedPrompt: `Lyrics:\n${lyrics}`,
    };

    onSave(refinement);

    addLog("INFO", "System", "Lyrics Saved", "Enhanced lyrics saved", {
      wordCount,
      syllableCount,
      lineCount,
    });
  };

  const insertRhymeSuggestion = (suggestion: string) => {
    const lines = lyrics.split('\n');
    if (lines.length > 0) {
      const lastLineIndex = lines.length - 1;
      const lastLine = lines[lastLineIndex];
      const words = lastLine.trim().split(/\s+/);
      if (words.length > 0) {
        words[words.length - 1] = suggestion;
        lines[lastLineIndex] = words.join(' ');
        setLyrics(lines.join('\n'));
      }
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Music className="w-5 h-5 text-primary" />
            Enhanced Lyrics Editor
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Statistics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-primary">{wordCount}</div>
              <div className="text-xs text-muted-foreground">Words</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-primary">{syllableCount}</div>
              <div className="text-xs text-muted-foreground">Syllables</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-primary">{lineCount}</div>
              <div className="text-xs text-muted-foreground">Lines</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-primary">
                {lineCount > 0 ? Math.round(syllableCount / lineCount * 10) / 10 : 0}
              </div>
              <div className="text-xs text-muted-foreground">Avg Syllables/Line</div>
            </div>
          </div>

          {/* Lyrics Editor */}
          <div className="space-y-3">
            <Textarea
              value={lyrics}
              onChange={(e) => setLyrics(e.target.value)}
              placeholder="Write your lyrics here... Use [Verse], [Chorus], [Bridge] to structure your song"
              rows={12}
              className="font-mono text-sm"
            />
          </div>

          {/* Rhyme Suggestions */}
          {rhymeSuggestions.length > 0 && (
            <>
              <Separator />
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-yellow-500" />
                  <span className="text-sm font-medium">Rhyme Suggestions</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {rhymeSuggestions.map((suggestion) => (
                    <Button
                      key={suggestion}
                      variant="outline"
                      size="sm"
                      onClick={() => insertRhymeSuggestion(suggestion)}
                      className="h-7 text-xs"
                    >
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Formatting Tips */}
          <div className="p-4 bg-muted rounded-lg">
            <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
              <Hash className="w-4 h-4" />
              Formatting Tips
            </h4>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Use [Verse 1], [Chorus], [Bridge] to structure sections</li>
              <li>• Each line should have similar syllable counts for rhythm</li>
              <li>• Click rhyme suggestions to replace the last word</li>
              <li>• Aim for 8-12 syllables per line for most genres</li>
            </ul>
          </div>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button onClick={handleSave} className="gap-2">
              <Save className="w-4 h-4" />
              Save Lyrics
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
