import { useState, useRef, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Bot, User, Send, Sparkles, Lightbulb, Wand2, AlertCircle } from "lucide-react";
import { Project, PromptRefinement, TextPrompt, LyricsData } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { toast } from "sonner";
import { useApiStore } from "@/stores/useApiStore";
import { useProjectStore } from "@/stores/useProjectStore";

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  suggestions?: string[];
}

interface AssistantAction {
  type: string;
  payload?: Record<string, unknown>;
}

interface AIChatSidebarProps {
  project: Project;
}

export const AIChatSidebar = ({ project }: AIChatSidebarProps) => {
  const { addLog } = useDebugLog();
  const geminiApiKey = useApiStore((s) => s.geminiApiKey);
  const geminiModel = useApiStore((s) => s.geminiModel);
  const geminiTemperature = useApiStore((s) => s.geminiTemperature);
  const geminiTopP = useApiStore((s) => s.geminiTopP);
  const geminiMaxTokens = useApiStore((s) => s.geminiMaxOutputTokens);
  const updateProjectMeta = useProjectStore((s) => s.updateProject);
  const setRefinement = useProjectStore((s) => s.updateRefinement);
  const setTextPrompt = useProjectStore((s) => s.updateTextPrompt);
  const setLyrics = useProjectStore((s) => s.updateLyrics);
  const setImageInspiration = useProjectStore((s) => s.updateImageInspiration);
  const getProject = useProjectStore((s) => s.getProject);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello! I'm your AI music assistant. I can help you refine your musical ideas, suggest improvements, and enhance your creative vision. What would you like to work on?",
      timestamp: new Date(),
      suggestions: [
        "Suggest instrument combinations",
        "Improve my lyrics structure",
        "Help with tempo and mood",
        "Generate melody ideas"
      ]
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Scroll to bottom when new messages arrive
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const extractTextFromResponse = (response: any): string | null => {
    const parts = response?.candidates?.[0]?.content?.parts;
    if (!Array.isArray(parts)) return null;
    const text = parts
      .map((part: any) => (typeof part?.text === "string" ? part.text : ""))
      .join("")
      .trim();
    return text.length > 0 ? text : null;
  };

  const parseStructuredResult = (raw: string) => {
    try {
      return JSON.parse(raw);
    } catch {
      const match = raw.match(/\{[\s\S]*\}/);
      if (!match) return null;
      try {
        return JSON.parse(match[0]);
      } catch {
        return null;
      }
    }
  };

  const isTempoValue = (value: unknown): value is TextPrompt["tempo"] =>
    value === "slow" || value === "medium" || value === "fast";

  const applyActions = useCallback(
    (actions: AssistantAction[] = []) => {
      if (!actions.length) {
        return;
      }

      const latest = getProject(project.id) ?? project;

      actions.forEach((action) => {
        const payload = (action?.payload ?? {}) as Record<string, unknown>;

        switch (action.type) {
          case "updateRefinement": {
            setRefinement(project.id, payload as Partial<PromptRefinement>);
            addLog("INFO", "AI", "Action Applied", "Refinement updated by assistant", {
              projectId: project.id,
              keys: Object.keys(payload),
            });
            break;
          }
          case "updateTextPrompt": {
            const existing: TextPrompt = {
              text: latest.textPrompt?.text ?? "",
              mood: Array.isArray(latest.textPrompt?.mood) ? latest.textPrompt?.mood ?? [] : [],
              genre: latest.textPrompt?.genre ?? "",
              tempo: latest.textPrompt?.tempo ?? "medium",
              style: latest.textPrompt?.style ?? "",
            };

            const next: TextPrompt = {
              text: typeof payload.text === "string" ? payload.text : existing.text,
              mood: Array.isArray(payload.mood)
                ? (payload.mood as unknown[]).map((m) => String(m))
                : existing.mood,
              genre: typeof payload.genre === "string" ? payload.genre : existing.genre,
              tempo: isTempoValue(payload.tempo) ? (payload.tempo as TextPrompt["tempo"]) : existing.tempo,
              style: typeof payload.style === "string" ? payload.style : existing.style,
            };

            setTextPrompt(project.id, next);
            addLog("INFO", "AI", "Action Applied", "Text prompt updated by assistant", {
              projectId: project.id,
            });
            break;
          }
          case "updateLyrics": {
            const existing: LyricsData = latest.lyrics ?? { content: "", structure: [] };
            const structured: Array<{ type: "chorus" | "verse"; text: string }> = Array.isArray(payload.structure)
              ? payload.structure
                  .map((item) => {
                    if (!item || typeof item !== "object") return null;
                    const type: "chorus" | "verse" = (item as any).type === "chorus" ? "chorus" : "verse";
                    const text = typeof (item as any).text === "string" ? (item as any).text : "";
                    if (!text) return null;
                    return { type, text };
                  })
                  .filter((item): item is { type: "chorus" | "verse"; text: string } => item !== null)
              : existing.structure;

            const next: LyricsData = {
              content: typeof payload.content === "string" ? payload.content : existing.content,
              structure: structured,
            };

            setLyrics(project.id, next);
            addLog("INFO", "AI", "Action Applied", "Lyrics updated by assistant", {
              projectId: project.id,
              length: next.content.length,
            });
            break;
          }
          case "updateProject": {
            const updates: Partial<Project> = {};
            if (typeof payload.name === "string" && payload.name.trim()) {
              updates.name = payload.name.trim();
            }
            if (Object.keys(updates).length > 0) {
              updateProjectMeta(project.id, updates);
              addLog("INFO", "AI", "Action Applied", "Project details updated by assistant", {
                projectId: project.id,
                updates,
              });
            }
            break;
          }
          case "updateImageInspiration": {
            const existing = latest.imageInspiration ?? {};
            const next = {
              ...existing,
              extractedPrompt:
                typeof payload.extractedPrompt === "string"
                  ? payload.extractedPrompt
                  : existing.extractedPrompt,
              colors: Array.isArray(payload.colors)
                ? (payload.colors as unknown[]).map((color) => String(color))
                : existing.colors,
            };
            setImageInspiration(project.id, next);
            addLog("INFO", "AI", "Action Applied", "Image inspiration updated by assistant", {
              projectId: project.id,
            });
            break;
          }
          default:
            addLog("WARN", "AI", "Action Ignored", "Unsupported assistant action", {
              projectId: project.id,
              action,
            });
        }
      });
    },
    [
      addLog,
      getProject,
      project,
      project.id,
      setImageInspiration,
      setLyrics,
      setRefinement,
      setTextPrompt,
      updateProjectMeta,
    ],
  );

  const sendMessageToGemini = async (conversation: ChatMessage[]): Promise<void> => {
    if (!geminiApiKey) {
      throw new Error("Gemini API key missing. Add it in API Settings to chat with the assistant.");
    }

    const latestProject = getProject(project.id) ?? project;
    const snapshot = {
      name: latestProject.name,
      textPrompt: latestProject.textPrompt,
      refinement: latestProject.refinement,
      lyrics: latestProject.lyrics?.content,
      lyricStructure: latestProject.lyrics?.structure,
      songStructure: latestProject.refinement?.structure,
    };

    const instructions = [
      "You are Muse, an AI collaborator embedded in a music creation workspace.",
      "Respond with STRICT JSON and nothing else.",
      "Schema:",
      '{',
      '  "reply": "natural language response for the user",',
      '  "actions": [',
      '    {"type": "updateRefinement", "payload": Partial<PromptRefinement>},',
      '    {"type": "updateTextPrompt", "payload": Partial<TextPrompt>},',
      '    {"type": "updateLyrics", "payload": {"content": string, "structure": [{"type": "verse"|"chorus","text": string}] }},',
      '    {"type": "updateProject", "payload": {"name": string}},',
      '    {"type": "updateImageInspiration", "payload": {"extractedPrompt": string, "colors": string[]}}',
      '  ],',
      '  "suggestions": ["short call-to-action strings"]',
      '}',
      "Only include actions when the user explicitly requests a change or when applying a clear improvement is helpful.",
      "If you cannot execute a request, explain in the reply and leave actions empty.",
      `Project snapshot:\n${JSON.stringify(snapshot, null, 2)}`,
    ].join("\n");

    const recentConversation = conversation.slice(-8).map((msg) => ({
      role: msg.role === "assistant" ? "model" : "user",
      parts: [{ text: msg.content }],
    }));

    const body = {
      contents: [
        {
          role: "user",
          parts: [{ text: instructions }],
        },
        ...recentConversation,
      ],
      generationConfig: {
        temperature: geminiTemperature ?? 0.7,
        topP: geminiTopP ?? 0.95,
        maxOutputTokens: Math.min(geminiMaxTokens ?? 1024, 1024),
      },
    };

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${geminiModel ?? "gemini-2.5-flash"}:generateContent?key=${geminiApiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      },
    );

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Gemini error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    const rawText = extractTextFromResponse(data);

    if (!rawText) {
      throw new Error("Gemini returned an empty response.");
    }

    const parsed = parseStructuredResult(rawText);
    const assistantReply = typeof parsed?.reply === "string" ? parsed.reply : rawText;
    const suggestions =
      Array.isArray(parsed?.suggestions) && parsed.suggestions.length > 0
        ? parsed.suggestions.map(String).slice(0, 3)
        : generateSuggestions(assistantReply);

    if (Array.isArray(parsed?.actions)) {
      applyActions(parsed.actions as AssistantAction[]);
    }

    const assistantMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: "assistant",
      content: assistantReply,
      timestamp: new Date(),
      suggestions,
    };

    setMessages((prev) => [...prev, assistantMessage]);

    addLog("INFO", "AI", "Chat Response", "Gemini assistant reply received", {
      projectId: project.id,
      replyLength: assistantReply.length,
      actionCount: Array.isArray(parsed?.actions) ? parsed.actions.length : 0,
    });
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    if (!geminiApiKey) {
      toast.error("Add your Gemini API key in API Settings to chat with the assistant.");
      return;
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    const conversation = [...messages, userMessage];
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    addLog("INFO", "AI", "Chat Message", "User sent message", {
      messageLength: input.length,
      projectId: project.id
    });

    try {
      await sendMessageToGemini(conversation);
    } catch (error) {
      const errorText = error instanceof Error ? error.message : "Unknown error";
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "I apologize, but I encountered an error. Please try again.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
      toast.error(errorText);
      
      addLog("ERROR", "AI", "Chat Error", "Failed to get AI response", {
        error: errorText,
        projectId: project.id
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateSuggestions = (userInput: string): string[] => {
    const suggestions: string[] = [];
    const lowerInput = userInput.toLowerCase();

    if (lowerInput.includes('instrument')) {
      suggestions.push("Try acoustic vs electric versions", "Add percussion elements", "Consider orchestral additions");
    } else if (lowerInput.includes('lyrics')) {
      suggestions.push("Focus on storytelling", "Use more metaphors", "Experiment with rhyme schemes");
    } else if (lowerInput.includes('tempo')) {
      suggestions.push("Test different BPM ranges", "Consider rhythmic variations", "Experiment with time signatures");
    } else {
      suggestions.push("Refine your musical vision", "Consider the emotional journey", "Think about production style");
    }

    return suggestions.slice(0, 3);
  };

  const applySuggestion = (suggestion: string) => {
    setInput(suggestion);
    addLog("INFO", "AI", "Suggestion Applied", "User applied AI suggestion", {
      suggestion,
      projectId: project.id
    });
  };

  return (
    <Card className="h-[calc(100vh-12rem)]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Bot className="w-5 h-5 text-primary" />
          AI Assistant
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        {/* Messages */}
        <ScrollArea className="h-[400px] px-4" ref={scrollAreaRef}>
          <div className="space-y-4 pb-4">
            {messages.map((message) => (
              <div key={message.id} className="space-y-2">
                <div className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`flex gap-2 max-w-[80%] ${message.role === 'user' ? 'flex-row-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {message.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                    </div>
                    <div className={`rounded-lg p-3 ${
                      message.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}>
                      <p className="text-sm">{message.content}</p>
                    </div>
                  </div>
                </div>

                {/* Suggestions */}
                {message.role === 'assistant' && message.suggestions && (
                  <div className="ml-11 space-y-2">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Lightbulb className="w-3 h-3" />
                      <span>Suggestions:</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {message.suggestions.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          onClick={() => applySuggestion(suggestion)}
                          className="h-6 text-xs px-2"
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="bg-muted rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        <Separator />

        {/* Input */}
        <div className="p-4 space-y-3">
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask me anything about your music..."
              rows={2}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              className="resize-none"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!input.trim() || isLoading}
              size="icon"
              className="flex-shrink-0"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap gap-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setInput("Suggest instrument combinations for my project")}
              className="h-7 text-xs px-2"
            >
              <Wand2 className="w-3 h-3 mr-1" />
              Instruments
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setInput("Help me improve my lyrics structure")}
              className="h-7 text-xs px-2"
            >
              <Sparkles className="w-3 h-3 mr-1" />
              Lyrics
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
