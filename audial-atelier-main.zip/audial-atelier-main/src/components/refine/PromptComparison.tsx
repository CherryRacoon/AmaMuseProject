import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { GitCompare, Check, X, Plus, Star } from "lucide-react";
import { Project, PromptVersion, useProjectStore } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";

// using PromptVersion type from project store

interface PromptComparisonProps {
  project: Project;
}

export const PromptComparison = ({ project }: PromptComparisonProps) => {
  const { addLog } = useDebugLog();

  const { addPromptVersion, updateProject, getProject } = useProjectStore();

  // Use real versions from project state
  const versions = project.promptVersions ?? [];
  const [selectedVersions, setSelectedVersions] = useState<string[]>(versions.length > 0 ? [versions[0].id] : []);
  const [comparisonMode, setComparisonMode] = useState<'side-by-side' | 'overlay'>('side-by-side');

  const createNewVersion = () => {
    const newVersion: PromptVersion = {
      id: `v-${Date.now()}`,
      prompt: project.refinement?.enhancedPrompt || 'Custom prompt',
      instruments: project.refinement?.instruments || [],
      emotions: project.refinement?.emotions || [],
      tempo: undefined,
      vocalType: project.refinement?.vocalType,
      createdAt: new Date().toISOString(),
    };

    addPromptVersion(project.id, newVersion);
    setSelectedVersions([newVersion.id]);

    addLog("INFO", "System", "Version Created", "New prompt version created", {
      versionId: newVersion.id,
      projectId: project.id,
    });
  };

  const selectVersion = (versionId: string) => {
    setSelectedVersions(prev => {
      if (prev.includes(versionId)) {
        return prev.filter(id => id !== versionId);
      } else if (prev.length < 2) {
        return [...prev, versionId];
      } else {
        return [prev[1], versionId]; // Replace first with new selection
      }
    });
  };

  const rateVersion = (versionId: string, rating: number) => {
    // Update in store
    const p = getProject(project.id);
    if (!p) return;
    const updated = (p.promptVersions || []).map((v) => (v.id === versionId ? { ...v, rating } : v));
    updateProject(project.id, { promptVersions: updated });

    addLog("INFO", "System", "Version Rated", `Version ${versionId} rated ${rating} stars`, {
      versionId,
      rating,
      projectId: project.id
    });
  };

  const selectedVersionData = versions.filter((v) => selectedVersions.includes(v.id));

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <GitCompare className="w-5 h-5 text-primary" />
              Prompt Comparison
            </div>
            <Button onClick={createNewVersion} size="sm" className="gap-2">
              <Plus className="w-4 h-4" />
              New Version
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Version List */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Available Versions</h4>
            <ScrollArea className="h-32">
              <div className="space-y-2">
                {versions.map((version) => (
                  <div
                    key={version.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      selectedVersions.includes(version.id)
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:bg-muted/50'
                    }`}
                    onClick={() => selectVersion(version.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-4 h-4 rounded border-2 flex items-center justify-center ${
                          selectedVersions.includes(version.id)
                            ? 'border-primary bg-primary'
                            : 'border-muted-foreground'
                        }`}>
                          {selectedVersions.includes(version.id) && (
                            <Check className="w-3 h-3 text-primary-foreground" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium">Version {version.id}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(version.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>

                      {/* Rating */}
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            onClick={(e) => {
                              e.stopPropagation();
                              rateVersion(version.id, star);
                            }}
                            className="focus:outline-none"
                          >
                            <Star
                              className={`w-4 h-4 ${
                                (version.rating || 0) >= star
                                  ? 'text-yellow-500 fill-current'
                                  : 'text-muted-foreground'
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>

          <Separator />

          {/* Comparison View */}
          {selectedVersionData.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium">Comparison</h4>
                <div className="flex gap-2">
                  <Button
                    variant={comparisonMode === 'side-by-side' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setComparisonMode('side-by-side')}
                  >
                    Side by Side
                  </Button>
                  <Button
                    variant={comparisonMode === 'overlay' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setComparisonMode('overlay')}
                  >
                    Overlay
                  </Button>
                </div>
              </div>

              {comparisonMode === 'side-by-side' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedVersionData.map((version, index) => (
                    <Card key={version.id} className="p-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Badge variant="secondary">Version {version.id}</Badge>
                          {version.rating && (
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-yellow-500 fill-current" />
                              <span className="text-sm">{version.rating}</span>
                            </div>
                          )}
                        </div>

                        <div className="space-y-2">
                          <p className="text-sm font-medium">Prompt:</p>
                          <p className="text-sm text-muted-foreground bg-muted p-2 rounded">
                            {version.prompt}
                          </p>
                        </div>

                        {version.instruments.length > 0 && (
                          <div className="space-y-2">
                            <p className="text-sm font-medium">Instruments:</p>
                            <div className="flex flex-wrap gap-1">
                              {version.instruments.map((instrument) => (
                                <Badge key={instrument} variant="outline" className="text-xs">
                                  {instrument}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        {version.emotions.length > 0 && (
                          <div className="space-y-2">
                            <p className="text-sm font-medium">Emotions:</p>
                            <div className="flex flex-wrap gap-1">
                              {version.emotions.map((emotion) => (
                                <Badge key={emotion} variant="outline" className="text-xs">
                                  {emotion}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-4">
                  <div className="space-y-4">
                    {selectedVersionData.map((version, index) => (
                      <div key={version.id} className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">Version {version.id}</Badge>
                          {version.rating && (
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-yellow-500 fill-current" />
                              <span className="text-sm">{version.rating}</span>
                            </div>
                          )}
                        </div>
                        <div className="bg-muted p-3 rounded">
                          <p className="text-sm">{version.prompt}</p>
                        </div>
                        {index < selectedVersionData.length - 1 && <Separator />}
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>
          )}

          {selectedVersionData.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <GitCompare className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Select versions to compare them side by side</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};