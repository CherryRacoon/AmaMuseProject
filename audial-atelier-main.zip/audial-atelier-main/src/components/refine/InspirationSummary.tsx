import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Mic, FileText, Music, Image as ImageIcon, Play, FileAudio, Sparkles } from "lucide-react";
import { Project } from "@/stores/useProjectStore";

interface InspirationSummaryProps {
  project: Project;
}

export const InspirationSummary = ({ project }: InspirationSummaryProps) => {
  const hasAudio = !!project.audioInput;
  const hasText = !!project.textPrompt;
  const hasLyrics = !!project.lyrics;
  const hasImage = !!project.imageInspiration;
  const imageAnalysis = project.imageInspiration?.analysis;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Captured Inspiration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Audio Input */}
          {hasAudio && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Mic className="w-4 h-4 text-blue-500" />
                <span className="font-medium">Audio Input</span>
                <Badge variant="secondary">{project.audioInput?.type}</Badge>
              </div>
              <div className="pl-6 space-y-2">
                {project.audioInput?.type === "recording" && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Play className="w-3 h-3" />
                    <span>Recorded audio ({project.audioInput.duration}s)</span>
                  </div>
                )}
                {project.audioInput?.type === "upload" && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <FileAudio className="w-3 h-3" />
                    <span>Uploaded file</span>
                  </div>
                )}
                {project.audioInput?.type === "youtube" && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Play className="w-3 h-3" />
                    <span>YouTube: {project.audioInput.url}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Text Prompt */}
          {hasText && (
            <>
              {hasAudio && <Separator />}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-green-500" />
                  <span className="font-medium">Text Prompt</span>
                </div>
                <div className="pl-6">
                  <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md">
                    {project.textPrompt?.text}
                  </p>
                  {project.textPrompt?.mood && project.textPrompt.mood.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {project.textPrompt.mood.map((mood) => (
                        <Badge key={mood} variant="outline" className="text-xs">
                          {mood}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </>
          )}

          {/* Lyrics */}
          {hasLyrics && (
            <>
              {(hasAudio || hasText) && <Separator />}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Music className="w-4 h-4 text-purple-500" />
                  <span className="font-medium">Lyrics</span>
                  <Badge variant="secondary">
                    {project.lyrics?.structure.length} sections
                  </Badge>
                </div>
                <div className="pl-6">
                  <div className="text-sm text-muted-foreground bg-muted p-3 rounded-md whitespace-pre-wrap">
                    {project.lyrics?.content}
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Image Inspiration */}
          {hasImage && (
            <>
              {(hasAudio || hasText || hasLyrics) && <Separator />}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-orange-500" />
                  <span className="font-medium">Image Inspiration</span>
                </div>
                <div className="pl-6 space-y-3">
                  {imageAnalysis ? (
                    <>
                      <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md leading-relaxed">
                        {imageAnalysis.description}
                      </p>
                      <div className="grid gap-3 sm:grid-cols-2">
                        {imageAnalysis.emotions.length > 0 && (
                          <div>
                            <span className="text-xs uppercase text-muted-foreground">Emotions</span>
                            <div className="mt-2 flex flex-wrap gap-1.5">
                              {imageAnalysis.emotions.map((emotion) => (
                                <Badge key={emotion} variant="secondary" className="text-xs">
                                  {emotion}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        {imageAnalysis.style.length > 0 && (
                          <div>
                            <span className="text-xs uppercase text-muted-foreground">Style</span>
                            <div className="mt-2 flex flex-wrap gap-1.5">
                              {imageAnalysis.style.map((style) => (
                                <Badge key={style} variant="outline" className="text-xs">
                                  {style}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        {imageAnalysis.timing && (
                          <div>
                            <span className="text-xs uppercase text-muted-foreground">Timing</span>
                            <div className="mt-2">
                              <Badge variant="outline" className="text-xs">
                                {imageAnalysis.timing}
                              </Badge>
                            </div>
                          </div>
                        )}
                        {imageAnalysis.feeling && (
                          <div className="sm:col-span-2">
                            <span className="text-xs uppercase text-muted-foreground">Feeling</span>
                            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                              {imageAnalysis.feeling}
                            </p>
                          </div>
                        )}
                      </div>
                      {project.imageInspiration?.extractedPrompt && (
                        <div className="space-y-1">
                          <span className="text-xs uppercase text-muted-foreground">Prompt Starter</span>
                          <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md leading-relaxed">
                            {project.imageInspiration.extractedPrompt}
                          </p>
                        </div>
                      )}
                    </>
                  ) : (
                    project.imageInspiration?.extractedPrompt && (
                      <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md leading-relaxed">
                        {project.imageInspiration.extractedPrompt}
                      </p>
                    )
                  )}
                  {project.imageInspiration?.colors && project.imageInspiration.colors.length > 0 && (
                    <div className="space-y-1">
                      <span className="text-xs uppercase text-muted-foreground">Colors</span>
                      <div className="flex flex-wrap gap-1.5">
                        {project.imageInspiration.colors.map((color) => (
                          <div
                            key={color}
                            className="h-5 w-5 rounded-full border border-border shadow-sm"
                            style={{ backgroundColor: color }}
                            title={color}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}

          {/* No inspiration captured */}
          {!hasAudio && !hasText && !hasLyrics && !hasImage && (
            <div className="text-center py-8 text-muted-foreground">
              <Sparkles className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No inspiration captured yet. Go back to the Capture page to add some input.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
