import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Sparkles, LayoutList, Save } from "lucide-react";
import type { Project, PromptRefinement } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";

interface SongStructurePlannerProps {
  project: Project;
  onSave: (refinement: Partial<PromptRefinement>) => void;
}

const SECTION_OPTIONS = [
  "Intro",
  "Verse",
  "Pre-Chorus",
  "Chorus",
  "Post-Chorus",
  "Bridge",
  "Solo",
  "Breakdown",
  "Build-up",
  "Outro",
];

const STRUCTURE_TEMPLATES = {
  classical: {
    label: "Classical",
    description: "Traditional AABA-inspired arc with clear exposition and resolution.",
    sections: [
      "Overture",
      "Verse",
      "Verse",
      "Chorus",
      "Verse",
      "Bridge",
      "Chorus",
      "Coda",
    ],
  },
  modern: {
    label: "Modern Pop",
    description: "Radio-ready flow with dynamic pre-chorus lift and memorable hook.",
    sections: [
      "Intro",
      "Verse",
      "Pre-Chorus",
      "Chorus",
      "Verse",
      "Pre-Chorus",
      "Chorus",
      "Bridge",
      "Chorus",
      "Outro",
    ],
  },
  punk: {
    label: "Punk",
    description: "High-energy burst with minimal sections and relentless drive.",
    sections: [
      "Count-in",
      "Verse",
      "Chorus",
      "Verse",
      "Chorus",
      "Solo",
      "Chorus",
      "Outro",
    ],
  },
  rock: {
    label: "Rock & Roll",
    description: "Classic rock momentum featuring a guitar solo spotlight.",
    sections: [
      "Intro",
      "Verse",
      "Chorus",
      "Verse",
      "Chorus",
      "Solo",
      "Bridge",
      "Chorus",
      "Outro",
    ],
  },
} as const;

type TemplateKey = keyof typeof STRUCTURE_TEMPLATES;

export const SongStructurePlanner = ({ project, onSave }: SongStructurePlannerProps) => {
  const { addLog } = useDebugLog();
  const currentStructure = project.refinement?.structure ?? [];
  // start with an empty flow per UX request (no pre-existing tags)
  const [structure, setStructure] = useState<string[]>(
    currentStructure.length > 0 ? currentStructure : [],
  );
  // start with no selection so the Select shows the placeholder
  const [selectedSection, setSelectedSection] = useState<string>("");
  const [customSection, setCustomSection] = useState<string>("");

  useEffect(() => {
    const nextStructure = project.refinement?.structure;
    if (nextStructure && nextStructure.join("|") !== structure.join("|")) {
      setStructure(nextStructure);
    }
  }, [project.refinement?.structure, structure]);

  const canSave = useMemo(() => structure.length > 0, [structure]);

  const applyTemplate = (template: TemplateKey) => {
    const { sections, label } = STRUCTURE_TEMPLATES[template];
    setStructure([...sections]);
    addLog("INFO", "System", "Structure Template Applied", "Applied lyric structure template", {
      template: label,
      sections: sections.length,
    });
  };

  const addSection = (section: string) => {
    const formatted = section.trim();
    if (!formatted) return;
    setStructure((prev) => [...prev, formatted]);
  };

  const removeSection = (index: number) => {
    setStructure((prev) => prev.filter((_, idx) => idx !== index));
  };

  // shuffle removed — deterministic ordering is preferred for structure planning

  const handleSave = () => {
    if (!canSave) return;
    onSave({ structure });
    addLog("INFO", "System", "Song Structure Saved", "Updated lyric structure layout", {
      sections: structure.length,
      preview: structure.join(" → "),
    });
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <LayoutList className="w-5 h-5 text-primary" />
          Song Structure Planner
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          <Label className="text-sm font-medium text-muted-foreground">Current Flow</Label>
          <div className="flex flex-wrap gap-2">
            {structure.map((section, index) => (
              <Badge
                key={`${section}-${index}`}
                variant="secondary"
                className="flex items-center gap-2 text-xs"
              >
                <span className="font-semibold">{index + 1}.</span>
                {section}
                <button
                  type="button"
                  onClick={() => removeSection(index)}
                  className="ml-1 text-muted-foreground hover:text-destructive focus:outline-none"
                  aria-label={`Remove ${section}`}
                >
                  ×
                </button>
              </Badge>
            ))}
            {structure.length === 0 && (
              <span className="text-xs text-muted-foreground">Select sections to create structure or use templates below.</span>
            )}
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <Label className="text-sm font-medium">Add Section</Label>
          <div className="flex flex-col sm:flex-row gap-2">
            <Select value={selectedSection} onValueChange={setSelectedSection}>
              <SelectTrigger className="sm:min-w-[160px]">
                <SelectValue placeholder="Select section" />
              </SelectTrigger>
              <SelectContent>
                {SECTION_OPTIONS.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => addSection(selectedSection)} disabled={!selectedSection}>
              Add Section
            </Button>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Input
              value={customSection}
              onChange={(e) => setCustomSection(e.target.value)}
              placeholder="Custom label (e.g., Breakdown, Drop)"
            />
            <Button
              variant="secondary"
              onClick={() => {
                addSection(customSection);
                setCustomSection("");
              }}
              disabled={!customSection.trim()}
            >
              Add Custom
            </Button>
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">Inspired Templates</span>
          </div>
          <div className="space-y-4">
            {(Object.entries(STRUCTURE_TEMPLATES) as [TemplateKey, typeof STRUCTURE_TEMPLATES[TemplateKey]][]).map(
              ([key, template]) => (
                <div key={key} className="rounded-lg border border-border p-4 space-y-3">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold">{template.label}</p>
                      <p className="text-xs text-muted-foreground">{template.description}</p>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => applyTemplate(key)}>
                      Use Template
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {template.sections.map((section, index) => (
                      <Badge key={`${template.label}-${section}-${index}`} variant="outline" className="text-[10px]">
                        {section}
                      </Badge>
                    ))}
                  </div>
                </div>
              ),
            )}
          </div>
        </div>

        <Separator />

        <div className="flex items-center justify-between">
          <div className="text-xs text-muted-foreground">
            Use templates or build your own to guide lyric pacing and dynamics.
          </div>
          <Button onClick={handleSave} disabled={!canSave} className="gap-2">
            <Save className="w-4 h-4" />
            Save Structure
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
