import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Music2, Clock, Play } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useProjectStore } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { toast } from "sonner";

export const ProjectDashboard = () => {
  const navigate = useNavigate();
  const { projects: storeProjects, createProject } = useProjectStore();
  const { addLog } = useDebugLog();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [projectName, setProjectName] = useState("");

  const handleCreateProject = () => {
    if (!projectName.trim()) {
      toast.error("Please enter a project name");
      return;
    }

    const projectId = createProject(projectName);
    
    addLog("INFO", "System", "Project Created", "New project initialized", {
      projectId,
      name: projectName,
    });

    toast.success(`Project "${projectName}" created!`);
    setIsDialogOpen(false);
    setProjectName("");
    navigate("/create");
  };

  const projects = [
    {
      id: 1,
      title: "Summer Vibes",
      genre: "Pop",
      duration: "2:45",
      createdAt: "2 days ago",
      thumbnail: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    },
    {
      id: 2,
      title: "Night Drive",
      genre: "Electronic",
      duration: "3:12",
      createdAt: "5 days ago",
      thumbnail: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
    },
    {
      id: 3,
      title: "Acoustic Dreams",
      genre: "Folk",
      duration: "2:30",
      createdAt: "1 week ago",
      thumbnail: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary via-primary to-accent p-12 text-center shadow-glow">
        <div className="relative z-10">
          <h2 className="text-4xl font-bold text-primary-foreground mb-4">
            Create Amazing Music with AI
          </h2>
          <p className="text-lg text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            Collaborate with cutting-edge AI models to generate, edit, and perfect your musical ideas
          </p>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg" variant="secondary" className="gap-2 shadow-lg">
                <Plus className="w-5 h-5" />
                New Project
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Project</DialogTitle>
                <DialogDescription>
                  Give your music project a name to get started
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Project Name</Label>
                  <Input
                    id="name"
                    placeholder="My Awesome Track"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleCreateProject()}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateProject}>Create Project</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent"></div>
      </div>

      {/* Projects Grid */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-2xl font-bold text-foreground">Your Projects</h3>
            <p className="text-sm text-muted-foreground mt-1">Recent compositions and works in progress</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <Card
              key={project.id}
              className="group overflow-hidden hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 cursor-pointer border-border bg-card"
            >
              <div
                className="h-40 relative"
                style={{ background: project.thumbnail }}
              >
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                  <Button
                    size="icon"
                    className="w-16 h-16 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-xl"
                  >
                    <Play className="w-6 h-6 ml-1" />
                  </Button>
                </div>
              </div>
              <div className="p-5">
                <h4 className="font-semibold text-lg text-foreground mb-2">{project.title}</h4>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Music2 className="w-4 h-4" />
                    {project.genre}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {project.duration}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mt-3">{project.createdAt}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};
