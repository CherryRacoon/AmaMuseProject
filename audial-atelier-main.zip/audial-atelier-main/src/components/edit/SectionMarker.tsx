import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Wand2, GripVertical } from "lucide-react";

interface Section {
  id: string;
  name: string;
  startTime: number;
  endTime: number;
  color: string;
}

interface SectionMarkerProps {
  section: Section;
  startX: number;
  width: number;
  isSelected: boolean;
  isDragging: boolean;
  onClick: () => void;
  onDragStart: () => void;
  onDragEnd: () => void;
  onRegenerate: () => void;
}

const SectionMarker = ({
  section,
  startX,
  width,
  isSelected,
  isDragging,
  onClick,
  onDragStart,
  onDragEnd,
  onRegenerate
}: SectionMarkerProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`absolute top-0 h-full cursor-pointer transition-all duration-200 ${
        isDragging ? 'z-50' : 'z-10'
      }`}
      style={{
        left: startX,
        width: width,
        transform: isDragging ? 'scale(1.05)' : 'scale(1)'
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
    >
      {/* Section background */}
      <div
        className={`h-8 rounded-sm border-2 transition-all duration-200 ${
          isSelected
            ? 'border-white shadow-lg'
            : 'border-transparent'
        }`}
        style={{
          backgroundColor: section.color,
          opacity: isSelected ? 0.9 : 0.7
        }}
      />

      {/* Section label */}
      <div className="absolute top-1 left-2 text-xs font-medium text-white drop-shadow-sm">
        {section.name}
      </div>

      {/* Section time range */}
      <div className="absolute bottom-1 left-2 text-xs text-white/80 drop-shadow-sm">
        {Math.floor(section.startTime / 60)}:{(section.startTime % 60).toString().padStart(2, '0')} - {Math.floor(section.endTime / 60)}:{(section.endTime % 60).toString().padStart(2, '0')}
      </div>

      {/* Hover controls */}
      {(isHovered || isSelected) && (
        <div className="absolute -top-8 left-0 flex gap-1">
          <Button
            size="sm"
            variant="secondary"
            className="h-6 px-2 text-xs"
            onClick={(e) => {
              e.stopPropagation();
              onRegenerate();
            }}
          >
            <Wand2 className="w-3 h-3 mr-1" />
            AI
          </Button>
          <div
            className="h-6 w-6 bg-secondary rounded flex items-center justify-center cursor-grab active:cursor-grabbing"
            onMouseDown={(e) => {
              e.stopPropagation();
              onDragStart();
            }}
            onMouseUp={onDragEnd}
          >
            <GripVertical className="w-3 h-3" />
          </div>
        </div>
      )}

      {/* Resize handles */}
      {isSelected && (
        <>
          {/* Left resize handle */}
          <div
            className="absolute left-0 top-0 bottom-0 w-1 bg-white cursor-ew-resize hover:bg-blue-400"
            onMouseDown={(e) => {
              e.stopPropagation();
              // Handle left resize
            }}
          />

          {/* Right resize handle */}
          <div
            className="absolute right-0 top-0 bottom-0 w-1 bg-white cursor-ew-resize hover:bg-blue-400"
            onMouseDown={(e) => {
              e.stopPropagation();
              // Handle right resize
            }}
          />
        </>
      )}
    </div>
  );
};

export { SectionMarker };