import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Loader2, X, ExternalLink } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetClose,
} from "@/components/ui/sheet";

interface ExternalSheetMusicSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  url: string;
  title?: string;
}

export const ExternalSheetMusicSheet = ({ open, onOpenChange, url, title = "External Sheet Music" }: ExternalSheetMusicSheetProps) => {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const timeoutRef = useRef<number | null>(null);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  useEffect(() => {
    if (open) {
      setLoaded(false);
      setFailed(false);

      // If iframe doesn't load within X ms, show fallback (handles CSP/X-Frame-Options)
      timeoutRef.current = window.setTimeout(() => {
        if (!loaded) {
          setFailed(true);
        }
      }, 8000);
    } else {
      // Clean up
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      setLoaded(false);
      setFailed(false);
    }

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };
  }, [open, loaded]);

  const handleIFrameLoad = () => {
    // If iframe loads successfully, clear the timeout and mark loaded
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setLoaded(true);
    setFailed(false);
  };

  const handleIFrameError = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setLoaded(false);
    setFailed(true);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="rounded-t-xl shadow-xl backdrop-blur-sm">
        <div className="flex items-center justify-between mb-3">
          <SheetHeader className="p-0">
            <SheetTitle className="flex items-center gap-2">
              <span className="text-lg font-semibold">{title}</span>
              {loaded && <Badge variant="secondary">Embedded</Badge>}
            </SheetTitle>
          </SheetHeader>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.open(url, "_blank", "noopener,noreferrer")}
              className="gap-2"
            >
              <ExternalLink className="w-4 h-4" />
              Open in new tab
            </Button>

            {/* SheetClose is already wired into SheetContent; include a visible close button too */}
            <SheetClose asChild>
              <Button variant="ghost" size="sm" className="p-2">
                <X className="w-4 h-4" />
              </Button>
            </SheetClose>
          </div>
        </div>

        <Separator />

        <div className="mt-4">
          {!loaded && !failed && (
            <div className="flex flex-col items-center justify-center gap-4 py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Loading embedded editor…</p>
            </div>
          )}

          {failed && (
            <div className="p-6 text-center space-y-4">
              <p className="text-lg font-medium">Cannot embed the sheet editor</p>
              <p className="text-sm text-muted-foreground">
                The external site prevented embedding (CSP / X-Frame-Options). You can open it in a new tab.
              </p>
              <div className="flex items-center justify-center gap-3">
                <Button onClick={() => window.open(url, "_blank", "noopener,noreferrer")}>
                  Open in new tab
                </Button>
                <Button variant="outline" onClick={() => onOpenChange(false)}>
                  Close
                </Button>
              </div>
            </div>
          )}

          {!failed && (
            <div style={{ height: 'calc(100vh - 160px)' }} className={`${loaded ? '' : 'opacity-0'} transition-opacity`}>
              <iframe
                ref={iframeRef}
                src={url}
                title="External Sheet Music"
                onLoad={handleIFrameLoad}
                onError={handleIFrameError}
                allow="clipboard-write; fullscreen; camera; microphone; accelerometer; gyroscope; geolocation"
                sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox"
                allowFullScreen
                style={{ width: '100%', height: '100%', border: 'none', borderRadius: 8 }}
              />
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default ExternalSheetMusicSheet;
