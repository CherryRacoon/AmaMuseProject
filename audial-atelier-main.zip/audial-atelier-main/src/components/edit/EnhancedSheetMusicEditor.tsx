import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Music, ZoomIn, ZoomOut, Download, FileDown, Printer, Play, Pause,
  SkipBack, SkipForward, Edit3, Trash2, Plus, Sparkles, RefreshCw,
  Settings, Piano, AlertCircle, CheckCircle
} from "lucide-react";

interface Note {
  id: string;
  pitch: string;
  octave: number;
  duration: number;
  measure: number;
  beat: number;
  isCorrect: boolean;
  suggestion?: string;
}

interface SheetSection {
  id: string;
  name: string;
  timeSignature: string;
  keySignature: string;
  tempo: number;
  measures: number;
}

interface EnhancedSheetMusicEditorProps {
  onNotesChange?: (notes: Note[]) => void;
}

export default function EnhancedSheetMusicEditor({ onNotesChange }: EnhancedSheetMusicEditorProps) {
  const [zoomLevel, setZoomLevel] = useState(100);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [selectedNote, setSelectedNote] = useState<string | null>(null);
  const [tempo, setTempo] = useState(120);
  const [transcriptionMethod, setTranscriptionMethod] = useState("auto");
  const [difficulty, setDifficulty] = useState(50);
  
  const [sections] = useState<SheetSection[]>([
    { id: "intro", name: "Intro", timeSignature: "4/4", keySignature: "C Major", tempo: 120, measures: 4 },
    { id: "verse1", name: "Verse 1", timeSignature: "4/4", keySignature: "C Major", tempo: 120, measures: 8 },
    { id: "chorus", name: "Chorus", timeSignature: "4/4", keySignature: "C Major", tempo: 120, measures: 8 },
  ]);
  
  const [selectedSection, setSelectedSection] = useState("verse1");

  const [notes] = useState<Note[]>([
    { id: "n1", pitch: "C", octave: 4, duration: 1, measure: 1, beat: 1, isCorrect: true },
    { id: "n2", pitch: "E", octave: 4, duration: 1, measure: 1, beat: 2, isCorrect: true },
    { id: "n3", pitch: "G", octave: 4, duration: 1, measure: 1, beat: 3, isCorrect: false, suggestion: "F#" },
    { id: "n4", pitch: "C", octave: 5, duration: 2, measure: 1, beat: 4, isCorrect: true },
  ]);

  const currentSection = sections.find(s => s.id === selectedSection);
  const correctNotes = notes.filter(n => n.isCorrect).length;
  const totalNotes = notes.length;
  const accuracy = Math.round((correctNotes / totalNotes) * 100);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleExport = (format: string) => {
    console.log(`Exporting as ${format}`);
  };

  const handleRegenerateFromAudio = () => {
    console.log("Regenerating from audio with method:", transcriptionMethod);
  };

  const handleAdjustDifficulty = () => {
    console.log("Adjusting difficulty to:", difficulty);
  };

  const handleApplySuggestions = () => {
    console.log("Applying AI suggestions");
  };

  const handleTranspose = () => {
    console.log("Transposing to new key");
  };

  const handleFixIssues = () => {
    console.log("Auto-fixing detected issues");
  };

  const getNoteSymbol = (duration: number) => {
    if (duration >= 4) return "𝅝";
    if (duration >= 2) return "𝅗𝅥";
    if (duration >= 1) return "𝅘𝅥";
    return "𝅘𝅥𝅮";
  };

  const getNoteYPosition = (pitch: string, octave: number) => {
    const noteOrder = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
    const pitchIndex = noteOrder.indexOf(pitch);
    const octaveOffset = (octave - 4) * 7;
    return 80 - (pitchIndex + octaveOffset) * 4;
  };

  return (
    <div className="flex flex-col h-full gap-4">
      {/* Top Toolbar */}
      <Card>
        <CardContent className="p-3">
          <div className="flex items-center justify-between gap-4">
            {/* File Operations */}
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => handleExport("pdf")}>
                <FileDown className="w-3 h-3 mr-1" />
                Export PDF
              </Button>
              <Button size="sm" variant="outline" onClick={() => handleExport("musicxml")}>
                <Download className="w-3 h-3 mr-1" />
                MusicXML
              </Button>
              <Button size="sm" variant="outline">
                <Printer className="w-3 h-3 mr-1" />
                Print
              </Button>
            </div>

            {/* Zoom Controls */}
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setZoomLevel(Math.max(50, zoomLevel - 25))}
              >
                <ZoomOut className="w-3 h-3" />
              </Button>
              <span className="text-xs text-muted-foreground min-w-[50px] text-center">
                {zoomLevel}%
              </span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setZoomLevel(Math.min(200, zoomLevel + 25))}
              >
                <ZoomIn className="w-3 h-3" />
              </Button>
            </div>

            {/* Playback Controls */}
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline">
                <SkipBack className="w-3 h-3" />
              </Button>
              <Button size="sm" onClick={handlePlayPause}>
                {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              </Button>
              <Button size="sm" variant="outline">
                <SkipForward className="w-3 h-3" />
              </Button>
              <span className="text-xs text-muted-foreground">0:00 / 3:00</span>
            </div>

            {/* Tempo */}
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setTempo(Math.max(40, tempo - 10))}
              >
                -
              </Button>
              <span className="text-xs text-muted-foreground min-w-[60px] text-center">
                {tempo} BPM
              </span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setTempo(Math.min(240, tempo + 10))}
              >
                +
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content */}
      <div className="grid gap-4 md:grid-cols-[180px_1fr_300px] flex-1 overflow-hidden">
        {/* Left Panel - Section Navigator */}
        <Card className="flex flex-col overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Sections</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden p-0">
            <ScrollArea className="h-full px-4 pb-4">
              <div className="space-y-1">
                {sections.map((section) => (
                  <div
                    key={section.id}
                    className={`p-2 rounded-md cursor-pointer transition-colors ${
                      selectedSection === section.id
                        ? 'bg-primary/10 border border-primary'
                        : 'hover:bg-muted'
                    }`}
                    onClick={() => setSelectedSection(section.id)}
                  >
                    <div className="text-sm font-medium">{section.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {section.measures} measures
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
          
          {/* Section Properties */}
          {currentSection && (
            <div className="border-t p-3 space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Time:</span>
                <span className="font-medium">{currentSection.timeSignature}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Key:</span>
                <span className="font-medium">{currentSection.keySignature}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tempo:</span>
                <span className="font-medium">{currentSection.tempo} BPM</span>
              </div>
            </div>
          )}
        </Card>

        {/* Center Panel - Sheet Music Display */}
        <Card className="flex flex-col overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Music className="w-4 h-4" />
              Sheet Music
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden p-0">
            <ScrollArea className="h-full">
              <div className="p-6" style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top left' }}>
                {/* Staff lines */}
                <div className="relative mb-8">
                  {Array.from({ length: 5 }, (_, i) => (
                    <div
                      key={i}
                      className="absolute w-full border-t border-foreground/30"
                      style={{ top: i * 10, height: 10 }}
                    />
                  ))}

                  {/* Clef */}
                  <div className="absolute left-0 top-0 text-4xl">𝄞</div>

                  {/* Time signature */}
                  <div className="absolute left-12 top-0 flex flex-col items-center text-lg font-bold">
                    <div>4</div>
                    <div>4</div>
                  </div>

                  {/* Notes */}
                  <div className="ml-24 relative">
                    {notes.map((note, index) => {
                      const x = index * 60;
                      const y = getNoteYPosition(note.pitch, note.octave);

                      return (
                        <div
                          key={note.id}
                          className={`absolute cursor-pointer transition-all ${
                            selectedNote === note.id ? 'scale-125' : 'hover:scale-110'
                          }`}
                          style={{ left: x, top: y - 12 }}
                          onClick={() => setSelectedNote(note.id)}
                        >
                          <div className={`text-3xl select-none ${
                            note.isCorrect ? 'text-foreground' : 'text-destructive'
                          }`}>
                            {getNoteSymbol(note.duration)}
                          </div>
                          
                          {!note.isCorrect && (
                            <div className="absolute -top-2 -right-2">
                              <AlertCircle className="w-4 h-4 text-destructive" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Statistics */}
                <div className="grid grid-cols-3 gap-3 mt-6">
                  <div className="text-center p-3 border rounded-lg">
                    <div className="text-lg font-semibold">{totalNotes}</div>
                    <div className="text-xs text-muted-foreground">Total Notes</div>
                  </div>
                  <div className="text-center p-3 border rounded-lg">
                    <div className="text-lg font-semibold text-green-600">{correctNotes}</div>
                    <div className="text-xs text-muted-foreground">Correct</div>
                  </div>
                  <div className="text-center p-3 border rounded-lg">
                    <div className="text-lg font-semibold text-red-600">
                      {totalNotes - correctNotes}
                    </div>
                    <div className="text-xs text-muted-foreground">Errors</div>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Right Panel - Note Editor & AI Tools */}
        <Card className="flex flex-col overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Tools
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden p-0">
            <ScrollArea className="h-full">
              <div className="p-4 space-y-4">
                {/* Selected Note Editor */}
                {selectedNote && (
                  <div className="space-y-3 pb-4 border-b">
                    <Label className="text-xs font-semibold flex items-center gap-1">
                      <Piano className="w-3 h-3" />
                      Note Editor
                    </Label>
                    <div className="space-y-2">
                      <div className="text-xs text-muted-foreground">
                        Currently Selected: {notes.find(n => n.id === selectedNote)?.pitch}
                        {notes.find(n => n.id === selectedNote)?.octave}
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="flex-1">
                          <Edit3 className="w-3 h-3 mr-1" />
                          Edit
                        </Button>
                        <Button size="sm" variant="outline">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Regenerate from Audio */}
                <div className="space-y-3">
                  <Label className="text-xs font-semibold">Regenerate from Audio</Label>
                  <Select value={transcriptionMethod} onValueChange={setTranscriptionMethod}>
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Automatic Beat Detection</SelectItem>
                      <SelectItem value="melody">Melody Only</SelectItem>
                      <SelectItem value="chords">Chord Changes</SelectItem>
                      <SelectItem value="full">Full Voicing</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={handleRegenerateFromAudio} variant="outline" size="sm" className="w-full">
                    <RefreshCw className="w-3 h-3 mr-2" />
                    Regenerate
                  </Button>
                </div>

                <Separator />

                {/* Adjust Difficulty */}
                <div className="space-y-3">
                  <Label className="text-xs font-semibold">Adjust Difficulty</Label>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Simple</span>
                      <span>Complex</span>
                    </div>
                    <Slider
                      value={[difficulty]}
                      onValueChange={([val]) => setDifficulty(val)}
                      max={100}
                      step={1}
                    />
                  </div>
                  <Button onClick={handleAdjustDifficulty} variant="outline" size="sm" className="w-full">
                    <RefreshCw className="w-3 h-3 mr-2" />
                    Regenerate
                  </Button>
                </div>

                <Separator />

                {/* AI Suggestions */}
                <div className="space-y-3">
                  <Label className="text-xs font-semibold flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    AI Suggestions
                  </Label>
                  <div className="space-y-2">
                    <div className="flex items-start gap-2 text-xs">
                      <CheckCircle className="w-3 h-3 mt-0.5 text-green-600 shrink-0" />
                      <span>Voice leading optimized</span>
                    </div>
                    <div className="flex items-start gap-2 text-xs">
                      <AlertCircle className="w-3 h-3 mt-0.5 text-yellow-600 shrink-0" />
                      <span>3 spelling corrections suggested</span>
                    </div>
                  </div>
                  <Button onClick={handleApplySuggestions} size="sm" className="w-full">
                    <Sparkles className="w-3 h-3 mr-2" />
                    Apply Suggestions
                  </Button>
                </div>

                <Separator />

                {/* Transposition */}
                <div className="space-y-3">
                  <Label className="text-xs font-semibold">Transposition</Label>
                  <Select defaultValue="c-major">
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="c-major">C Major</SelectItem>
                      <SelectItem value="g-major">G Major</SelectItem>
                      <SelectItem value="d-major">D Major</SelectItem>
                      <SelectItem value="a-major">A Major</SelectItem>
                      <SelectItem value="e-major">E Major</SelectItem>
                      <SelectItem value="f-major">F Major</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={handleTranspose} variant="outline" size="sm" className="w-full">
                    Transpose
                  </Button>
                </div>

                <Separator />

                {/* Comparison with Audio */}
                <div className="space-y-3">
                  <Label className="text-xs font-semibold">Compare with Audio</Label>
                  <div className="p-3 border rounded-lg bg-muted/30 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">Accuracy</span>
                      <Badge variant={accuracy >= 90 ? "default" : accuracy >= 70 ? "secondary" : "destructive"}>
                        {accuracy}%
                      </Badge>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex items-start gap-1">
                        <span className="text-muted-foreground">•</span>
                        <span>Measure 3: timing off by 50ms</span>
                      </div>
                      <div className="flex items-start gap-1">
                        <span className="text-muted-foreground">•</span>
                        <span>Measure 5: pitch off by semitone</span>
                      </div>
                    </div>
                  </div>
                  <Button onClick={handleFixIssues} size="sm" className="w-full">
                    Fix Issues
                  </Button>
                </div>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
