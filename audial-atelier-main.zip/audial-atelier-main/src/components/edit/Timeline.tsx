import { useState, useRef, useCallback, useEffect } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Redo,
  Save,
  Share2,
  Music,
  Mic,
  Drum,
  Guitar,
  Piano,
  Users,
  FileText,
  Eye,
  EyeOff,
  Scissors,
  Copy,
  Trash2,
  Wand2
} from "lucide-react";
import { TrackWaveform } from "./TrackWaveform";
import { SectionMarker } from "./SectionMarker";

interface Track {
  id: string;
  name: string;
  type: "vocals" | "drums" | "bass" | "melody" | "harmony" | "full";
  audioUrl: string;
  volume: number;
  pan: number;
  muted: boolean;
  soloed: boolean;
  color: string;
}

interface TimelineProps {
  tracks: Track[];
  zoomLevel: number;
  currentTime: number;
  duration: number;
  selectedTrackId: string | null;
  onTrackSelect: (trackId: string) => void;
  onRegenerateSection: (startTime: number, endTime: number, instructions: string) => void;
  editMode: "arrange" | "effects" | "lyrics" | "sheet-music";
}

interface Section {
  id: string;
  name: string;
  startTime: number;
  endTime: number;
  color: string;
}

const Timeline = ({
  tracks,
  zoomLevel,
  currentTime,
  duration,
  selectedTrackId,
  onTrackSelect,
  onRegenerateSection,
  editMode
}: TimelineProps) => {
  const timelineRef = useRef<HTMLDivElement>(null);
  const [sections, setSections] = useState<Section[]>([
    { id: "intro", name: "Intro", startTime: 0, endTime: 15, color: "#ff6b6b" },
    { id: "verse1", name: "Verse 1", startTime: 15, endTime: 45, color: "#4ecdc4" },
    { id: "chorus1", name: "Chorus 1", startTime: 45, endTime: 75, color: "#45b7d1" },
    { id: "verse2", name: "Verse 2", startTime: 75, endTime: 105, color: "#96ceb4" },
    { id: "chorus2", name: "Chorus 2", startTime: 105, endTime: 135, color: "#feca57" },
    { id: "outro", name: "Outro", startTime: 135, endTime: 180, color: "#ff9ff3" }
  ]);
  const [draggedSection, setDraggedSection] = useState<string | null>(null);
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const getTrackIcon = (type: Track["type"]) => {
    switch (type) {
      case "vocals": return <Mic className="w-4 h-4" />;
      case "drums": return <Drum className="w-4 h-4" />;
      case "bass": return <Guitar className="w-4 h-4" />;
      case "melody": return <Piano className="w-4 h-4" />;
      case "harmony": return <Users className="w-4 h-4" />;
      case "full": return <Music className="w-4 h-4" />;
      default: return <Music className="w-4 h-4" />;
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSectionClick = (sectionId: string) => {
    setSelectedSection(sectionId);
  };

  const handleSectionDragStart = (sectionId: string) => {
    setDraggedSection(sectionId);
    setIsDragging(true);
  };

  const handleSectionDragEnd = () => {
    setDraggedSection(null);
    setIsDragging(false);
  };

  const handleRegenerateSection = (sectionId: string) => {
    const section = sections.find(s => s.id === sectionId);
    if (section) {
      onRegenerateSection(section.startTime, section.endTime, `Regenerate ${section.name}`);
    }
  };

  const timelineWidth = duration * zoomLevel * 20; // 20px per second at zoom 1

  return (
    <div className="flex-1 flex flex-col bg-background">
      {/* Time Ruler */}
      <div className="h-12 border-b border-border bg-card flex items-center relative">
        <div className="w-48 flex-shrink-0 border-r border-border" /> {/* Track header space */}
        <ScrollArea className="flex-1">
          <div
            className="relative"
            style={{ width: timelineWidth }}
          >
            {/* Time markers */}
            {Array.from({ length: Math.ceil(duration / 10) + 1 }, (_, i) => {
              const time = i * 10;
              const x = time * zoomLevel * 20;
              return (
                <div
                  key={time}
                  className="absolute top-0 h-full border-l border-border/50"
                  style={{ left: x }}
                >
                  <div className="text-xs text-muted-foreground mt-1 ml-1">
                    {formatTime(time)}
                  </div>
                </div>
              );
            })}

            {/* Section markers */}
            {sections.map(section => {
              const startX = section.startTime * zoomLevel * 20;
              const width = (section.endTime - section.startTime) * zoomLevel * 20;

              return (
                <SectionMarker
                  key={section.id}
                  section={section}
                  startX={startX}
                  width={width}
                  isSelected={selectedSection === section.id}
                  isDragging={draggedSection === section.id}
                  onClick={() => handleSectionClick(section.id)}
                  onDragStart={() => handleSectionDragStart(section.id)}
                  onDragEnd={handleSectionDragEnd}
                  onRegenerate={() => handleRegenerateSection(section.id)}
                />
              );
            })}

            {/* Playhead */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10 pointer-events-none"
              style={{ left: currentTime * zoomLevel * 20 }}
            />
          </div>
        </ScrollArea>
      </div>

      {/* Tracks */}
      <ScrollArea className="flex-1">
        <div className="flex">
          {/* Track Headers */}
          <div className="w-48 flex-shrink-0 border-r border-border">
            {tracks.map(track => (
              <div
                key={track.id}
                className={`h-16 border-b border-border p-3 flex items-center gap-3 cursor-pointer hover:bg-accent/50 transition-colors ${
                  selectedTrackId === track.id ? 'bg-accent' : ''
                }`}
                onClick={() => onTrackSelect(track.id)}
              >
                <div
                  className="w-4 h-4 rounded-full flex-shrink-0"
                  style={{ backgroundColor: track.color }}
                />
                {getTrackIcon(track.type)}
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{track.name}</div>
                  <div className="text-xs text-muted-foreground capitalize">{track.type}</div>
                </div>
                <div className="flex gap-1">
                  {track.muted && <VolumeX className="w-3 h-3 text-muted-foreground" />}
                  {track.soloed && <Badge variant="secondary" className="text-xs px-1">S</Badge>}
                </div>
              </div>
            ))}
          </div>

          {/* Track Waveforms */}
          <div className="flex-1">
            <ScrollArea className="h-full">
              <div
                className="relative"
                style={{ width: timelineWidth }}
              >
                {tracks.map(track => (
                  <TrackWaveform
                    key={track.id}
                    track={track}
                    zoomLevel={zoomLevel}
                    duration={duration}
                    isSelected={selectedTrackId === track.id}
                    onClick={() => onTrackSelect(track.id)}
                  />
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

export { Timeline };