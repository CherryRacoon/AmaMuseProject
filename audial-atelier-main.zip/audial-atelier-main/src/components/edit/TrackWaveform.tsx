import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Wand2, Scissors, Copy, Trash2 } from "lucide-react";

interface Track {
  id: string;
  name: string;
  type: "vocals" | "drums" | "bass" | "melody" | "harmony" | "full";
  audioUrl: string;
  volume: number;
  pan: number;
  muted: boolean;
  soloed: boolean;
  color: string;
}

interface TrackWaveformProps {
  track: Track;
  zoomLevel: number;
  duration: number;
  isSelected: boolean;
  onClick: () => void;
}

const TrackWaveform = ({
  track,
  zoomLevel,
  duration,
  isSelected,
  onClick
}: TrackWaveformProps) => {
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [regenerateInstructions, setRegenerateInstructions] = useState("");

  const handleRegenerate = useCallback(() => {
    setIsRegenerating(true);
    // Mock regeneration - in real app, this would call AI API
    setTimeout(() => {
      setIsRegenerating(false);
      setRegenerateInstructions("");
    }, 3000);
  }, []);

  const waveformHeight = 64;
  const trackWidth = duration * zoomLevel * 20;

  // Generate mock waveform data
  const waveformData = Array.from({ length: Math.floor(trackWidth / 2) }, () =>
    Math.random() * waveformHeight * (track.volume * 0.8 + 0.2)
  );

  return (
    <div
      className={`h-16 border-b border-border relative cursor-pointer hover:bg-accent/20 transition-colors ${
        isSelected ? 'bg-accent/50' : ''
      }`}
      onClick={onClick}
    >
      {/* Waveform visualization */}
      <div className="absolute inset-0 flex items-center px-2">
        <svg
          width={trackWidth}
          height={waveformHeight}
          className="opacity-70"
          style={{ filter: track.muted ? 'grayscale(100%) opacity(0.5)' : 'none' }}
        >
          <path
            d={`M 0 ${waveformHeight/2} ${waveformData.map((height, i) =>
              `L ${i * 2} ${waveformHeight/2 - height/2} L ${i * 2} ${waveformHeight/2 + height/2}`
            ).join(' ')}`}
            fill="none"
            stroke={track.color}
            strokeWidth="1"
          />
        </svg>
      </div>

      {/* Track controls overlay */}
      {isSelected && (
        <div className="absolute right-2 top-2 flex gap-1 opacity-0 hover:opacity-100 transition-opacity">
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" variant="secondary" className="h-6 w-6 p-0">
                <Wand2 className="w-3 h-3" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Regenerate Track Section</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Textarea
                  placeholder="Describe how you want to regenerate this track section..."
                  value={regenerateInstructions}
                  onChange={(e) => setRegenerateInstructions(e.target.value)}
                />
                <Button
                  onClick={handleRegenerate}
                  disabled={isRegenerating || !regenerateInstructions.trim()}
                  className="w-full"
                >
                  {isRegenerating ? "Regenerating..." : "Regenerate"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Button size="sm" variant="secondary" className="h-6 w-6 p-0">
            <Scissors className="w-3 h-3" />
          </Button>
          <Button size="sm" variant="secondary" className="h-6 w-6 p-0">
            <Copy className="w-3 h-3" />
          </Button>
          <Button size="sm" variant="destructive" className="h-6 w-6 p-0">
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      )}

      {/* Volume indicator */}
      <div className="absolute left-2 top-2 text-xs text-muted-foreground">
        {Math.round(track.volume * 100)}%
      </div>
    </div>
  );
};

export { TrackWaveform };