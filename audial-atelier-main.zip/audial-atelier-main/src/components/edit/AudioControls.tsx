import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  RotateCcw
} from "lucide-react";

interface PlaybackState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
}

interface AudioControlsProps {
  playbackState: PlaybackState;
  onPlayPause: () => void;
  onStop: () => void;
  onVolumeChange: (volume: number) => void;
  onMuteToggle: () => void;
}

const AudioControls = ({
  playbackState,
  onPlayPause,
  onStop,
  onVolumeChange,
  onMuteToggle
}: AudioControlsProps) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = (playbackState.currentTime / playbackState.duration) * 100;

  return (
    <div className="flex items-center gap-4 flex-1">
      {/* Transport Controls */}
      <div className="flex items-center gap-1">
        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
          <SkipBack className="w-3 h-3" />
        </Button>
        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
          <RotateCcw className="w-3 h-3" />
        </Button>
        <Button
          size="sm"
          onClick={onPlayPause}
          className="h-8 w-8 p-0"
        >
          {playbackState.isPlaying ? (
            <Pause className="w-3 h-3" />
          ) : (
            <Play className="w-3 h-3" />
          )}
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={onStop}
          className="h-8 w-8 p-0"
        >
          <Square className="w-3 h-3" />
        </Button>
        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
          <SkipForward className="w-3 h-3" />
        </Button>
      </div>

      {/* Time Display */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground min-w-[120px]">
        <span>{formatTime(playbackState.currentTime)}</span>
        <span>/</span>
        <span>{formatTime(playbackState.duration)}</span>
      </div>

      {/* Progress Bar */}
      <div className="flex-1 max-w-md">
        <Slider
          value={[progressPercentage]}
          max={100}
          min={0}
          step={0.1}
          className="w-full"
          // In real app, this would seek to position
        />
      </div>

      {/* Volume Control */}
      <div className="flex items-center gap-2 min-w-[120px]">
        <Button
          size="sm"
          variant="ghost"
          onClick={onMuteToggle}
          className="h-6 w-6 p-0"
        >
          {playbackState.isMuted || playbackState.volume === 0 ? (
            <VolumeX className="w-3 h-3" />
          ) : (
            <Volume2 className="w-3 h-3" />
          )}
        </Button>
        <Slider
          value={[playbackState.isMuted ? 0 : playbackState.volume]}
          onValueChange={([value]) => onVolumeChange(value)}
          max={1}
          min={0}
          step={0.01}
          className="w-16"
        />
        <span className="text-xs text-muted-foreground w-8 text-right">
          {Math.round((playbackState.isMuted ? 0 : playbackState.volume) * 100)}%
        </span>
      </div>

      {/* Playback Status */}
      <Badge variant={playbackState.isPlaying ? "default" : "secondary"} className="text-xs">
        {playbackState.isPlaying ? "Playing" : "Stopped"}
      </Badge>
    </div>
  );
};

export { AudioControls };