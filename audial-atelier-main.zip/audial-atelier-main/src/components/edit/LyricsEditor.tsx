import { useState, useEffect } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  FileText,
  Clock,
  Edit3,
  Save,
  RotateCcw,
  Play,
  Pause,
  SkipForward,
  SkipBack
} from "lucide-react";

interface LyricsEditorProps {
  lyrics: string;
  onLyricsChange: (lyrics: string) => void;
}

interface LyricLine {
  id: string;
  text: string;
  startTime: number;
  endTime: number;
  section?: string;
}

const LyricsEditor = ({ lyrics, onLyricsChange }: LyricsEditorProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedLyrics, setEditedLyrics] = useState(lyrics);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedLine, setSelectedLine] = useState<string | null>(null);

  // Parse lyrics into structured format
  const parseLyrics = (lyricsText: string): LyricLine[] => {
    const lines = lyricsText.split('\n').filter(line => line.trim());
    return lines.map((line, index) => ({
      id: `line-${index}`,
      text: line.trim(),
      startTime: index * 5, // Mock timing - 5 seconds per line
      endTime: (index + 1) * 5,
      section: getSectionForTime(index * 5)
    }));
  };

  const getSectionForTime = (time: number): string => {
    if (time < 15) return "Intro";
    if (time < 45) return "Verse 1";
    if (time < 75) return "Chorus 1";
    if (time < 105) return "Verse 2";
    if (time < 135) return "Chorus 2";
    return "Outro";
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSave = () => {
    onLyricsChange(editedLyrics);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedLyrics(lyrics);
    setIsEditing(false);
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    // Mock playback - in real app, this would control audio
  };

  const handleSeekToLine = (lineId: string) => {
    const lines = parseLyrics(lyrics);
    const line = lines.find(l => l.id === lineId);
    if (line) {
      setCurrentTime(line.startTime);
      setSelectedLine(lineId);
    }
  };

  const lyricLines = parseLyrics(lyrics);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Lyrics Editor
          </h3>
          <div className="flex items-center gap-2">
            {!isEditing ? (
              <Button
                size="sm"
                variant="outline"
                onClick={() => setIsEditing(true)}
                className="gap-2"
              >
                <Edit3 className="w-3 h-3" />
                Edit
              </Button>
            ) : (
              <>
                <Button size="sm" variant="outline" onClick={handleCancel}>
                  <RotateCcw className="w-3 h-3" />
                </Button>
                <Button size="sm" onClick={handleSave} className="gap-2">
                  <Save className="w-3 h-3" />
                  Save
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Playback Controls */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={() => setCurrentTime(Math.max(0, currentTime - 5))}>
              <SkipBack className="w-3 h-3" />
            </Button>
            <Button size="sm" onClick={handlePlayPause} className="gap-2">
              {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              {isPlaying ? "Pause" : "Play"}
            </Button>
            <Button size="sm" variant="outline" onClick={() => setCurrentTime(currentTime + 5)}>
              <SkipForward className="w-3 h-3" />
            </Button>
          </div>
          <div className="text-sm text-muted-foreground">
            {formatTime(currentTime)}
          </div>
        </div>
      </div>

      {/* Lyrics Content */}
      <ScrollArea className="flex-1">
        {isEditing ? (
          <div className="p-4">
            <Textarea
              value={editedLyrics}
              onChange={(e) => setEditedLyrics(e.target.value)}
              placeholder="Enter lyrics here..."
              className="min-h-[300px] resize-none"
            />
          </div>
        ) : (
          <div className="p-4 space-y-2">
            {lyricLines.map((line, index) => {
              const isCurrentLine = currentTime >= line.startTime && currentTime < line.endTime;
              const isSelected = selectedLine === line.id;

              return (
                <div
                  key={line.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isCurrentLine
                      ? 'border-primary bg-primary/5'
                      : isSelected
                      ? 'border-accent bg-accent/50'
                      : 'border-border hover:border-accent'
                  }`}
                  onClick={() => handleSeekToLine(line.id)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {formatTime(line.startTime)}
                      </Badge>
                      {line.section && (
                        <Badge variant="secondary" className="text-xs">
                          {line.section}
                        </Badge>
                      )}
                    </div>
                    {isCurrentLine && (
                      <div className="flex items-center gap-1 text-primary">
                        <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                        <span className="text-xs">Playing</span>
                      </div>
                    )}
                  </div>
                  <div className="text-sm leading-relaxed">
                    {line.text}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ScrollArea>

      {/* Footer */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{lyricLines.length} lines</span>
          <span>Synced to timeline</span>
        </div>
      </div>
    </div>
  );
};

export { LyricsEditor };