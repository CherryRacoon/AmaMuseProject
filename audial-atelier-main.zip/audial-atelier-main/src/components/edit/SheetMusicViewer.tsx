import { useState, useRef } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Music,
  Edit3,
  Save,
  Download,
  Upload,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  FileText,
  AlertCircle
} from "lucide-react";

interface SheetMusicViewerProps {
  onNoteEdit: (originalNote: string, correctedNote: string) => void;
}

interface Note {
  id: string;
  pitch: string;
  octave: number;
  duration: number;
  startTime: number;
  isCorrect: boolean;
  suggestedCorrection?: string;
}

const SheetMusicViewer = ({ onNoteEdit }: SheetMusicViewerProps) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedNote, setSelectedNote] = useState<string | null>(null);
  const [correctionInput, setCorrectionInput] = useState("");

  // Mock sheet music data - in real app, this would be parsed from MIDI or MusicXML
  const [notes] = useState<Note[]>([
    { id: "n1", pitch: "C", octave: 4, duration: 1, startTime: 0, isCorrect: true },
    { id: "n2", pitch: "E", octave: 4, duration: 1, startTime: 1, isCorrect: true },
    { id: "n3", pitch: "G", octave: 4, duration: 1, startTime: 2, isCorrect: false, suggestedCorrection: "F#" },
    { id: "n4", pitch: "C", octave: 5, duration: 2, startTime: 3, isCorrect: true },
    { id: "n5", pitch: "A", octave: 4, duration: 1, startTime: 5, isCorrect: true },
    { id: "n6", pitch: "F", octave: 4, duration: 1, startTime: 6, isCorrect: false, suggestedCorrection: "F#" },
    { id: "n7", pitch: "D", octave: 4, duration: 1, startTime: 7, isCorrect: true },
    { id: "n8", pitch: "C", octave: 4, duration: 4, startTime: 8, isCorrect: true }
  ]);

  const staffHeight = 80;
  const noteSpacing = 40 * zoomLevel;
  const staffLineHeight = 8 * zoomLevel;

  const getNoteYPosition = (pitch: string, octave: number) => {
    const noteOrder = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
    const pitchIndex = noteOrder.indexOf(pitch);
    const octaveOffset = (octave - 4) * 7; // 7 notes per octave
    return staffHeight - (pitchIndex + octaveOffset) * (staffLineHeight / 2);
  };

  const getNoteSymbol = (duration: number) => {
    if (duration >= 4) return "𝅝"; // Whole note
    if (duration >= 2) return "𝅗𝅥"; // Half note
    if (duration >= 1) return "𝅘𝅥"; // Quarter note
    return "𝅘𝅥𝅮"; // Eighth note
  };

  const handleNoteClick = (noteId: string) => {
    const note = notes.find(n => n.id === noteId);
    if (note && !note.isCorrect) {
      setSelectedNote(noteId);
      setCorrectionInput(note.suggestedCorrection || "");
    }
  };

  const handleCorrectionSave = () => {
    if (selectedNote && correctionInput.trim()) {
      const note = notes.find(n => n.id === selectedNote);
      if (note) {
        onNoteEdit(`${note.pitch}${note.octave}`, correctionInput.trim());
        setSelectedNote(null);
        setCorrectionInput("");
      }
    }
  };

  const handleCorrectionCancel = () => {
    setSelectedNote(null);
    setCorrectionInput("");
  };

  const exportSheetMusic = () => {
    // Mock export - in real app, this would generate PDF or MusicXML
    console.log("Exporting sheet music...");
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm flex items-center gap-2">
            <Music className="w-4 h-4" />
            Sheet Music
          </h3>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setZoomLevel(Math.max(0.5, zoomLevel - 0.25))}
            >
              <ZoomOut className="w-3 h-3" />
            </Button>
            <span className="text-xs text-muted-foreground min-w-[40px] text-center">
              {Math.round(zoomLevel * 100)}%
            </span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setZoomLevel(Math.min(2, zoomLevel + 0.25))}
            >
              <ZoomIn className="w-3 h-3" />
            </Button>
            <Separator orientation="vertical" className="h-4" />
            <Button size="sm" variant="outline" onClick={exportSheetMusic} className="gap-2">
              <Download className="w-3 h-3" />
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Sheet Music Display */}
      <ScrollArea className="flex-1">
        <div className="p-6">
          {/* Staff */}
          <div className="relative mb-8">
            {/* Staff lines */}
            {Array.from({ length: 5 }, (_, i) => (
              <div
                key={i}
                className="absolute w-full border-t border-gray-400"
                style={{
                  top: i * staffLineHeight,
                  height: staffLineHeight
                }}
              />
            ))}

            {/* Clef */}
            <div className="absolute left-0 top-0 text-4xl">𝄞</div>

            {/* Time signature */}
            <div className="absolute left-8 top-0 flex flex-col items-center text-lg">
              <div>4</div>
              <div>4</div>
            </div>

            {/* Notes */}
            <div className="ml-16 relative">
              {notes.map((note, index) => {
                const x = index * noteSpacing;
                const y = getNoteYPosition(note.pitch, note.octave);
                const isSelected = selectedNote === note.id;

                return (
                  <div
                    key={note.id}
                    className={`absolute cursor-pointer transition-all ${
                      !note.isCorrect ? 'hover:scale-110' : ''
                    } ${isSelected ? 'scale-125' : ''}`}
                    style={{
                      left: x,
                      top: y - 12,
                      transform: isSelected ? 'scale(1.25)' : 'scale(1)'
                    }}
                    onClick={() => handleNoteClick(note.id)}
                  >
                    {/* Note symbol */}
                    <div
                      className={`text-2xl select-none ${
                        note.isCorrect ? 'text-black' : 'text-red-500'
                      }`}
                      style={{ fontSize: `${1.5 * zoomLevel}rem` }}
                    >
                      {getNoteSymbol(note.duration)}
                    </div>

                    {/* Error indicator */}
                    {!note.isCorrect && (
                      <div className="absolute -top-2 -right-2">
                        <AlertCircle className="w-4 h-4 text-red-500" />
                      </div>
                    )}

                    {/* Stem */}
                    <div
                      className="absolute w-0.5 bg-black"
                      style={{
                        height: '24px',
                        left: '6px',
                        top: note.pitch === 'C' || note.pitch === 'D' ? '12px' : '-24px'
                      }}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Note correction panel */}
          {selectedNote && (
            <div className="mt-6 p-4 border border-border rounded-lg bg-card">
              <h4 className="font-medium text-sm mb-3">Correct Note</h4>
              <div className="flex gap-2">
                <Input
                  value={correctionInput}
                  onChange={(e) => setCorrectionInput(e.target.value)}
                  placeholder="Enter corrected note (e.g., F#4)"
                  className="flex-1"
                />
                <Button size="sm" variant="outline" onClick={handleCorrectionCancel}>
                  Cancel
                </Button>
                <Button size="sm" onClick={handleCorrectionSave}>
                  Save
                </Button>
              </div>
            </div>
          )}

          {/* Statistics */}
          <div className="mt-6 grid grid-cols-3 gap-4">
            <div className="text-center p-3 border border-border rounded-lg">
              <div className="text-lg font-semibold">{notes.length}</div>
              <div className="text-xs text-muted-foreground">Total Notes</div>
            </div>
            <div className="text-center p-3 border border-border rounded-lg">
              <div className="text-lg font-semibold text-green-600">
                {notes.filter(n => n.isCorrect).length}
              </div>
              <div className="text-xs text-muted-foreground">Correct</div>
            </div>
            <div className="text-center p-3 border border-border rounded-lg">
              <div className="text-lg font-semibold text-red-600">
                {notes.filter(n => !n.isCorrect).length}
              </div>
              <div className="text-xs text-muted-foreground">Errors</div>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

export { SheetMusicViewer };