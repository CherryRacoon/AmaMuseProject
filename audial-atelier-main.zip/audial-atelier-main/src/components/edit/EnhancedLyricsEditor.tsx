import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import {
  FileText, Plus, Trash2, Copy, Sparkles, Globe, RotateCcw,
  Play, Pause, Languages, BookOpen, TrendingUp, TrendingDown
} from "lucide-react";

interface LyricsSection {
  id: string;
  name: string;
  type: "verse" | "chorus" | "bridge" | "intro" | "outro" | "pre-chorus";
  content: string;
  language: string;
  wordCount: number;
  syllableCount: number;
  lineCount: number;
}

interface EnhancedLyricsEditorProps {
  initialLyrics?: string;
  onLyricsChange?: (lyrics: string) => void;
}

export default function EnhancedLyricsEditor({ initialLyrics = "", onLyricsChange }: EnhancedLyricsEditorProps) {
  const [sections, setSections] = useState<LyricsSection[]>([
    {
      id: "verse1",
      name: "Verse 1",
      type: "verse",
      content: initialLyrics || "Walking through the empty streets tonight\nSearching for a sign of life\nEvery corner holds a memory\nOf you and me",
      language: "en",
      wordCount: 19,
      syllableCount: 24,
      lineCount: 4
    }
  ]);
  const [selectedSection, setSelectedSection] = useState("verse1");
  const [aiMode, setAiMode] = useState<"expand" | "condense" | "rework" | "align">("expand");
  const [rhymeScheme, setRhymeScheme] = useState("ABAB");
  const [syllableTarget, setSyllableTarget] = useState(8);
  const [newTone, setNewTone] = useState("");
  const [newTheme, setNewTheme] = useState("");

  const currentSection = sections.find(s => s.id === selectedSection);

  const handleContentChange = (content: string) => {
    const updated = sections.map(s =>
      s.id === selectedSection
        ? {
            ...s,
            content,
            wordCount: content.split(/\s+/).filter(w => w).length,
            lineCount: content.split('\n').filter(l => l.trim()).length,
            syllableCount: estimateSyllables(content)
          }
        : s
    );
    setSections(updated);
    onLyricsChange?.(updated.map(s => `[${s.name}]\n${s.content}`).join('\n\n'));
  };

  const estimateSyllables = (text: string): number => {
    // Simple syllable estimation
    const words = text.toLowerCase().split(/\s+/).filter(w => w);
    return words.reduce((total, word) => {
      const cleaned = word.replace(/[^a-z]/g, '');
      const syllables = cleaned.split(/[aeiou]+/).length - 1;
      return total + Math.max(1, syllables);
    }, 0);
  };

  const handleAddSection = () => {
    const newSection: LyricsSection = {
      id: `section-${Date.now()}`,
      name: `New Section`,
      type: "verse",
      content: "",
      language: "en",
      wordCount: 0,
      syllableCount: 0,
      lineCount: 0
    };
    setSections([...sections, newSection]);
    setSelectedSection(newSection.id);
  };

  const handleDeleteSection = (id: string) => {
    const updated = sections.filter(s => s.id !== id);
    setSections(updated);
    if (selectedSection === id && updated.length > 0) {
      setSelectedSection(updated[0].id);
    }
  };

  const handleDuplicateSection = (id: string) => {
    const section = sections.find(s => s.id === id);
    if (section) {
      const duplicate: LyricsSection = {
        ...section,
        id: `section-${Date.now()}`,
        name: `${section.name} (Copy)`
      };
      setSections([...sections, duplicate]);
    }
  };

  const handleEnhanceWithAI = () => {
    // Mock AI enhancement - in real app, this would call an AI API
    console.log("Enhancing with AI:", { aiMode, rhymeScheme, syllableTarget });
  };

  const handleApplyTone = () => {
    console.log("Applying new tone:", newTone);
  };

  const handleRetheme = () => {
    console.log("Applying new theme:", newTheme);
  };

  const handleRegenerate = () => {
    console.log("Regenerating section:", selectedSection);
  };

  const handleTranslate = () => {
    console.log("Translating section");
  };

  return (
    <div className="grid gap-4 md:grid-cols-[220px_1fr_320px] h-full">
      {/* Left Panel - Section Navigator */}
      <Card className="flex flex-col h-full overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center justify-between">
            Sections
            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={handleAddSection}>
              <Plus className="w-3 h-3" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden p-0">
          <ScrollArea className="h-full px-4 pb-4">
            <div className="space-y-1">
              {sections.map((section) => (
                <div
                  key={section.id}
                  className={`p-2 rounded-md cursor-pointer transition-colors ${
                    selectedSection === section.id
                      ? 'bg-primary/10 border border-primary'
                      : 'hover:bg-muted'
                  }`}
                  onClick={() => setSelectedSection(section.id)}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{section.name}</span>
                    <Badge variant="outline" className="text-xs">
                      {section.type}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
        
        {/* Section Statistics */}
        {currentSection && (
          <div className="border-t p-3 space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Words:</span>
              <span className="font-medium">{currentSection.wordCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Syllables:</span>
              <span className="font-medium">{currentSection.syllableCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Lines:</span>
              <span className="font-medium">{currentSection.lineCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Avg Syl/Line:</span>
              <span className="font-medium">
                {currentSection.lineCount > 0 
                  ? (currentSection.syllableCount / currentSection.lineCount).toFixed(1)
                  : 0}
              </span>
            </div>
          </div>
        )}
      </Card>

      {/* Center Panel - Editor */}
      <Card className="flex flex-col h-full overflow-hidden">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Lyrics Editor
            </CardTitle>
            {currentSection && (
              <div className="flex gap-1">
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-7 w-7"
                  onClick={() => handleDuplicateSection(currentSection.id)}
                  title="Duplicate"
                >
                  <Copy className="w-3 h-3" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-7 w-7"
                  onClick={() => handleDeleteSection(currentSection.id)}
                  title="Delete"
                >
                  <Trash2 className="w-3 h-3 text-destructive" />
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        
        {currentSection && (
          <>
            <div className="px-4 pb-3 space-y-2">
              <div className="flex gap-2">
                <Input
                  value={currentSection.name}
                  onChange={(e) => {
                    const updated = sections.map(s =>
                      s.id === selectedSection ? { ...s, name: e.target.value } : s
                    );
                    setSections(updated);
                  }}
                  className="h-8 text-sm"
                />
                <Select
                  value={currentSection.type}
                  onValueChange={(value: any) => {
                    const updated = sections.map(s =>
                      s.id === selectedSection ? { ...s, type: value } : s
                    );
                    setSections(updated);
                  }}
                >
                  <SelectTrigger className="w-32 h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="verse">Verse</SelectItem>
                    <SelectItem value="chorus">Chorus</SelectItem>
                    <SelectItem value="bridge">Bridge</SelectItem>
                    <SelectItem value="intro">Intro</SelectItem>
                    <SelectItem value="outro">Outro</SelectItem>
                    <SelectItem value="pre-chorus">Pre-Chorus</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <CardContent className="flex-1 overflow-hidden p-0">
              <ScrollArea className="h-full">
                <div className="p-4">
                  <Textarea
                    value={currentSection.content}
                    onChange={(e) => handleContentChange(e.target.value)}
                    placeholder="Enter lyrics here..."
                    className="min-h-[400px] resize-none font-mono"
                  />
                </div>
              </ScrollArea>
            </CardContent>
          </>
        )}
      </Card>

      {/* Right Panel - AI & Remix */}
      <Card className="flex flex-col h-full overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            AI Remix
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden p-0">
          <ScrollArea className="h-full">
            <div className="p-4 space-y-4">
              {/* AI Enhancement Section */}
              <div className="space-y-3">
                <Label className="text-xs font-semibold">AI Enhancement Mode</Label>
                <RadioGroup value={aiMode} onValueChange={(v: any) => setAiMode(v)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="expand" id="expand" />
                    <Label htmlFor="expand" className="text-sm cursor-pointer flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      Expand
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="condense" id="condense" />
                    <Label htmlFor="condense" className="text-sm cursor-pointer flex items-center gap-1">
                      <TrendingDown className="w-3 h-3" />
                      Condense
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="rework" id="rework" />
                    <Label htmlFor="rework" className="text-sm cursor-pointer flex items-center gap-1">
                      <RotateCcw className="w-3 h-3" />
                      Rework
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="align" id="align" />
                    <Label htmlFor="align" className="text-sm cursor-pointer flex items-center gap-1">
                      <BookOpen className="w-3 h-3" />
                      Align Only
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <Separator />

              {/* Rhyme Scheme */}
              <div className="space-y-2">
                <Label className="text-xs">Rhyme Scheme</Label>
                <Select value={rhymeScheme} onValueChange={setRhymeScheme}>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AABB">AABB (consecutive)</SelectItem>
                    <SelectItem value="ABAB">ABAB (alternating)</SelectItem>
                    <SelectItem value="ABCB">ABCB (varied)</SelectItem>
                    <SelectItem value="FREE">Free Verse</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Syllable Target */}
              <div className="space-y-2">
                <Label className="text-xs">Syllables per Line</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={syllableTarget}
                    onChange={(e) => setSyllableTarget(parseInt(e.target.value) || 8)}
                    className="h-8 text-sm"
                    min={4}
                    max={16}
                  />
                  <span className="text-xs text-muted-foreground">±2</span>
                </div>
              </div>

              <Button onClick={handleEnhanceWithAI} className="w-full" size="sm">
                <Sparkles className="w-3 h-3 mr-2" />
                Enhance with AI
              </Button>

              <Separator />

              {/* Remix Options */}
              <div className="space-y-3">
                <Label className="text-xs font-semibold">Remix Options</Label>
                
                <div className="space-y-2">
                  <Label className="text-xs">Change Emotional Tone</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Describe new tone..."
                      value={newTone}
                      onChange={(e) => setNewTone(e.target.value)}
                      className="h-8 text-sm flex-1"
                    />
                    <Button size="sm" variant="outline" onClick={handleApplyTone} className="h-8 px-2">
                      Apply
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">Change Theme</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="New theme..."
                      value={newTheme}
                      onChange={(e) => setNewTheme(e.target.value)}
                      className="h-8 text-sm flex-1"
                    />
                    <Button size="sm" variant="outline" onClick={handleRetheme} className="h-8 px-2">
                      Apply
                    </Button>
                  </div>
                </div>

                <Button onClick={handleRegenerate} variant="outline" className="w-full" size="sm">
                  <RotateCcw className="w-3 h-3 mr-2" />
                  Regenerate Section
                </Button>
              </div>

              <Separator />

              {/* Language & Localization */}
              <div className="space-y-3">
                <Label className="text-xs font-semibold flex items-center gap-1">
                  <Globe className="w-3 h-3" />
                  Language
                </Label>
                
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="cursor-pointer">EN</Badge>
                  <Badge variant="outline" className="cursor-pointer">中文</Badge>
                  <Badge variant="outline" className="cursor-pointer">日本語</Badge>
                  <Badge variant="outline" className="cursor-pointer">한국어</Badge>
                </div>

                <Button onClick={handleTranslate} variant="outline" className="w-full" size="sm">
                  <Languages className="w-3 h-3 mr-2" />
                  Translate Section
                </Button>
              </div>

              <Separator />

              {/* Preview Section */}
              <div className="space-y-2">
                <Label className="text-xs font-semibold">Preview</Label>
                <div className="p-3 border rounded-md bg-muted/30">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">Section Preview</span>
                    <Button size="icon" variant="ghost" className="h-6 w-6">
                      <Play className="w-3 h-3" />
                    </Button>
                  </div>
                  {currentSection && (
                    <p className="text-xs leading-relaxed whitespace-pre-wrap">
                      {currentSection.content.slice(0, 100)}
                      {currentSection.content.length > 100 && "..."}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
