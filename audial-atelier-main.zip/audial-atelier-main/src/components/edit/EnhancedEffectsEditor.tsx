import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Plus, GripVertical, Trash2, Power, Settings, Sliders,
  Music, Activity, Radio, Clock, Gauge, Volume, Sparkles
} from "lucide-react";

const FX_TYPES = [
  { type: "eq", label: "EQ", icon: Activity, color: "#667eea" },
  { type: "compressor", label: "Compressor", icon: Gauge, color: "#764ba2" },
  { type: "reverb", label: "Reverb", icon: Radio, color: "#00d9ff" },
  { type: "delay", label: "Delay", icon: Clock, color: "#00ff88" },
  { type: "limiter", label: "Limiter", icon: Volume, color: "#ff6b00" },
  { type: "noisegate", label: "Noise Gate", icon: Sliders, color: "#ff0055" },
  { type: "pitch", label: "Pitch/Time", icon: Music, color: "#ffaa00" }
];

interface Effect {
  id: string;
  type: string;
  bypass: boolean;
  wet: number;
  params: Record<string, number>;
  order: number;
}

interface EnhancedEffectsEditorProps {
  trackId?: string;
  onEffectsChange?: (effects: Effect[]) => void;
}

export default function EnhancedEffectsEditor({ trackId, onEffectsChange }: EnhancedEffectsEditorProps) {
  const [selectedTrack, setSelectedTrack] = useState(trackId || "full-mix");
  const [fxChain, setFxChain] = useState<Effect[]>([]);
  const [selectedEffect, setSelectedEffect] = useState<string | null>(null);

  const handleAddEffect = (type: string) => {
    const newEffect: Effect = {
      id: `${type}-${Date.now()}`,
      type,
      bypass: false,
      wet: 1,
      params: getDefaultParams(type),
      order: fxChain.length
    };
    const updated = [...fxChain, newEffect];
    setFxChain(updated);
    setSelectedEffect(newEffect.id);
    onEffectsChange?.(updated);
  };

  const handleRemoveEffect = (effectId: string) => {
    const updated = fxChain.filter(fx => fx.id !== effectId);
    setFxChain(updated);
    if (selectedEffect === effectId) setSelectedEffect(null);
    onEffectsChange?.(updated);
  };

  const handleBypass = (effectId: string) => {
    const updated = fxChain.map(fx =>
      fx.id === effectId ? { ...fx, bypass: !fx.bypass } : fx
    );
    setFxChain(updated);
    onEffectsChange?.(updated);
  };

  const handleWetChange = (effectId: string, wet: number) => {
    const updated = fxChain.map(fx =>
      fx.id === effectId ? { ...fx, wet } : fx
    );
    setFxChain(updated);
    onEffectsChange?.(updated);
  };

  const handleParamChange = (effectId: string, param: string, value: number) => {
    const updated = fxChain.map(fx =>
      fx.id === effectId ? { ...fx, params: { ...fx.params, [param]: value } } : fx
    );
    setFxChain(updated);
    onEffectsChange?.(updated);
  };

  const getDefaultParams = (type: string): Record<string, number> => {
    switch (type) {
      case "eq":
        return { low: 0, mid: 0, high: 0, frequency: 1000, q: 1 };
      case "compressor":
        return { threshold: -20, ratio: 4, attack: 10, release: 100, makeup: 0 };
      case "reverb":
        return { roomSize: 0.5, decay: 2, predelay: 20, damping: 0.5, spread: 0.5 };
      case "delay":
        return { time: 500, feedback: 30, cutoff: 5000 };
      case "limiter":
        return { threshold: -3, release: 50, lookahead: 5 };
      case "noisegate":
        return { threshold: -40, attack: 5, release: 50, hold: 20, range: -60 };
      case "pitch":
        return { pitch: 0, timeStretch: 1 };
      default:
        return {};
    }
  };

  const renderEffectParams = (effect: Effect) => {
    const fxType = FX_TYPES.find(f => f.type === effect.type);
    
    return (
      <div className="space-y-6 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {fxType?.icon && <fxType.icon className="w-5 h-5" style={{ color: fxType.color }} />}
            <h3 className="font-semibold">{fxType?.label || effect.type}</h3>
          </div>
          <Badge variant={effect.bypass ? "outline" : "default"}>
            {effect.bypass ? "Bypassed" : "Active"}
          </Badge>
        </div>

        {/* Wet/Dry Mix */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="text-sm">Wet/Dry Mix</Label>
            <span className="text-sm text-muted-foreground">{Math.round(effect.wet * 100)}%</span>
          </div>
          <Slider
            value={[effect.wet * 100]}
            onValueChange={([val]) => handleWetChange(effect.id, val / 100)}
            max={100}
            step={1}
            className="w-full"
          />
        </div>

        <Separator />

        {/* Effect-specific parameters */}
        {effect.type === "eq" && (
          <>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Low Gain</Label>
                <span className="text-sm text-muted-foreground">{effect.params.low?.toFixed(1)} dB</span>
              </div>
              <Slider
                value={[effect.params.low + 12]}
                onValueChange={([val]) => handleParamChange(effect.id, "low", val - 12)}
                max={24}
                step={0.1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Mid Gain</Label>
                <span className="text-sm text-muted-foreground">{effect.params.mid?.toFixed(1)} dB</span>
              </div>
              <Slider
                value={[effect.params.mid + 12]}
                onValueChange={([val]) => handleParamChange(effect.id, "mid", val - 12)}
                max={24}
                step={0.1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">High Gain</Label>
                <span className="text-sm text-muted-foreground">{effect.params.high?.toFixed(1)} dB</span>
              </div>
              <Slider
                value={[effect.params.high + 12]}
                onValueChange={([val]) => handleParamChange(effect.id, "high", val - 12)}
                max={24}
                step={0.1}
              />
            </div>
          </>
        )}

        {effect.type === "compressor" && (
          <>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Threshold</Label>
                <span className="text-sm text-muted-foreground">{effect.params.threshold?.toFixed(0)} dB</span>
              </div>
              <Slider
                value={[effect.params.threshold + 60]}
                onValueChange={([val]) => handleParamChange(effect.id, "threshold", val - 60)}
                max={60}
                step={1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Ratio</Label>
                <span className="text-sm text-muted-foreground">{effect.params.ratio?.toFixed(1)}:1</span>
              </div>
              <Slider
                value={[effect.params.ratio]}
                onValueChange={([val]) => handleParamChange(effect.id, "ratio", val)}
                min={1}
                max={20}
                step={0.1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Attack</Label>
                <span className="text-sm text-muted-foreground">{effect.params.attack?.toFixed(1)} ms</span>
              </div>
              <Slider
                value={[effect.params.attack]}
                onValueChange={([val]) => handleParamChange(effect.id, "attack", val)}
                min={0.1}
                max={100}
                step={0.1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Release</Label>
                <span className="text-sm text-muted-foreground">{effect.params.release?.toFixed(0)} ms</span>
              </div>
              <Slider
                value={[effect.params.release]}
                onValueChange={([val]) => handleParamChange(effect.id, "release", val)}
                min={10}
                max={1000}
                step={10}
              />
            </div>
          </>
        )}

        {effect.type === "reverb" && (
          <>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Room Size</Label>
                <span className="text-sm text-muted-foreground">{effect.params.roomSize?.toFixed(2)}</span>
              </div>
              <Slider
                value={[effect.params.roomSize * 100]}
                onValueChange={([val]) => handleParamChange(effect.id, "roomSize", val / 100)}
                max={100}
                step={1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Decay Time</Label>
                <span className="text-sm text-muted-foreground">{effect.params.decay?.toFixed(1)} s</span>
              </div>
              <Slider
                value={[effect.params.decay * 10]}
                onValueChange={([val]) => handleParamChange(effect.id, "decay", val / 10)}
                min={5}
                max={100}
                step={1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Pre-delay</Label>
                <span className="text-sm text-muted-foreground">{effect.params.predelay?.toFixed(0)} ms</span>
              </div>
              <Slider
                value={[effect.params.predelay]}
                onValueChange={([val]) => handleParamChange(effect.id, "predelay", val)}
                max={200}
                step={1}
              />
            </div>
          </>
        )}

        {effect.type === "delay" && (
          <>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Time</Label>
                <span className="text-sm text-muted-foreground">{effect.params.time?.toFixed(0)} ms</span>
              </div>
              <Slider
                value={[effect.params.time]}
                onValueChange={([val]) => handleParamChange(effect.id, "time", val)}
                min={1}
                max={5000}
                step={1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Feedback</Label>
                <span className="text-sm text-muted-foreground">{effect.params.feedback?.toFixed(0)}%</span>
              </div>
              <Slider
                value={[effect.params.feedback]}
                onValueChange={([val]) => handleParamChange(effect.id, "feedback", val)}
                max={95}
                step={1}
              />
            </div>
          </>
        )}

        {effect.type === "limiter" && (
          <>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Threshold</Label>
                <span className="text-sm text-muted-foreground">{effect.params.threshold?.toFixed(0)} dB</span>
              </div>
              <Slider
                value={[effect.params.threshold + 24]}
                onValueChange={([val]) => handleParamChange(effect.id, "threshold", val - 24)}
                max={24}
                step={1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Release</Label>
                <span className="text-sm text-muted-foreground">{effect.params.release?.toFixed(0)} ms</span>
              </div>
              <Slider
                value={[effect.params.release]}
                onValueChange={([val]) => handleParamChange(effect.id, "release", val)}
                min={10}
                max={1000}
                step={10}
              />
            </div>
          </>
        )}

        {effect.type === "noisegate" && (
          <>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Threshold</Label>
                <span className="text-sm text-muted-foreground">{effect.params.threshold?.toFixed(0)} dB</span>
              </div>
              <Slider
                value={[effect.params.threshold + 60]}
                onValueChange={([val]) => handleParamChange(effect.id, "threshold", val - 60)}
                max={60}
                step={1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Attack</Label>
                <span className="text-sm text-muted-foreground">{effect.params.attack?.toFixed(1)} ms</span>
              </div>
              <Slider
                value={[effect.params.attack * 10]}
                onValueChange={([val]) => handleParamChange(effect.id, "attack", val / 10)}
                max={1000}
                step={1}
              />
            </div>
          </>
        )}

        {effect.type === "pitch" && (
          <>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Pitch Shift</Label>
                <span className="text-sm text-muted-foreground">{effect.params.pitch > 0 ? '+' : ''}{effect.params.pitch?.toFixed(0)} semitones</span>
              </div>
              <Slider
                value={[effect.params.pitch + 24]}
                onValueChange={([val]) => handleParamChange(effect.id, "pitch", val - 24)}
                max={48}
                step={1}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Time Stretch</Label>
                <span className="text-sm text-muted-foreground">{effect.params.timeStretch?.toFixed(2)}x</span>
              </div>
              <Slider
                value={[effect.params.timeStretch * 100 - 50]}
                onValueChange={([val]) => handleParamChange(effect.id, "timeStretch", (val + 50) / 100)}
                max={150}
                step={1}
              />
            </div>
          </>
        )}
      </div>
    );
  };

  return (
    <div className="grid gap-4 md:grid-cols-[220px_1fr_340px] h-full">
      {/* Left Panel - Track Selection */}
      <Card className="flex flex-col h-full">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Track</CardTitle>
        </CardHeader>
        <CardContent className="flex-1">
          <Select value={selectedTrack} onValueChange={setSelectedTrack}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="vocals">Vocals</SelectItem>
              <SelectItem value="drums">Drums</SelectItem>
              <SelectItem value="bass">Bass</SelectItem>
              <SelectItem value="melody">Melody</SelectItem>
              <SelectItem value="harmony">Harmony</SelectItem>
              <SelectItem value="full-mix">Full Mix</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Center Panel - FX Chain */}
      <Card className="flex flex-col h-full overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            FX Chain
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden flex flex-col gap-4 p-4">
          <ScrollArea className="flex-1">
            <div className="space-y-2 pr-4">
              {fxChain.length === 0 && (
                <div className="text-sm text-muted-foreground text-center py-8">
                  No effects yet. Add one below.
                </div>
              )}
              {fxChain.map((fx) => {
                const fxType = FX_TYPES.find(f => f.type === fx.type);
                return (
                  <div
                    key={fx.id}
                    className={`flex items-center gap-2 border rounded-lg p-3 transition-colors cursor-pointer ${
                      selectedEffect === fx.id ? 'border-primary bg-primary/5' : 'bg-muted/30 hover:bg-muted/50'
                    }`}
                    onClick={() => setSelectedEffect(fx.id)}
                  >
                    <GripVertical className="w-4 h-4 opacity-50 shrink-0 cursor-move" />
                    {fxType?.icon && <fxType.icon className="w-4 h-4 shrink-0" style={{ color: fxType.color }} />}
                    <Badge variant={fx.bypass ? "outline" : "secondary"}>{fxType?.label || fx.type}</Badge>
                    <div className="flex-1" />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 shrink-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleBypass(fx.id);
                      }}
                    >
                      <Power className={`w-3 h-3 ${fx.bypass ? "text-muted-foreground" : "text-green-500"}`} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 shrink-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveEffect(fx.id);
                      }}
                    >
                      <Trash2 className="w-3 h-3 text-destructive" />
                    </Button>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
          
          {/* Add Effect Buttons */}
          <div className="border-t pt-4">
            <div className="flex flex-wrap gap-2">
              {FX_TYPES.map((fx) => (
                <Button
                  key={fx.type}
                  variant="outline"
                  size="sm"
                  onClick={() => handleAddEffect(fx.type)}
                  className="gap-2"
                >
                  <Plus className="w-3 h-3" />
                  {fx.label}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Right Panel - Parameters */}
      <Card className="flex flex-col h-full overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Parameters</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-hidden p-0">
          <ScrollArea className="h-full">
            {selectedEffect ? (
              <>
                {fxChain.filter(fx => fx.id === selectedEffect).map(fx => (
                  <div key={fx.id}>
                    {renderEffectParams(fx)}
                  </div>
                ))}
              </>
            ) : (
              <div className="text-sm text-muted-foreground text-center py-8 px-4">
                Select an effect to edit parameters
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
