import { useState, useEffect } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  Volume2,
  RotateCcw,
  Settings,
  Plus,
  X,
  Zap,
  Waves,
  Filter,
  Mic,
  Radio
} from "lucide-react";

interface Effect {
  id: string;
  name: string;
  type: "reverb" | "eq" | "compression" | "delay" | "distortion" | "chorus";
  enabled: boolean;
  params: Record<string, number>;
}

interface EffectsRackProps {
  selectedTrackId: string | null;
  onEffectChange: (effect: string, params: Record<string, number>) => void;
}

const EffectsRack = ({ selectedTrackId, onEffectChange }: EffectsRackProps) => {
  const [effects, setEffects] = useState<Effect[]>([
    {
      id: "reverb",
      name: "Reverb",
      type: "reverb",
      enabled: false,
      params: { decay: 0.5, mix: 0.3, preDelay: 0.02 }
    },
    {
      id: "eq",
      name: "EQ",
      type: "eq",
      enabled: true,
      params: { low: 0, mid: 0, high: 0, presence: 0 }
    },
    {
      id: "compression",
      name: "Compressor",
      type: "compression",
      enabled: false,
      params: { threshold: -20, ratio: 4, attack: 0.01, release: 0.1 }
    }
  ]);

  const getEffectIcon = (type: Effect["type"]) => {
    switch (type) {
      case "reverb": return <Waves className="w-4 h-4" />;
      case "eq": return <Filter className="w-4 h-4" />;
      case "compression": return <Volume2 className="w-4 h-4" />;
      case "delay": return <Radio className="w-4 h-4" />;
      case "distortion": return <Zap className="w-4 h-4" />;
      case "chorus": return <Mic className="w-4 h-4" />;
      default: return <Settings className="w-4 h-4" />;
    }
  };

  const handleEffectToggle = (effectId: string) => {
    setEffects(prev => prev.map(effect =>
      effect.id === effectId
        ? { ...effect, enabled: !effect.enabled }
        : effect
    ));
  };

  const handleParamChange = (effectId: string, param: string, value: number) => {
    setEffects(prev => prev.map(effect =>
      effect.id === effectId
        ? { ...effect, params: { ...effect.params, [param]: value } }
        : effect
    ));

    const effect = effects.find(e => e.id === effectId);
    if (effect) {
      onEffectChange(effectId, { ...effect.params, [param]: value });
    }
  };

  const addEffect = (type: Effect["type"]) => {
    const newEffect: Effect = {
      id: `${type}-${Date.now()}`,
      name: type.charAt(0).toUpperCase() + type.slice(1),
      type,
      enabled: false,
      params: getDefaultParams(type)
    };

    setEffects(prev => [...prev, newEffect]);
  };

  const removeEffect = (effectId: string) => {
    setEffects(prev => prev.filter(effect => effect.id !== effectId));
  };

  const getDefaultParams = (type: Effect["type"]): Record<string, number> => {
    switch (type) {
      case "reverb": return { decay: 0.5, mix: 0.3, preDelay: 0.02 };
      case "eq": return { low: 0, mid: 0, high: 0, presence: 0 };
      case "compression": return { threshold: -20, ratio: 4, attack: 0.01, release: 0.1 };
      case "delay": return { time: 0.3, feedback: 0.3, mix: 0.2 };
      case "distortion": return { drive: 0.5, tone: 0.5, mix: 0.3 };
      case "chorus": return { rate: 0.5, depth: 0.3, mix: 0.2 };
      default: return {};
    }
  };

  const renderEffectControls = (effect: Effect) => {
    switch (effect.type) {
      case "reverb":
        return (
          <div className="space-y-3">
            <div>
              <label className="text-xs text-muted-foreground">Decay</label>
              <Slider
                value={[effect.params.decay]}
                onValueChange={([value]) => handleParamChange(effect.id, "decay", value)}
                max={1}
                min={0}
                step={0.01}
                className="mt-1"
              />
              <div className="text-xs text-muted-foreground text-right">{Math.round(effect.params.decay * 100)}%</div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Mix</label>
              <Slider
                value={[effect.params.mix]}
                onValueChange={([value]) => handleParamChange(effect.id, "mix", value)}
                max={1}
                min={0}
                step={0.01}
                className="mt-1"
              />
              <div className="text-xs text-muted-foreground text-right">{Math.round(effect.params.mix * 100)}%</div>
            </div>
          </div>
        );

      case "eq":
        return (
          <div className="space-y-3">
            {["low", "mid", "high", "presence"].map(param => (
              <div key={param}>
                <label className="text-xs text-muted-foreground capitalize">{param}</label>
                <Slider
                  value={[effect.params[param]]}
                  onValueChange={([value]) => handleParamChange(effect.id, param, value)}
                  max={12}
                  min={-12}
                  step={0.1}
                  className="mt-1"
                />
                <div className="text-xs text-muted-foreground text-right">{effect.params[param] > 0 ? '+' : ''}{effect.params[param].toFixed(1)}dB</div>
              </div>
            ))}
          </div>
        );

      case "compression":
        return (
          <div className="space-y-3">
            <div>
              <label className="text-xs text-muted-foreground">Threshold</label>
              <Slider
                value={[effect.params.threshold]}
                onValueChange={([value]) => handleParamChange(effect.id, "threshold", value)}
                max={0}
                min={-40}
                step={0.1}
                className="mt-1"
              />
              <div className="text-xs text-muted-foreground text-right">{effect.params.threshold.toFixed(1)}dB</div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Ratio</label>
              <Slider
                value={[effect.params.ratio]}
                onValueChange={([value]) => handleParamChange(effect.id, "ratio", value)}
                max={20}
                min={1}
                step={0.1}
                className="mt-1"
              />
              <div className="text-xs text-muted-foreground text-right">{effect.params.ratio.toFixed(1)}:1</div>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-xs text-muted-foreground text-center py-4">
            Effect controls coming soon
          </div>
        );
    }
  };

  if (!selectedTrackId) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        <Settings className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p className="text-sm">Select a track to edit effects</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm">Effects Rack</h3>
          <Select onValueChange={(value) => addEffect(value as Effect["type"])}>
            <SelectTrigger className="w-8 h-8 p-0">
              <Plus className="w-4 h-4" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="reverb">Reverb</SelectItem>
              <SelectItem value="eq">EQ</SelectItem>
              <SelectItem value="compression">Compressor</SelectItem>
              <SelectItem value="delay">Delay</SelectItem>
              <SelectItem value="distortion">Distortion</SelectItem>
              <SelectItem value="chorus">Chorus</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Effects List */}
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-3">
          {effects.map(effect => (
            <div key={effect.id} className="border border-border rounded-lg p-3">
              {/* Effect Header */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {getEffectIcon(effect.type)}
                  <span className="font-medium text-sm">{effect.name}</span>
                  {effect.enabled && <Badge variant="secondary" className="text-xs">ON</Badge>}
                </div>
                <div className="flex items-center gap-1">
                  <Switch
                    checked={effect.enabled}
                    onCheckedChange={() => handleEffectToggle(effect.id)}
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                    onClick={() => removeEffect(effect.id)}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              </div>

              {/* Effect Controls */}
              {effect.enabled && renderEffectControls(effect)}
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Footer */}
      <div className="p-4 border-t border-border">
        <div className="text-xs text-muted-foreground text-center">
          {effects.filter(e => e.enabled).length} effects active
        </div>
      </div>
    </div>
  );
};

export { EffectsRack };