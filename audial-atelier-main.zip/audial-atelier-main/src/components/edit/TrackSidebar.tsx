import { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Drum,
  Guitar,
  Piano,
  Users,
  Music,
  Plus,
  Settings
} from "lucide-react";

interface Track {
  id: string;
  name: string;
  type: "vocals" | "drums" | "bass" | "melody" | "harmony" | "full";
  audioUrl: string;
  volume: number;
  pan: number;
  muted: boolean;
  soloed: boolean;
  color: string;
}

interface TrackSidebarProps {
  tracks: Track[];
  selectedTrackId: string | null;
  onTrackSelect: (trackId: string) => void;
  onTrackUpdate: (trackId: string, updates: Partial<Track>) => void;
}

const TrackSidebar = ({
  tracks,
  selectedTrackId,
  onTrackSelect,
  onTrackUpdate
}: TrackSidebarProps) => {
  const [editingTrackId, setEditingTrackId] = useState<string | null>(null);

  const getTrackIcon = (type: Track["type"]) => {
    switch (type) {
      case "vocals": return <Mic className="w-4 h-4" />;
      case "drums": return <Drum className="w-4 h-4" />;
      case "bass": return <Guitar className="w-4 h-4" />;
      case "melody": return <Piano className="w-4 h-4" />;
      case "harmony": return <Users className="w-4 h-4" />;
      case "full": return <Music className="w-4 h-4" />;
      default: return <Music className="w-4 h-4" />;
    }
  };

  const handleVolumeChange = (trackId: string, volume: number[]) => {
    onTrackUpdate(trackId, { volume: volume[0] });
  };

  const handlePanChange = (trackId: string, pan: number[]) => {
    onTrackUpdate(trackId, { pan: pan[0] });
  };

  const handleMuteToggle = (trackId: string) => {
    const track = tracks.find(t => t.id === trackId);
    if (track) {
      onTrackUpdate(trackId, { muted: !track.muted });
    }
  };

  const handleSoloToggle = (trackId: string) => {
    const track = tracks.find(t => t.id === trackId);
    if (track) {
      onTrackUpdate(trackId, { soloed: !track.soloed });
    }
  };

  return (
    <div className="w-64 border-r border-border bg-card flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm">Audio Stems</h3>
          <Button size="sm" variant="outline" className="h-6 w-6 p-0">
            <Plus className="w-3 h-3" />
          </Button>
        </div>
      </div>

      {/* Tracks List */}
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-2">
          {tracks.map(track => (
            <div
              key={track.id}
              className={`p-3 rounded-lg border transition-all cursor-pointer ${
                selectedTrackId === track.id
                  ? 'border-primary bg-accent'
                  : 'border-border hover:border-accent'
              }`}
              onClick={() => onTrackSelect(track.id)}
            >
              {/* Track Header */}
              <div className="flex items-center gap-2 mb-3">
                <div
                  className="w-3 h-3 rounded-full flex-shrink-0"
                  style={{ backgroundColor: track.color }}
                />
                {getTrackIcon(track.type)}
                <span className="font-medium text-sm flex-1 truncate">
                  {track.name}
                </span>
                <div className="flex gap-1">
                  {track.soloed && (
                    <Badge variant="secondary" className="text-xs px-1 h-4">S</Badge>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-4 w-4 p-0"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleMuteToggle(track.id);
                    }}
                  >
                    {track.muted ? (
                      <VolumeX className="w-3 h-3 text-muted-foreground" />
                    ) : (
                      <Volume2 className="w-3 h-3" />
                    )}
                  </Button>
                </div>
              </div>

              {/* Volume Control */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Volume</span>
                  <span>{Math.round(track.volume * 100)}%</span>
                </div>
                <Slider
                  value={[track.volume]}
                  onValueChange={(value) => handleVolumeChange(track.id, value)}
                  max={1}
                  min={0}
                  step={0.01}
                  className="w-full"
                />
              </div>

              {/* Pan Control */}
              <div className="space-y-2 mt-3">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Pan</span>
                  <span>{track.pan > 0 ? `R${Math.round(track.pan * 100)}` : track.pan < 0 ? `L${Math.round(Math.abs(track.pan) * 100)}` : 'C'}</span>
                </div>
                <Slider
                  value={[track.pan]}
                  onValueChange={(value) => handlePanChange(track.id, value)}
                  max={1}
                  min={-1}
                  step={0.01}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>L</span>
                  <span>C</span>
                  <span>R</span>
                </div>
              </div>

              {/* Solo Button */}
              <div className="mt-3">
                <Button
                  size="sm"
                  variant={track.soloed ? "default" : "outline"}
                  className="w-full h-6 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSoloToggle(track.id);
                  }}
                >
                  Solo
                </Button>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Footer */}
      <div className="p-4 border-t border-border">
        <div className="text-xs text-muted-foreground text-center">
          {tracks.length} tracks loaded
        </div>
      </div>
    </div>
  );
};

export { TrackSidebar };