import { useState } from "react";
import { Music, Sparkles } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useProjectStore } from "@/stores/useProjectStore";
import { AIChatSidebar } from "@/components/refine/AIChatSidebar";

export const AIChatAssistantButton = () => {
  const project = useProjectStore((state) => state.currentProject);
  const [open, setOpen] = useState(false);

  if (!project) {
    return null;
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          size="icon"
          className="fixed bottom-6 right-6 z-[60] h-14 w-14 rounded-full bg-gradient-to-br from-primary to-accent shadow-xl hover:scale-105 transition"
          aria-label="Open AI assistant"
        >
          <Music className="h-6 w-6 text-primary-foreground" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-full p-0 sm:max-w-lg">
        <SheetHeader className="px-6 pt-6 pb-2 text-left">
          <SheetTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="h-4 w-4 text-primary" />
            Creative Assistant
          </SheetTitle>
          <SheetDescription>
            Chat with the assistant for lyric tweaks, structure suggestions, and automated updates.
          </SheetDescription>
        </SheetHeader>
        <div className="h-full overflow-hidden px-4 pb-6">
          <AIChatSidebar project={project} />
        </div>
      </SheetContent>
    </Sheet>
  );
};
