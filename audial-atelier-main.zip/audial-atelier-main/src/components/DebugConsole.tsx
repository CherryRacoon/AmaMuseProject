import { useState } from "react";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, Trash2, Search } from "lucide-react";
import { useDebugLog, type LogEntry } from "@/hooks/useDebugLog";

interface DebugConsoleProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const DebugConsole = ({ open, onOpenChange }: DebugConsoleProps) => {
  const { logs, clearLogs } = useDebugLog();
  const [filter, setFilter] = useState("");
  const [levelFilter, setLevelFilter] = useState<string>("ALL");

  const filteredLogs = logs.filter((log) => {
    const matchesLevel = levelFilter === "ALL" || log.level === levelFilter;
    const matchesSearch = 
      log.message.toLowerCase().includes(filter.toLowerCase()) ||
      log.action.toLowerCase().includes(filter.toLowerCase()) ||
      log.source.toLowerCase().includes(filter.toLowerCase());
    return matchesLevel && matchesSearch;
  });

  const exportLogs = () => {
    const dataStr = JSON.stringify(logs, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `debug-logs-${new Date().toISOString()}.json`;
    link.click();
  };

  const getLevelColor = (level: LogEntry["level"]) => {
    switch (level) {
      case "DEBUG": return "text-muted-foreground";
      case "INFO": return "text-info";
      case "WARN": return "text-warning";
      case "ERROR": return "text-destructive";
    }
  };

  const getSourceColor = (source: LogEntry["source"]) => {
    switch (source) {
      case "Gemini": return "bg-accent/20 text-accent";
      case "Lyria": return "bg-primary/20 text-primary";
      case "Suno": return "bg-info/20 text-info";
      case "System": return "bg-secondary text-secondary-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[70vh] p-0">
        <SheetHeader className="p-6 pb-4 border-b border-border">
          <div className="flex items-center justify-between">
            <div>
              <SheetTitle>Debug Console</SheetTitle>
              <SheetDescription>
                Real-time application and API event logging
              </SheetDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={exportLogs} className="gap-2">
                <Download className="w-4 h-4" />
                Export
              </Button>
              <Button variant="outline" size="sm" onClick={clearLogs} className="gap-2">
                <Trash2 className="w-4 h-4" />
                Clear
              </Button>
            </div>
          </div>
        </SheetHeader>

        <div className="p-6 space-y-4">
          {/* Filters */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="pl-9"
              />
            </div>
            <Tabs value={levelFilter} onValueChange={setLevelFilter} className="w-auto">
              <TabsList>
                <TabsTrigger value="ALL">All</TabsTrigger>
                <TabsTrigger value="DEBUG">Debug</TabsTrigger>
                <TabsTrigger value="INFO">Info</TabsTrigger>
                <TabsTrigger value="WARN">Warn</TabsTrigger>
                <TabsTrigger value="ERROR">Error</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Log Entries */}
          <ScrollArea className="h-[calc(70vh-220px)]">
            <div className="space-y-2 pr-4">
              {filteredLogs.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No logs to display
                </div>
              ) : (
                filteredLogs.map((log) => (
                  <div
                    key={`${log.timestamp}-${log.source}-${log.action}`}
                    className="p-3 rounded-lg bg-card border border-border hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex items-start gap-3">
                      <span className="text-xs text-muted-foreground font-mono whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleTimeString()}.
                        {new Date(log.timestamp).getMilliseconds().toString().padStart(3, "0")}
                      </span>
                      <Badge variant="outline" className={`text-xs ${getLevelColor(log.level)}`}>
                        {log.level}
                      </Badge>
                      <Badge className={`text-xs ${getSourceColor(log.source)}`}>
                        {log.source}
                      </Badge>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm text-foreground">{log.action}</div>
                        <div className="text-sm text-muted-foreground mt-1">{log.message}</div>
                        {log.details && Object.keys(log.details).length > 0 && (
                          <details className="mt-2">
                            <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground">
                              View details
                            </summary>
                            <pre className="mt-2 text-xs bg-secondary p-2 rounded overflow-x-auto">
                              {JSON.stringify(log.details, null, 2)}
                            </pre>
                          </details>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
};
