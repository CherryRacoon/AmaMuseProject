import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Eye, EyeOff, Zap, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useDebugLog } from "@/hooks/useDebugLog";
import { useApiStore } from "@/stores/useApiStore";
import { Alert, AlertDescription } from "@/components/ui/alert";

export const GeminiConfig = () => {
  const [showKey, setShowKey] = useState(false);
  const [testing, setTesting] = useState(false);
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [responseTime, setResponseTime] = useState<number | null>(null);
  
  const { toast } = useToast();
  const { addLog } = useDebugLog();
  const apiKey = useApiStore((s) => s.geminiApiKey) ?? "";
  const setApiKey = useApiStore((s) => s.setGeminiApiKey);
  const model = useApiStore((s) => s.geminiModel);
  const setModel = useApiStore((s) => s.setGeminiModel);
  const temperature = useApiStore((s) => s.geminiTemperature);
  const setTemperature = useApiStore((s) => s.setGeminiTemperature);
  const topP = useApiStore((s) => s.geminiTopP);
  const setTopP = useApiStore((s) => s.setGeminiTopP);
  const maxTokens = useApiStore((s) => s.geminiMaxOutputTokens);
  const setMaxTokens = useApiStore((s) => s.setGeminiMaxOutputTokens);

  const temperatureSliderValue = useMemo<[number]>(() => [temperature], [temperature]);
  const topPSliderValue = useMemo<[number]>(() => [topP], [topP]);

  const testConnection = async () => {
    if (!apiKey) {
      toast({
        title: "API Key Required",
        description: "Please enter your Gemini API key",
        variant: "destructive",
      });
      return;
    }

    setTesting(true);
    setStatus("idle");
    const startTime = Date.now();

    addLog("INFO", "Gemini", "Connection Test", "Testing Gemini API connection...", {
      endpoint: `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      model,
      temperature,
      maxTokens,
      topP,
    });

    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{
              role: "user",
              parts: [{ text: "Say hello in one word" }]
            }],
            generationConfig: {
              temperature,
              maxOutputTokens: maxTokens,
              topP,
            }
          })
        }
      );

      const endTime = Date.now();
      const duration = endTime - startTime;
      setResponseTime(duration);

      if (response.ok) {
        const data = await response.json();
        setStatus("success");
        
        addLog("INFO", "Gemini", "Connection Test", "Connection successful", {
          responseTime: duration,
          statusCode: response.status,
          tokenCount: data.usageMetadata?.totalTokenCount,
        });

        toast({
          title: "Connection Successful",
          description: `Response received in ${duration}ms`,
        });
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      setStatus("error");
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      
      addLog("ERROR", "Gemini", "Connection Test", "Connection failed", {
        error: errorMessage,
        responseTime: Date.now() - startTime,
      });

      toast({
        title: "Connection Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card className="p-6 space-y-6 border-border bg-card shadow-card">
      <div className="space-y-4">
        <div>
          <h3 className="text-xl font-semibold text-foreground mb-2">Gemini API Configuration</h3>
          <p className="text-sm text-muted-foreground">
            Configure your Google Gemini API for prompt enhancement and content generation
          </p>
        </div>

        <Alert className="border-border bg-secondary/40">
          <AlertDescription className="text-xs text-muted-foreground">
            These credentials stay on your machine only. We store them locally in your browser and never upload them to the cloud.
          </AlertDescription>
        </Alert>

        {/* API Key */}
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <Label htmlFor="gemini-key">API Key</Label>
            <Button
              type="button"
              variant="link"
              className="h-auto p-0 text-xs font-medium text-primary"
              onClick={() => {
                if (typeof window !== "undefined") {
                  window.open("https://aistudio.google.com/app/apikey", "_blank", "noopener");
                }
              }}
            >
              Get a Gemini API key
            </Button>
          </div>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Input
                id="gemini-key"
                type={showKey ? "text" : "password"}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value ? e.target.value : null)}
                placeholder="AIzaSy..."
                className="pr-10"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1 h-8 w-8"
                onClick={() => setShowKey(!showKey)}
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Model Selection */}
        <div className="space-y-2">
          <Label htmlFor="gemini-model">Model</Label>
          <Select value={model} onValueChange={setModel}>
            <SelectTrigger id="gemini-model">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="gemini-2.5-flash">gemini-2.5-flash</SelectItem>
              <SelectItem value="gemini-pro">gemini-pro</SelectItem>
              <SelectItem value="gemini-ultra">gemini-ultra</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Temperature */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>Temperature</Label>
            <span className="text-sm text-muted-foreground">{temperature.toFixed(2)}</span>
          </div>
          <Slider
            value={temperatureSliderValue}
            onValueChange={(value) => setTemperature(value[0])}
            min={0}
            max={2}
            step={0.1}
            className="w-full"
          />
        </div>

        {/* Max Tokens */}
        <div className="space-y-2">
          <Label htmlFor="gemini-tokens">Max Output Tokens</Label>
          <Input
            id="gemini-tokens"
            type="number"
            value={maxTokens.toString()}
            onChange={(e) => {
              const next = e.target.value === "" ? 0 : parseInt(e.target.value, 10);
              setMaxTokens(Number.isFinite(next) ? next : 0);
            }}
            placeholder="2048"
          />
        </div>

        {/* Top P */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>Top P</Label>
            <span className="text-sm text-muted-foreground">{topP.toFixed(2)}</span>
          </div>
          <Slider
            value={topPSliderValue}
            onValueChange={(value) => setTopP(value[0])}
            min={0}
            max={1}
            step={0.05}
            className="w-full"
          />
        </div>
      </div>

      {/* Diagnostics */}
      <div className="pt-6 border-t border-border space-y-4">
        <h4 className="font-semibold text-foreground">Connection Diagnostics</h4>
        
        <div className="flex items-center gap-4">
          <Button onClick={testConnection} disabled={testing} className="gap-2">
            {testing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                Test Connection
              </>
            )}
          </Button>

          {status !== "idle" && (
            <Badge
              variant={status === "success" ? "default" : "destructive"}
              className="gap-1"
            >
              {status === "success" ? (
                <CheckCircle className="w-3 h-3" />
              ) : (
                <XCircle className="w-3 h-3" />
              )}
              {status === "success" ? "Connected" : "Failed"}
            </Badge>
          )}

          {responseTime && (
            <span className="text-sm text-muted-foreground">
              Response: {responseTime}ms
            </span>
          )}
        </div>
      </div>
    </Card>
  );
};
