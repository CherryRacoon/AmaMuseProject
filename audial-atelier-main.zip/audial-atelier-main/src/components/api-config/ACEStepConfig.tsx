import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Slider } from "../ui/slider";
import { Switch } from "../ui/switch";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { aceStepService } from "../../services/aceStepService";
import { useState } from "react";

export const ACEStepConfig = () => {
  const defaultConfig = aceStepService.getDefaultConfig();
  const [config, setConfig] = useState(defaultConfig);

  const handleConfigChange = (key: string, value: any) => {
    setConfig((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>ACE-Step Configuration</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Inference Steps</Label>
          <Slider
            value={[config.inferStep || 20]}
            onValueChange={([value]) => handleConfigChange('inferStep', value)}
            min={1}
            max={50}
            step={1}
          />
        </div>

        <div className="space-y-2">
          <Label>Guidance Scale</Label>
          <Slider
            value={[config.guidanceScale || 7.5]}
            onValueChange={([value]) => handleConfigChange('guidanceScale', value)}
            min={1}
            max={20}
            step={0.5}
          />
        </div>

        <div className="space-y-2">
          <Label>Scheduler Type</Label>
          <Select
            value={config.schedulerType}
            onValueChange={(value) => handleConfigChange('schedulerType', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select scheduler" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="flowmatch_euler">Flowmatch Euler</SelectItem>
              <SelectItem value="flowmatch_heun">Flowmatch Heun</SelectItem>
              <SelectItem value="flowmatch_dpm">Flowmatch DPM</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>CFG Type</Label>
          <Select
            value={config.cfgType}
            onValueChange={(value) => handleConfigChange('cfgType', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select CFG type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="tag">Tag</SelectItem>
              <SelectItem value="lyric">Lyric</SelectItem>
              <SelectItem value="both">Both</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="ergTag"
            checked={config.useErgTag}
            onCheckedChange={(checked) => handleConfigChange('useErgTag', checked)}
          />
          <Label htmlFor="ergTag">Use ERG Tag</Label>
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="ergLyric"
            checked={config.useErgLyric}
            onCheckedChange={(checked) => handleConfigChange('useErgLyric', checked)}
          />
          <Label htmlFor="ergLyric">Use ERG Lyric</Label>
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="ergDiffusion"
            checked={config.useErgDiffusion}
            onCheckedChange={(checked) => handleConfigChange('useErgDiffusion', checked)}
          />
          <Label htmlFor="ergDiffusion">Use ERG Diffusion</Label>
        </div>
      </CardContent>
    </Card>
  );
};