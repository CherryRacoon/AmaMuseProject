import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Zap, CheckCircle, XCircle, Loader2, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useDebugLog } from "@/hooks/useDebugLog";

export const LyriaConfig = () => {
  const [projectId, setProjectId] = useState("");
  const [region, setRegion] = useState("us-central1");
  const [serviceAccount, setServiceAccount] = useState("");
  const [sampleCount, setSampleCount] = useState("1");
  const [testing, setTesting] = useState(false);
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  
  const { toast } = useToast();
  const { addLog } = useDebugLog();

  const testConnection = async () => {
    if (!projectId || !serviceAccount) {
      toast({
        title: "Configuration Required",
        description: "Please provide project ID and service account credentials",
        variant: "destructive",
      });
      return;
    }

    setTesting(true);
    setStatus("idle");

    const endpoint = `https://${region}-aiplatform.googleapis.com/v1/projects/${projectId}/locations/${region}/publishers/google/models/lyria-002:predict`;

    addLog("INFO", "Lyria", "Connection Test", "Testing Lyria Vertex AI connection...", {
      endpoint,
      region,
      projectId: projectId.substring(0, 10) + "...",
    });

    // Simulated test (actual implementation would require OAuth token)
    setTimeout(() => {
      setStatus("success");
      setTesting(false);
      
      addLog("INFO", "Lyria", "Connection Test", "Connection simulated successfully", {
        note: "Full OAuth flow would be implemented in production",
      });

      toast({
        title: "Configuration Valid",
        description: "Lyria API credentials appear valid (simulated)",
      });
    }, 2000);
  };

  return (
    <Card className="p-6 space-y-6 border-border bg-card shadow-card">
      <div className="space-y-4">
        <div>
          <h3 className="text-xl font-semibold text-foreground mb-2">Lyria Vertex AI Configuration</h3>
          <p className="text-sm text-muted-foreground">
            Configure Google Cloud Vertex AI for Lyria music generation
          </p>
        </div>

        {/* Project ID */}
        <div className="space-y-2">
          <Label htmlFor="lyria-project">Google Cloud Project ID</Label>
          <Input
            id="lyria-project"
            value={projectId}
            onChange={(e) => setProjectId(e.target.value)}
            placeholder="my-project-id"
          />
        </div>

        {/* Region */}
        <div className="space-y-2">
          <Label htmlFor="lyria-region">Region</Label>
          <Select value={region} onValueChange={setRegion}>
            <SelectTrigger id="lyria-region">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="us-central1">us-central1</SelectItem>
              <SelectItem value="europe-west4">europe-west4</SelectItem>
              <SelectItem value="asia-southeast1">asia-southeast1</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Service Account */}
        <div className="space-y-2">
          <Label htmlFor="lyria-service">Service Account JSON</Label>
          <Textarea
            id="lyria-service"
            value={serviceAccount}
            onChange={(e) => setServiceAccount(e.target.value)}
            placeholder="Paste service account JSON or upload file..."
            rows={4}
            className="font-mono text-xs"
          />
          <Button variant="outline" size="sm" className="gap-2">
            <Upload className="w-4 h-4" />
            Upload JSON File
          </Button>
        </div>

        {/* Sample Count */}
        <div className="space-y-2">
          <Label htmlFor="lyria-samples">Sample Count (1-4)</Label>
          <Input
            id="lyria-samples"
            type="number"
            min="1"
            max="4"
            value={sampleCount}
            onChange={(e) => setSampleCount(e.target.value)}
          />
        </div>

        {/* Endpoint Preview */}
        <div className="p-4 bg-secondary rounded-lg">
          <p className="text-xs text-muted-foreground mb-1">Generated Endpoint:</p>
          <p className="text-xs font-mono text-foreground break-all">
            https://{region}-aiplatform.googleapis.com/v1/projects/{projectId || "{PROJECT_ID}"}/locations/{region}/publishers/google/models/lyria-002:predict
          </p>
        </div>
      </div>

      {/* Diagnostics */}
      <div className="pt-6 border-t border-border space-y-4">
        <h4 className="font-semibold text-foreground">Connection Diagnostics</h4>
        
        <div className="flex items-center gap-4">
          <Button onClick={testConnection} disabled={testing} className="gap-2">
            {testing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                Test Connection
              </>
            )}
          </Button>

          {status !== "idle" && (
            <Badge
              variant={status === "success" ? "default" : "destructive"}
              className="gap-1"
            >
              {status === "success" ? (
                <CheckCircle className="w-3 h-3" />
              ) : (
                <XCircle className="w-3 h-3" />
              )}
              {status === "success" ? "Valid Config" : "Failed"}
            </Badge>
          )}
        </div>

        <div className="p-3 bg-info/10 border border-info/20 rounded-lg">
          <p className="text-xs text-info">
            <strong>Note:</strong> Full OAuth 2.0 authentication flow would be implemented in production environment
          </p>
        </div>
      </div>
    </Card>
  );
};
