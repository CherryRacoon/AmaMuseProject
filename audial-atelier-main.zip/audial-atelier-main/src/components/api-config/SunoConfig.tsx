import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Eye, EyeOff, Zap, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useDebugLog } from "@/hooks/useDebugLog";
import { useApiStore } from "@/stores/useApiStore";

export const SunoConfig = () => {
  const [showKey, setShowKey] = useState(false);
  const apiKey = useApiStore((s) => s.sunoApiKey) ?? "";
  const setApiKey = useApiStore((s) => s.setSunoApiKey);
  const baseUrl = useApiStore((s) => s.sunoBaseUrl);
  const setBaseUrl = useApiStore((s) => s.setSunoBaseUrl);
  const apiVersion = useApiStore((s) => s.sunoApiVersion);
  const setApiVersion = useApiStore((s) => s.setSunoApiVersion);
  const [mode, setMode] = useState("custom");
  const [testing, setTesting] = useState(false);
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [credits, setCredits] = useState<number | null>(null);
  
  const { toast } = useToast();
  const { addLog } = useDebugLog();

  const testConnection = async () => {
    if (!apiKey) {
      toast({
        title: "API Key Required",
        description: "Please enter your Suno API key",
        variant: "destructive",
      });
      return;
    }

    setTesting(true);
    setStatus("idle");

    addLog("INFO", "Suno", "Connection Test", "Testing Suno API connection...", {
      endpoint: `${baseUrl}/api/suno/${apiVersion}`,
      mode,
    });

    // Simulated test (actual implementation would make real API call)
    setTimeout(() => {
      const mockCredits = Math.floor(Math.random() * 1000) + 100;
      setCredits(mockCredits);
      setStatus("success");
      setTesting(false);
      
      addLog("INFO", "Suno", "Connection Test", "Connection successful", {
        credits: mockCredits,
        statusCode: 200,
      });

      toast({
        title: "Connection Successful",
        description: `Available credits: ${mockCredits}`,
      });
    }, 1500);
  };

  return (
    <Card className="p-6 space-y-6 border-border bg-card shadow-card">
      <div className="space-y-4">
        <div>
          <h3 className="text-xl font-semibold text-foreground mb-2">Suno API Configuration</h3>
          <p className="text-sm text-muted-foreground">
            Configure Suno API for music generation and editing capabilities
          </p>
        </div>

        {/* API Key */}
        <div className="space-y-2">
          <Label htmlFor="suno-key">API Key</Label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Input
                id="suno-key"
                type={showKey ? "text" : "password"}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk_..."
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1 h-8 w-8"
                onClick={() => setShowKey(!showKey)}
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Base URL */}
        <div className="space-y-2">
          <Label htmlFor="suno-url">Base URL</Label>
          <Input
            id="suno-url"
            value={baseUrl}
            onChange={(e) => setBaseUrl(e.target.value)}
            placeholder="https://api.sunoapi.org"
          />
        </div>

        {/* API Version */}
        <div className="space-y-2">
          <Label htmlFor="suno-version">API Version</Label>
          <Select value={apiVersion} onValueChange={setApiVersion}>
            <SelectTrigger id="suno-version">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="v1">v1</SelectItem>
              <SelectItem value="v2">v2</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Mode */}
        <div className="space-y-2">
          <Label htmlFor="suno-mode">Default Mode</Label>
          <Select value={mode} onValueChange={setMode}>
            <SelectTrigger id="suno-mode">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="inspiration">Inspiration</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
              <SelectItem value="extend">Extend</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Diagnostics */}
      <div className="pt-6 border-t border-border space-y-4">
        <h4 className="font-semibold text-foreground">Connection Diagnostics</h4>
        
        <div className="flex items-center gap-4 flex-wrap">
          <Button onClick={testConnection} disabled={testing} className="gap-2">
            {testing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                Test Connection
              </>
            )}
          </Button>

          {status !== "idle" && (
            <Badge
              variant={status === "success" ? "default" : "destructive"}
              className="gap-1"
            >
              {status === "success" ? (
                <CheckCircle className="w-3 h-3" />
              ) : (
                <XCircle className="w-3 h-3" />
              )}
              {status === "success" ? "Connected" : "Failed"}
            </Badge>
          )}

          {credits !== null && (
            <Badge variant="outline" className="gap-1">
              Credits: {credits}
            </Badge>
          )}
        </div>
      </div>
    </Card>
  );
};
