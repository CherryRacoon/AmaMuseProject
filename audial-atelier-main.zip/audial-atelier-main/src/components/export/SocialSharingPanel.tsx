import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Share2,
  Instagram,
  Youtube,
  Cloud,
  Music2,
  Hash,
  Calendar,
  Eye,
  Lock,
  Globe,
  Wand2
} from "lucide-react";

interface Project {
  id: string;
  name: string;
  tracks: any[];
  selectedVersionId?: string;
}

interface SocialSharingPanelProps {
  project: Project;
  onShare: (platform: string, data: any) => void;
  onPreview: (data: any) => void;
}

const SocialSharingPanel = ({ project, onShare, onPreview }: SocialSharingPanelProps) => {
  const [selectedPlatform, setSelectedPlatform] = useState<string>("");
  const [title, setTitle] = useState(project.name);
  const [description, setDescription] = useState("");
  const [hashtags, setHashtags] = useState("#AI #Music #AudialAtelier");
  const [visibility, setVisibility] = useState<"public" | "private" | "unlisted">("public");
  const [schedulePost, setSchedulePost] = useState(false);
  const [scheduleDate, setScheduleDate] = useState("");
  const [autoGenerate, setAutoGenerate] = useState(true);

  const platforms = [
    {
      id: "instagram",
      name: "Instagram",
      icon: Instagram,
      color: "text-pink-600",
      description: "Share short clips and stories",
      supports: ["video", "image", "story"]
    },
    {
      id: "youtube",
      name: "YouTube",
      icon: Youtube,
      color: "text-red-600",
      description: "Upload full tracks and music videos",
      supports: ["video", "audio"]
    },
    {
      id: "soundcloud",
      name: "SoundCloud",
      icon: Cloud,
      color: "text-orange-600",
      description: "Professional audio sharing platform",
      supports: ["audio", "playlist"]
    },
    {
      id: "spotify",
      name: "Spotify",
      icon: Music2,
      color: "text-green-600",
      description: "Submit for distribution (requires approval)",
      supports: ["audio", "album"]
    }
  ];

  const generateCaption = () => {
    if (!autoGenerate) return;

    const baseCaption = `🎵 "${title}" - Created with AI in Audial Atelier\n\n`;
    const moodTags = ["electronic", "ambient", "energetic", "melancholic"];
    const styleTags = ["AI-generated", "original", "experimental", "ambient"];

    const randomMood = moodTags[Math.floor(Math.random() * moodTags.length)];
    const randomStyle = styleTags[Math.floor(Math.random() * styleTags.length)];

    const generatedCaption = `${baseCaption}A ${randomMood} ${randomStyle} composition brought to life through artificial creativity.\n\n${hashtags} #AIMusic #GeneratedMusic #AudialAtelier`;

    setDescription(generatedCaption);
  };

  const generateHashtags = () => {
    if (!autoGenerate) return;

    const baseHashtags = ["#AIMusic", "#GeneratedMusic", "#AudialAtelier"];
    const styleHashtags = ["#Electronic", "#Ambient", "#Experimental", "#AIArt"];
    const moodHashtags = ["#Chill", "#Energetic", "#Melancholic", "#Uplifting"];

    const randomStyle = styleHashtags[Math.floor(Math.random() * styleHashtags.length)];
    const randomMood = moodHashtags[Math.floor(Math.random() * moodHashtags.length)];

    const generatedHashtags = [...baseHashtags, randomStyle, randomMood].join(" ");
    setHashtags(generatedHashtags);
  };

  const handleShare = () => {
    if (!selectedPlatform) return;

    const shareData = {
      platform: selectedPlatform,
      title,
      description,
      hashtags,
      visibility,
      schedulePost,
      scheduleDate: schedulePost ? scheduleDate : null,
      projectId: project.id,
      projectName: project.name
    };

    onShare(selectedPlatform, shareData);
  };

  const handlePreview = () => {
    const previewData = {
      type: "social",
      platform: selectedPlatform,
      title,
      description,
      hashtags,
      visibility,
      schedulePost,
      scheduleDate
    };

    onPreview(previewData);
  };

  const selectedPlatformData = platforms.find(p => p.id === selectedPlatform);

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Social Sharing
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Share your music across social platforms with auto-generated captions and scheduling
          </p>
        </div>

        {/* Platform Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Choose Platform</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {platforms.map(platform => {
                const Icon = platform.icon;
                return (
                  <div
                    key={platform.id}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      selectedPlatform === platform.id ? "border-primary bg-primary/5" : "border-border hover:border-accent"
                    }`}
                    onClick={() => setSelectedPlatform(platform.id)}
                  >
                    <Icon className={`w-8 h-8 mx-auto mb-2 ${platform.color}`} />
                    <div className="text-center">
                      <div className="font-medium">{platform.name}</div>
                      <div className="text-xs text-muted-foreground mt-1">{platform.description}</div>
                      <div className="flex flex-wrap gap-1 mt-2 justify-center">
                        {platform.supports.map(support => (
                          <Badge key={support} variant="outline" className="text-xs">
                            {support}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Content Configuration */}
        {selectedPlatform && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Content Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Auto Generate Toggle */}
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-2">
                  <Wand2 className="w-4 h-4 text-primary" />
                  <div>
                    <div className="text-sm font-medium">Auto-generate content</div>
                    <div className="text-xs text-muted-foreground">Create captions and hashtags automatically</div>
                  </div>
                </div>
                <Checkbox
                  checked={autoGenerate}
                  onCheckedChange={(checked) => setAutoGenerate(checked as boolean)}
                />
              </div>

              {/* Title */}
              <div>
                <label className="text-sm font-medium">Title</label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter post title..."
                  className="mt-1"
                />
              </div>

              {/* Description/Caption */}
              <div>
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Description/Caption</label>
                  {autoGenerate && (
                    <Button size="sm" variant="outline" onClick={generateCaption}>
                      Generate
                    </Button>
                  )}
                </div>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Enter description or caption..."
                  className="mt-1"
                  rows={4}
                />
              </div>

              {/* Hashtags */}
              <div>
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Hashtags</label>
                  {autoGenerate && (
                    <Button size="sm" variant="outline" onClick={generateHashtags}>
                      Generate
                    </Button>
                  )}
                </div>
                <Input
                  value={hashtags}
                  onChange={(e) => setHashtags(e.target.value)}
                  placeholder="#AIMusic #GeneratedMusic"
                  className="mt-1"
                />
              </div>

              {/* Visibility */}
              <div>
                <label className="text-sm font-medium">Visibility</label>
                <Select value={visibility} onValueChange={(value: "public" | "private" | "unlisted") => setVisibility(value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">
                      <div className="flex items-center gap-2">
                        <Globe className="w-4 h-4" />
                        Public
                      </div>
                    </SelectItem>
                    <SelectItem value="private">
                      <div className="flex items-center gap-2">
                        <Lock className="w-4 h-4" />
                        Private
                      </div>
                    </SelectItem>
                    <SelectItem value="unlisted">
                      <div className="flex items-center gap-2">
                        <Eye className="w-4 h-4" />
                        Unlisted
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Scheduling */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="schedule-post"
                    checked={schedulePost}
                    onCheckedChange={(checked) => setSchedulePost(checked as boolean)}
                  />
                  <label htmlFor="schedule-post" className="text-sm font-medium">
                    Schedule post
                  </label>
                </div>

                {schedulePost && (
                  <div>
                    <label className="text-sm font-medium">Schedule Date & Time</label>
                    <Input
                      type="datetime-local"
                      value={scheduleDate}
                      onChange={(e) => setScheduleDate(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Platform-specific Info */}
        {selectedPlatformData && (
          <Card className="bg-muted/50">
            <CardContent className="pt-4">
              <div className="flex items-start gap-3">
                <selectedPlatformData.icon className={`w-5 h-5 mt-0.5 ${selectedPlatformData.color}`} />
                <div className="text-sm">
                  <p className="font-medium">{selectedPlatformData.name} Tips</p>
                  <ul className="text-muted-foreground mt-1 space-y-1">
                    {selectedPlatform === "instagram" && (
                      <>
                        <li>• Best for short clips (15-60 seconds)</li>
                        <li>• Use Stories for behind-the-scenes content</li>
                        <li>• Add music to Reels for better reach</li>
                      </>
                    )}
                    {selectedPlatform === "youtube" && (
                      <>
                        <li>• Upload full tracks or music videos</li>
                        <li>• Add timestamps in description</li>
                        <li>• Use playlists to organize your music</li>
                      </>
                    )}
                    {selectedPlatform === "soundcloud" && (
                      <>
                        <li>• Professional audio platform for musicians</li>
                        <li>• Great for building a music catalog</li>
                        <li>• Supports unlimited uploads</li>
                      </>
                    )}
                    {selectedPlatform === "spotify" && (
                      <>
                        <li>• Submit through Spotify for Artists</li>
                        <li>• Requires artist verification</li>
                        <li>• Best for distribution to streaming</li>
                      </>
                    )}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Share Actions */}
        {selectedPlatform && (
          <div className="flex gap-3">
            <Button
              onClick={handlePreview}
              variant="outline"
              className="flex-1 gap-2"
            >
              <Eye className="w-4 h-4" />
              Preview Post
            </Button>
            <Button
              onClick={handleShare}
              className="flex-1 gap-2"
            >
              <Share2 className="w-4 h-4" />
              Share to {platforms.find(p => p.id === selectedPlatform)?.name}
            </Button>
          </div>
        )}
      </div>
    </ScrollArea>
  );
};

export { SocialSharingPanel };