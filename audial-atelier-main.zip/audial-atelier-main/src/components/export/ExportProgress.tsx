import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Loader2,
  CheckCircle,
  AlertCircle,
  X,
  FileAudio,
  FileText,
  Archive,
  Share2
} from "lucide-react";

interface ExportJob {
  id: string;
  type: "audio" | "sheet-music" | "archive" | "social";
  status: "pending" | "processing" | "completed" | "failed";
  progress: number;
  fileName: string;
  fileSize?: string;
  error?: string;
  startTime: Date;
  endTime?: Date;
}

interface ExportProgressProps {
  jobs: ExportJob[];
  onCancel: () => void;
}

const ExportProgress = ({ jobs, onCancel }: ExportProgressProps) => {
  const [isOpen, setIsOpen] = useState(true);

  const getJobIcon = (type: ExportJob["type"]) => {
    switch (type) {
      case "audio": return <FileAudio className="w-4 h-4" />;
      case "sheet-music": return <FileText className="w-4 h-4" />;
      case "archive": return <Archive className="w-4 h-4" />;
      case "social": return <Share2 className="w-4 h-4" />;
      default: return <FileAudio className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: ExportJob["status"]) => {
    switch (status) {
      case "completed": return "text-green-600";
      case "failed": return "text-red-600";
      case "processing": return "text-blue-600";
      default: return "text-gray-600";
    }
  };

  const getStatusIcon = (status: ExportJob["status"]) => {
    switch (status) {
      case "completed": return <CheckCircle className="w-4 h-4" />;
      case "failed": return <AlertCircle className="w-4 h-4" />;
      case "processing": return <Loader2 className="w-4 h-4 animate-spin" />;
      default: return <Loader2 className="w-4 h-4" />;
    }
  };

  const formatDuration = (start: Date, end?: Date) => {
    const endTime = end || new Date();
    const duration = Math.round((endTime.getTime() - start.getTime()) / 1000);
    return `${duration}s`;
  };

  const allCompleted = jobs.every(job => job.status === "completed" || job.status === "failed");
  const hasErrors = jobs.some(job => job.status === "failed");

  // Auto-close after all jobs complete
  useEffect(() => {
    if (allCompleted) {
      const timer = setTimeout(() => {
        setIsOpen(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [allCompleted]);

  const handleClose = () => {
    setIsOpen(false);
    onCancel();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {allCompleted ? (
              hasErrors ? (
                <AlertCircle className="w-5 h-5 text-red-600" />
              ) : (
                <CheckCircle className="w-5 h-5 text-green-600" />
              )
            ) : (
              <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
            )}
            {allCompleted ? "Export Complete" : "Exporting..."}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {jobs.map(job => (
            <div key={job.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getJobIcon(job.type)}
                  <span className="text-sm font-medium truncate max-w-[200px]">
                    {job.fileName}
                  </span>
                </div>
                <div className={`flex items-center gap-1 ${getStatusColor(job.status)}`}>
                  {getStatusIcon(job.status)}
                  <Badge variant="outline" className="text-xs">
                    {job.status}
                  </Badge>
                </div>
              </div>

              <Progress value={job.progress} className="h-2" />

              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>{job.progress}%</span>
                <span>{formatDuration(job.startTime, job.endTime)}</span>
              </div>

              {job.fileSize && (
                <div className="text-xs text-muted-foreground">
                  Size: {job.fileSize}
                </div>
              )}

              {job.error && (
                <div className="text-xs text-red-600 bg-red-50 p-2 rounded">
                  Error: {job.error}
                </div>
              )}
            </div>
          ))}

          {jobs.length > 1 && <Separator />}

          {/* Summary */}
          <div className="text-sm text-center text-muted-foreground">
            {allCompleted ? (
              hasErrors ? (
                <span className="text-red-600">
                  {jobs.filter(j => j.status === "failed").length} of {jobs.length} exports failed
                </span>
              ) : (
                <span className="text-green-600">
                  All {jobs.length} exports completed successfully
                </span>
              )
            ) : (
              <span>
                Processing {jobs.filter(j => j.status === "processing").length} of {jobs.length} exports...
              </span>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={!allCompleted}
          >
            {allCompleted ? "Close" : "Cancel All"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export { ExportProgress };