import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  FileAudio,
  FileText,
  Archive,
  Share2,
  Music,
  Eye,
  CheckCircle,
  AlertCircle,
  X
} from "lucide-react";

interface ExportPreviewProps {
  data: any;
  type: "audio" | "sheet-music" | "archive" | "social";
  onClose: () => void;
  onConfirm: () => void;
}

const ExportPreview = ({ data, type, onClose, onConfirm }: ExportPreviewProps) => {
  const [isConfirming, setIsConfirming] = useState(false);

  const handleConfirm = async () => {
    setIsConfirming(true);
    // Simulate brief processing
    setTimeout(() => {
      onConfirm();
      setIsConfirming(false);
    }, 500);
  };

  const renderAudioPreview = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <FileAudio className="w-8 h-8 text-orange-500" />
        <div>
          <h3 className="font-semibold">{data.fileName}</h3>
          <p className="text-sm text-muted-foreground">Audio Export Preview</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Format:</span>
            <Badge variant="secondary">{data.format?.toUpperCase()}</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Quality:</span>
            <Badge variant="secondary">{data.quality}</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Bitrate:</span>
            <Badge variant="secondary">{data.bitrate}kbps</Badge>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Stems:</span>
            <Badge variant={data.includeStems ? "default" : "outline"}>
              {data.includeStems ? `${data.selectedTracks?.length || 0} included` : "No"}
            </Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Files:</span>
            <Badge variant="secondary">
              {data.includeStems ? (data.selectedTracks?.length || 0) + 1 : 1}
            </Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Size:</span>
            <Badge variant="secondary">~{(data.includeStems ? 45 : 15)}MB</Badge>
          </div>
        </div>
      </div>

      {/* Mock waveform preview */}
      <div className="border rounded-lg p-4 bg-muted/50">
        <div className="text-sm font-medium mb-2">Waveform Preview</div>
        <div className="h-16 bg-gradient-to-r from-blue-100 to-blue-200 rounded flex items-center justify-center">
          <Music className="w-6 h-6 text-blue-600" />
          <span className="ml-2 text-sm text-blue-700">Audio waveform visualization</span>
        </div>
      </div>
    </div>
  );

  const renderSheetMusicPreview = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <FileText className="w-8 h-8 text-blue-500" />
        <div>
          <h3 className="font-semibold">{data.fileName}</h3>
          <p className="text-sm text-muted-foreground">Sheet Music Export Preview</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Format:</span>
            <Badge variant="secondary">{data.format?.toUpperCase()}</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Layout:</span>
            <Badge variant="secondary">{data.layout}</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Page Size:</span>
            <Badge variant="secondary">{data.pageSize?.toUpperCase()}</Badge>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Transposition:</span>
            <Badge variant="secondary">{data.transposition} semitones</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Lyrics:</span>
            <Badge variant={data.includeLyrics ? "default" : "outline"}>
              {data.includeLyrics ? "Included" : "No"}
            </Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Chords:</span>
            <Badge variant={data.includeChordSymbols ? "default" : "outline"}>
              {data.includeChordSymbols ? "Included" : "No"}
            </Badge>
          </div>
        </div>
      </div>

      {/* Mock sheet music preview */}
      <div className="border rounded-lg p-4 bg-muted/50">
        <div className="text-sm font-medium mb-2">Sheet Music Preview</div>
        <div className="h-32 bg-gradient-to-r from-gray-100 to-gray-200 rounded flex items-center justify-center">
          <FileText className="w-8 h-8 text-gray-600" />
          <span className="ml-2 text-sm text-gray-700">Musical notation preview</span>
        </div>
      </div>
    </div>
  );

  const renderArchivePreview = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Archive className="w-8 h-8 text-green-500" />
        <div>
          <h3 className="font-semibold">{data.fileName}</h3>
          <p className="text-sm text-muted-foreground">Project Archive Preview</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Compression:</span>
            <Badge variant="secondary">{data.compression?.toUpperCase()}</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Total Size:</span>
            <Badge variant="secondary">{data.totalSize?.toFixed(1)}MB</Badge>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Items:</span>
            <Badge variant="secondary">
              {[data.includeAudio, data.includeStems, data.includePrompts, data.includeLogs, data.includeEdits, data.includeMetadata].filter(Boolean).length}
            </Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Format:</span>
            <Badge variant="secondary">
              {data.compression === 'none' ? 'TAR' : data.compression?.toUpperCase()}
            </Badge>
          </div>
        </div>
      </div>

      {/* Archive contents */}
      <div className="border rounded-lg p-4">
        <div className="text-sm font-medium mb-3">Archive Contents</div>
        <div className="space-y-2">
          {data.includeAudio && (
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Audio files (~50MB)</span>
            </div>
          )}
          {data.includeStems && (
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Individual stems (~200MB)</span>
            </div>
          )}
          {data.includePrompts && (
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>AI prompts (~1MB)</span>
            </div>
          )}
          {data.includeLogs && (
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Debug logs (~5MB)</span>
            </div>
          )}
          {data.includeEdits && (
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Edit sessions (~2MB)</span>
            </div>
          )}
          {data.includeMetadata && (
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Project metadata (~0.5MB)</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderSocialPreview = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Share2 className="w-8 h-8 text-purple-500" />
        <div>
          <h3 className="font-semibold">{data.title}</h3>
          <p className="text-sm text-muted-foreground">Social Media Post Preview</p>
        </div>
      </div>

      <div className="border rounded-lg p-4 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
              <Music className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="text-sm font-medium">Your Account</div>
              <div className="text-xs text-muted-foreground">
                {data.schedulePost ? `Scheduled for ${new Date(data.scheduleDate).toLocaleString()}` : 'Posting now'}
              </div>
            </div>
          </div>

          <div className="text-sm whitespace-pre-wrap">{data.description}</div>

          <div className="text-sm text-blue-600">{data.hashtags}</div>

          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            {data.visibility === 'public' && <Eye className="w-3 h-3" />}
            {data.visibility === 'private' && <AlertCircle className="w-3 h-3" />}
            <span className="capitalize">{data.visibility}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Platform:</span>
            <Badge variant="secondary" className="capitalize">{data.platform}</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Visibility:</span>
            <Badge variant="secondary" className="capitalize">{data.visibility}</Badge>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Scheduled:</span>
            <Badge variant={data.schedulePost ? "default" : "outline"}>
              {data.schedulePost ? "Yes" : "No"}
            </Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm">Hashtags:</span>
            <Badge variant="secondary">{data.hashtags.split(' ').length}</Badge>
          </div>
        </div>
      </div>
    </div>
  );

  const renderPreview = () => {
    switch (type) {
      case "audio": return renderAudioPreview();
      case "sheet-music": return renderSheetMusicPreview();
      case "archive": return renderArchivePreview();
      case "social": return renderSocialPreview();
      default: return <div>Unknown preview type</div>;
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Export Preview
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh]">
          <div className="p-4">
            {renderPreview()}
          </div>
        </ScrollArea>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleConfirm} disabled={isConfirming}>
            {isConfirming ? "Confirming..." : "Confirm Export"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export { ExportPreview };