import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Music,
  Download,
  Settings,
  Eye,
  FileAudio,
  Archive,
  Zap,
  Star,
  Users
} from "lucide-react";

interface Project {
  id: string;
  name: string;
  tracks: any[];
  // ... other project properties
}

interface AudioExportPanelProps {
  project: Project;
  onExport: (data: any) => void;
  onPreview: (data: any) => void;
  isExporting: boolean;
}

type AudioFormat = "mp3" | "wav" | "flac";
type QualityPreset = "demo" | "full" | "social";
type ExportType = "full-mix" | "stems" | "stems-zip";

const AudioExportPanel = ({ project, onExport, onPreview, isExporting }: AudioExportPanelProps) => {
  const [format, setFormat] = useState<AudioFormat>("mp3");
  const [quality, setQuality] = useState<QualityPreset>("full");
  const [exportType, setExportType] = useState<ExportType>("full-mix");
  const [selectedStems, setSelectedStems] = useState<string[]>([]);
  const [includeMetadata, setIncludeMetadata] = useState(true);

  const formatOptions = [
    {
      value: "mp3" as const,
      label: "MP3",
      description: "Compressed, widely compatible",
      bitrate: "320kbps"
    },
    {
      value: "wav" as const,
      label: "WAV",
      description: "Uncompressed, highest quality",
      bitrate: "Lossless"
    },
    {
      value: "flac" as const,
      label: "FLAC",
      description: "Compressed lossless",
      bitrate: "Lossless"
    }
  ];

  const qualityPresets = [
    {
      value: "demo" as const,
      label: "Demo Quality",
      icon: <Zap className="w-4 h-4" />,
      description: "128kbps MP3, fast export",
      settings: { bitrate: "128kbps", sampleRate: "44.1kHz" }
    },
    {
      value: "full" as const,
      label: "Full Release",
      icon: <Star className="w-4 h-4" />,
      description: "High quality for distribution",
      settings: { bitrate: "320kbps", sampleRate: "48kHz" }
    },
    {
      value: "social" as const,
      label: "Social Media",
      icon: <Users className="w-4 h-4" />,
      description: "Optimized for platforms",
      settings: { bitrate: "256kbps", sampleRate: "44.1kHz" }
    }
  ];

  const handleStemToggle = (stemId: string) => {
    setSelectedStems(prev =>
      prev.includes(stemId)
        ? prev.filter(id => id !== stemId)
        : [...prev, stemId]
    );
  };

  const handleSelectAllStems = () => {
    setSelectedStems(project.tracks.map(track => track.id));
  };

  const handleDeselectAllStems = () => {
    setSelectedStems([]);
  };

  const handlePreview = () => {
    const exportData = {
      type: "audio",
      format,
      quality,
      exportType,
      selectedStems: exportType === "stems" ? selectedStems : [],
      includeMetadata,
      fileName: `${project.name}-audio-${format}`,
      settings: qualityPresets.find(p => p.value === quality)?.settings
    };
    onPreview(exportData);
  };

  const handleExport = () => {
    const exportData = {
      type: "audio",
      format,
      quality,
      exportType,
      selectedStems: exportType === "stems" ? selectedStems : [],
      includeMetadata,
      fileName: `${project.name}-audio-${format}`,
      settings: qualityPresets.find(p => p.value === quality)?.settings
    };
    onExport(exportData);
  };

  const selectedFormat = formatOptions.find(f => f.value === format);
  const selectedPreset = qualityPresets.find(p => p.value === quality);

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-6">
        {/* Format Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileAudio className="w-5 h-5" />
              Audio Format
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              {formatOptions.map(option => (
                <div
                  key={option.value}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    format === option.value
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-accent'
                  }`}
                  onClick={() => setFormat(option.value)}
                >
                  <div className="font-semibold">{option.label}</div>
                  <div className="text-sm text-muted-foreground">{option.description}</div>
                  <Badge variant="secondary" className="mt-2">{option.bitrate}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quality Presets */}
        <Card>
          <CardHeader>
            <CardTitle>Quality Preset</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-3">
              {qualityPresets.map(preset => (
                <div
                  key={preset.value}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    quality === preset.value
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-accent'
                  }`}
                  onClick={() => setQuality(preset.value)}
                >
                  <div className="flex items-center gap-3">
                    {preset.icon}
                    <div className="flex-1">
                      <div className="font-semibold">{preset.label}</div>
                      <div className="text-sm text-muted-foreground">{preset.description}</div>
                    </div>
                    <Badge variant="outline">
                      {preset.settings.bitrate}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Export Type */}
        <Card>
          <CardHeader>
            <CardTitle>Export Type</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Select value={exportType} onValueChange={(value) => setExportType(value as ExportType)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="full-mix">Full Mix Only</SelectItem>
                <SelectItem value="stems">Individual Stems</SelectItem>
                <SelectItem value="stems-zip">Stems + ZIP Archive</SelectItem>
              </SelectContent>
            </Select>

            {(exportType === "stems" || exportType === "stems-zip") && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">Select Stems</Label>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={handleSelectAllStems}>
                      All
                    </Button>
                    <Button size="sm" variant="outline" onClick={handleDeselectAllStems}>
                      None
                    </Button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {project.tracks.map(track => (
                    <div key={track.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={track.id}
                        checked={selectedStems.includes(track.id)}
                        onCheckedChange={() => handleStemToggle(track.id)}
                      />
                      <Label htmlFor={track.id} className="text-sm">
                        {track.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Options */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Options
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="metadata"
                checked={includeMetadata}
                onCheckedChange={(checked) => setIncludeMetadata(checked === true)}
              />
              <Label htmlFor="metadata">Include metadata (title, artist, etc.)</Label>
            </div>
          </CardContent>
        </Card>

        {/* Export Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Export Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Format:</span>
                <div className="font-medium">{selectedFormat?.label}</div>
              </div>
              <div>
                <span className="text-muted-foreground">Quality:</span>
                <div className="font-medium">{selectedPreset?.label}</div>
              </div>
              <div>
                <span className="text-muted-foreground">Type:</span>
                <div className="font-medium capitalize">{exportType.replace("-", " ")}</div>
              </div>
              <div>
                <span className="text-muted-foreground">Files:</span>
                <div className="font-medium">
                  {exportType === "full-mix" ? "1 file" :
                   exportType === "stems" ? `${selectedStems.length} files` :
                   `${selectedStems.length + 1} files (ZIP)`}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            onClick={handlePreview}
            variant="outline"
            className="flex-1 gap-2"
          >
            <Eye className="w-4 h-4" />
            Preview
          </Button>
          <Button
            onClick={handleExport}
            disabled={isExporting || (exportType !== "full-mix" && selectedStems.length === 0)}
            className="flex-1 gap-2"
          >
            <Download className="w-4 h-4" />
            {isExporting ? "Exporting..." : "Export Audio"}
          </Button>
        </div>
      </div>
    </ScrollArea>
  );
};

export { AudioExportPanel };