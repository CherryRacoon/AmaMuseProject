import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Archive,
  Download,
  Eye,
  FileAudio,
  FileText,
  Database,
  Settings,
  HardDrive
} from "lucide-react";

interface Project {
  id: string;
  name: string;
  tracks: any[];
  selectedVersionId?: string;
}

interface ProjectArchivePanelProps {
  project: Project;
  onExport: (data: any) => void;
  onPreview: (data: any) => void;
  isExporting: boolean;
}

const ProjectArchivePanel = ({ project, onExport, onPreview, isExporting }: ProjectArchivePanelProps) => {
  const [includeAudio, setIncludeAudio] = useState(true);
  const [includeStems, setIncludeStems] = useState(true);
  const [includePrompts, setIncludePrompts] = useState(true);
  const [includeLogs, setIncludeLogs] = useState(true);
  const [includeEdits, setIncludeEdits] = useState(true);
  const [includeMetadata, setIncludeMetadata] = useState(true);
  const [compression, setCompression] = useState<"none" | "zip" | "7z">("zip");

  const archiveOptions = [
    {
      id: "audio",
      label: "Audio Files",
      description: "Final mix and stems",
      icon: FileAudio,
      checked: includeAudio,
      onChange: setIncludeAudio,
      size: "~50MB"
    },
    {
      id: "stems",
      label: "Individual Stems",
      description: "Separated audio tracks",
      icon: FileAudio,
      checked: includeStems,
      onChange: setIncludeStems,
      size: "~200MB"
    },
    {
      id: "prompts",
      label: "AI Prompts",
      description: "Original prompts and refinements",
      icon: FileText,
      checked: includePrompts,
      onChange: setIncludePrompts,
      size: "~1MB"
    },
    {
      id: "logs",
      label: "Debug Logs",
      description: "Generation and edit history",
      icon: Database,
      checked: includeLogs,
      onChange: setIncludeLogs,
      size: "~5MB"
    },
    {
      id: "edits",
      label: "Edit Sessions",
      description: "Timeline and effect settings",
      icon: Settings,
      checked: includeEdits,
      onChange: setIncludeEdits,
      size: "~2MB"
    },
    {
      id: "metadata",
      label: "Project Metadata",
      description: "Tags, descriptions, and settings",
      icon: FileText,
      checked: includeMetadata,
      onChange: setIncludeMetadata,
      size: "~0.5MB"
    }
  ];

  const compressionOptions = [
    {
      value: "none" as const,
      label: "No Compression",
      description: "Fast export, larger file size"
    },
    {
      value: "zip" as const,
      label: "ZIP Archive",
      description: "Balanced speed and compression"
    },
    {
      value: "7z" as const,
      label: "7-Zip Archive",
      description: "Maximum compression, slower"
    }
  ];

  const calculateTotalSize = () => {
    let total = 0;
    if (includeAudio) total += 50;
    if (includeStems) total += 200;
    if (includePrompts) total += 1;
    if (includeLogs) total += 5;
    if (includeEdits) total += 2;
    if (includeMetadata) total += 0.5;

    // Apply compression factor
    const compressionFactors = { none: 1, zip: 0.8, "7z": 0.6 };
    total *= compressionFactors[compression];

    return total;
  };

  const handleExport = () => {
    const exportData = {
      type: "archive",
      includeAudio,
      includeStems,
      includePrompts,
      includeLogs,
      includeEdits,
      includeMetadata,
      compression,
      fileName: `${project.name.replace(/\s+/g, '_')}_project_archive.${compression === 'none' ? 'tar' : compression}`
    };

    onExport(exportData);
  };

  const handlePreview = () => {
    const previewData = {
      type: "archive",
      includeAudio,
      includeStems,
      includePrompts,
      includeLogs,
      includeEdits,
      includeMetadata,
      compression,
      totalSize: calculateTotalSize(),
      fileName: `${project.name.replace(/\s+/g, '_')}_project_archive.${compression === 'none' ? 'tar' : compression}`
    };

    onPreview(previewData);
  };

  const totalSize = calculateTotalSize();
  const selectedCount = archiveOptions.filter(option => option.checked).length;

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Archive className="w-5 h-5" />
            Project Archive
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Create a complete backup of your project for safekeeping or sharing
          </p>
        </div>

        {/* Archive Contents */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Archive Contents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {archiveOptions.map(option => {
                const Icon = option.icon;
                return (
                  <div key={option.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id={option.id}
                        checked={option.checked}
                        onCheckedChange={(checked) => option.onChange(checked as boolean)}
                      />
                      <Icon className="w-5 h-5 text-muted-foreground" />
                      <div>
                        <label htmlFor={option.id} className="text-sm font-medium cursor-pointer">
                          {option.label}
                        </label>
                        <p className="text-xs text-muted-foreground">{option.description}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {option.size}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Compression Options */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Compression</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {compressionOptions.map(option => (
                <div
                  key={option.value}
                  className={`p-3 border-2 rounded-lg cursor-pointer transition-all ${
                    compression === option.value ? "border-primary bg-primary/5" : "border-border hover:border-accent"
                  }`}
                  onClick={() => setCompression(option.value)}
                >
                  <div className="font-medium">{option.label}</div>
                  <div className="text-xs text-muted-foreground mt-1">{option.description}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Archive Summary */}
        <Card className="bg-muted/50">
          <CardContent className="pt-4">
            <div className="text-sm space-y-2">
              <div className="flex justify-between items-center">
                <span>Items selected:</span>
                <Badge variant="secondary">{selectedCount} / {archiveOptions.length}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Estimated size:</span>
                <Badge variant="secondary">{totalSize.toFixed(1)}MB</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Compression:</span>
                <Badge variant="secondary">{compression.toUpperCase()}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Format:</span>
                <Badge variant="secondary">
                  {compression === 'none' ? 'TAR' : compression.toUpperCase()}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Export Actions */}
        <div className="flex gap-3">
          <Button
            onClick={handlePreview}
            variant="outline"
            className="flex-1 gap-2"
          >
            <Eye className="w-4 h-4" />
            Preview Archive
          </Button>
          <Button
            onClick={handleExport}
            disabled={isExporting || selectedCount === 0}
            className="flex-1 gap-2"
          >
            <Download className="w-4 h-4" />
            {isExporting ? "Creating Archive..." : "Create Archive"}
          </Button>
        </div>

        {/* Usage Tips */}
        <Card className="border-blue-200 bg-blue-50/50">
          <CardContent className="pt-4">
            <div className="flex items-start gap-3">
              <HardDrive className="w-5 h-5 text-blue-600 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-blue-900">Archive Usage Tips</p>
                <ul className="text-blue-800 mt-1 space-y-1">
                  <li>• Use archives for project backups and sharing</li>
                  <li>• Include logs for debugging future issues</li>
                  <li>• ZIP compression provides good balance of size and speed</li>
                  <li>• Archives can be imported back into Audial Atelier</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </ScrollArea>
  );
};

export { ProjectArchivePanel };