import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Tag,
  Music,
  User,
  Disc,
  Hash,
  Image as ImageIcon,
  Save,
  RotateCcw
} from "lucide-react";

interface Project {
  id: string;
  name: string;
  refinement?: {
    enhancedPrompt?: string;
    instruments?: string[];
    vocalType?: string;
    emotions?: string[];
    structure?: string[];
  };
  analysis?: {
    key?: string;
    bpm?: number;
    mood?: string[];
  };
  // ... other project properties
}

interface Metadata {
  title: string;
  artist: string;
  album: string;
  genre: string;
  year: string;
  bpm: number;
  key: string;
  description: string;
  tags: string[];
  coverArt?: File;
}

interface MetadataEditorProps {
  project: Project;
}

const MetadataEditor = ({ project }: MetadataEditorProps) => {
  const [metadata, setMetadata] = useState<Metadata>({
    title: project.name,
    artist: "",
    album: "",
    genre: "",
    year: new Date().getFullYear().toString(),
    bpm: project.analysis?.bpm || 120,
    key: project.analysis?.key || "",
    description: project.refinement?.enhancedPrompt || "",
    tags: project.refinement?.emotions || []
  });

  const [newTag, setNewTag] = useState("");
  const [hasChanges, setHasChanges] = useState(false);

  const genres = [
    "Pop", "Rock", "Hip Hop", "Electronic", "Jazz", "Classical",
    "Country", "R&B", "Reggae", "Blues", "Folk", "World",
    "Alternative", "Indie", "Ambient", "Experimental"
  ];

  const keys = [
    "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
  ];

  useEffect(() => {
    // Auto-populate from project data
    setMetadata(prev => ({
      ...prev,
      title: project.name,
      bpm: project.analysis?.bpm || prev.bpm,
      key: project.analysis?.key || prev.key,
      description: project.refinement?.enhancedPrompt || prev.description,
      tags: project.refinement?.emotions || prev.tags
    }));
  }, [project]);

  const handleInputChange = (field: keyof Metadata, value: any) => {
    setMetadata(prev => ({ ...prev, [field]: value }));
    setHasChanges(true);
  };

  const handleAddTag = () => {
    if (newTag.trim() && !metadata.tags.includes(newTag.trim())) {
      setMetadata(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag("");
      setHasChanges(true);
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setMetadata(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    // In a real app, this would save to the project store
    console.log("Saving metadata:", metadata);
    setHasChanges(false);
  };

  const handleReset = () => {
    setMetadata({
      title: project.name,
      artist: "",
      album: "",
      genre: "",
      year: new Date().getFullYear().toString(),
      bpm: project.analysis?.bpm || 120,
      key: project.analysis?.key || "",
      description: project.refinement?.enhancedPrompt || "",
      tags: project.refinement?.emotions || []
    });
    setHasChanges(false);
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Tag className="w-5 h-5" />
          Metadata
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Title */}
        <div className="space-y-2">
          <Label htmlFor="title" className="flex items-center gap-2">
            <Music className="w-4 h-4" />
            Title
          </Label>
          <Input
            id="title"
            value={metadata.title}
            onChange={(e) => handleInputChange("title", e.target.value)}
            placeholder="Song title"
          />
        </div>

        {/* Artist */}
        <div className="space-y-2">
          <Label htmlFor="artist" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            Artist
          </Label>
          <Input
            id="artist"
            value={metadata.artist}
            onChange={(e) => handleInputChange("artist", e.target.value)}
            placeholder="Artist name"
          />
        </div>

        {/* Album */}
        <div className="space-y-2">
          <Label htmlFor="album" className="flex items-center gap-2">
            <Disc className="w-4 h-4" />
            Album
          </Label>
          <Input
            id="album"
            value={metadata.album}
            onChange={(e) => handleInputChange("album", e.target.value)}
            placeholder="Album name"
          />
        </div>

        {/* Genre and Year */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="genre">Genre</Label>
            <Select value={metadata.genre} onValueChange={(value) => handleInputChange("genre", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select genre" />
              </SelectTrigger>
              <SelectContent>
                {genres.map(genre => (
                  <SelectItem key={genre} value={genre}>{genre}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="year">Year</Label>
            <Input
              id="year"
              value={metadata.year}
              onChange={(e) => handleInputChange("year", e.target.value)}
              placeholder="2024"
            />
          </div>
        </div>

        {/* BPM and Key */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="bpm">BPM</Label>
            <Input
              id="bpm"
              type="number"
              value={metadata.bpm}
              onChange={(e) => handleInputChange("bpm", parseInt(e.target.value) || 120)}
              min="60"
              max="200"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="key">Key</Label>
            <Select value={metadata.key} onValueChange={(value) => handleInputChange("key", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select key" />
              </SelectTrigger>
              <SelectContent>
                {keys.map(key => (
                  <SelectItem key={key} value={key}>{key}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Separator />

        {/* Description */}
        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={metadata.description}
            onChange={(e) => handleInputChange("description", e.target.value)}
            placeholder="Song description or lyrics excerpt"
            rows={3}
          />
        </div>

        {/* Tags */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <Hash className="w-4 h-4" />
            Tags
          </Label>
          <div className="flex gap-2">
            <Input
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              placeholder="Add tag"
              onKeyPress={(e) => e.key === "Enter" && handleAddTag()}
            />
            <Button size="sm" onClick={handleAddTag} disabled={!newTag.trim()}>
              Add
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {metadata.tags.map(tag => (
              <Badge
                key={tag}
                variant="secondary"
                className="cursor-pointer"
                onClick={() => handleRemoveTag(tag)}
              >
                {tag} ×
              </Badge>
            ))}
          </div>
        </div>

        {/* Cover Art */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <ImageIcon className="w-4 h-4" />
            Cover Art
          </Label>
          <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
            <ImageIcon className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              Drop image here or click to browse
            </p>
            <Button size="sm" variant="outline" className="mt-2">
              Choose File
            </Button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-4">
          <Button
            size="sm"
            variant="outline"
            onClick={handleReset}
            className="flex-1 gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Reset
          </Button>
          <Button
            size="sm"
            onClick={handleSave}
            disabled={!hasChanges}
            className="flex-1 gap-2"
          >
            <Save className="w-4 h-4" />
            Save
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export { MetadataEditor };