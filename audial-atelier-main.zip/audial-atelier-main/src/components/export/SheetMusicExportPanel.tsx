import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  FileText,
  Download,
  Eye,
  Music,
  File,
  Settings,
  Hash,
  Type
} from "lucide-react";

interface Project {
  id: string;
  name: string;
  tracks: any[];
  selectedVersionId?: string;
}

interface SheetMusicExportPanelProps {
  project: Project;
  onExport: (data: any) => void;
  onPreview: (data: any) => void;
  isExporting: boolean;
}

const SheetMusicExportPanel = ({ project, onExport, onPreview, isExporting }: SheetMusicExportPanelProps) => {
  const [format, setFormat] = useState<"pdf" | "musicxml" | "midi">("pdf");
  const [layout, setLayout] = useState<"standard" | "compact" | "landscape">("standard");
  const [transposition, setTransposition] = useState("0");
  const [includeLyrics, setIncludeLyrics] = useState(true);
  const [includeChordSymbols, setIncludeChordSymbols] = useState(true);
  const [pageSize, setPageSize] = useState<"a4" | "letter" | "legal">("a4");

  const formatOptions = [
    {
      value: "pdf" as const,
      label: "PDF",
      description: "Printable sheet music",
      icon: FileText
    },
    {
      value: "musicxml" as const,
      label: "MusicXML",
      description: "Editable in notation software",
      icon: File
    },
    {
      value: "midi" as const,
      label: "MIDI",
      description: "For playback and sequencing",
      icon: Music
    }
  ];

  const layoutOptions = [
    {
      value: "standard" as const,
      label: "Standard",
      description: "Traditional music notation layout"
    },
    {
      value: "compact" as const,
      label: "Compact",
      description: "Space-efficient layout"
    },
    {
      value: "landscape" as const,
      label: "Landscape",
      description: "Wide format for multiple systems"
    }
  ];

  const handleExport = () => {
    const exportData = {
      type: "sheet-music",
      format,
      layout,
      transposition: parseInt(transposition),
      includeLyrics,
      includeChordSymbols,
      pageSize,
      fileName: `${project.name.replace(/\s+/g, '_')}_sheet_music_${format}`
    };

    onExport(exportData);
  };

  const handlePreview = () => {
    const previewData = {
      type: "sheet-music",
      format,
      layout,
      transposition: parseInt(transposition),
      includeLyrics,
      includeChordSymbols,
      pageSize,
      fileName: `${project.name.replace(/\s+/g, '_')}_sheet_music_${format}`
    };

    onPreview(previewData);
  };

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Sheet Music Export
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Export your composition as printable or editable sheet music
          </p>
        </div>

        {/* Format Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Format</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              {formatOptions.map(option => {
                const Icon = option.icon;
                return (
                  <div
                    key={option.value}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      format === option.value ? "border-primary bg-primary/5" : "border-border hover:border-accent"
                    }`}
                    onClick={() => setFormat(option.value)}
                  >
                    <Icon className="w-8 h-8 mx-auto mb-2 text-primary" />
                    <div className="text-center">
                      <div className="font-medium">{option.label}</div>
                      <div className="text-xs text-muted-foreground mt-1">{option.description}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Layout Options */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Layout</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              {layoutOptions.map(option => (
                <div
                  key={option.value}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    layout === option.value ? "border-primary bg-primary/5" : "border-border hover:border-accent"
                  }`}
                  onClick={() => setLayout(option.value)}
                >
                  <div className="text-center">
                    <div className="font-medium">{option.label}</div>
                    <div className="text-xs text-muted-foreground mt-1">{option.description}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Page Size */}
            <div className="pt-4 border-t">
              <label className="text-sm font-medium">Page Size</label>
              <Select value={pageSize} onValueChange={(value: "a4" | "letter" | "legal") => setPageSize(value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="a4">A4 (210×297mm)</SelectItem>
                  <SelectItem value="letter">Letter (8.5×11")</SelectItem>
                  <SelectItem value="legal">Legal (8.5×14")</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Musical Options */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Musical Options</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Transposition */}
            <div>
              <label className="text-sm font-medium">Transposition (semitones)</label>
              <Select value={transposition} onValueChange={setTransposition}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="-12">-12 (octave down)</SelectItem>
                  <SelectItem value="-7">-7</SelectItem>
                  <SelectItem value="-5">-5</SelectItem>
                  <SelectItem value="-2">-2</SelectItem>
                  <SelectItem value="0">0 (original key)</SelectItem>
                  <SelectItem value="2">+2</SelectItem>
                  <SelectItem value="5">+5</SelectItem>
                  <SelectItem value="7">+7</SelectItem>
                  <SelectItem value="12">+12 (octave up)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Include Options */}
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-lyrics"
                  checked={includeLyrics}
                  onCheckedChange={(checked) => setIncludeLyrics(checked as boolean)}
                />
                <label htmlFor="include-lyrics" className="text-sm font-medium">
                  Include lyrics
                </label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-chords"
                  checked={includeChordSymbols}
                  onCheckedChange={(checked) => setIncludeChordSymbols(checked as boolean)}
                />
                <label htmlFor="include-chords" className="text-sm font-medium">
                  Include chord symbols
                </label>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Export Actions */}
        <div className="flex gap-3">
          <Button
            onClick={handlePreview}
            variant="outline"
            className="flex-1 gap-2"
          >
            <Eye className="w-4 h-4" />
            Preview
          </Button>
          <Button
            onClick={handleExport}
            disabled={isExporting}
            className="flex-1 gap-2"
          >
            <Download className="w-4 h-4" />
            {isExporting ? "Exporting..." : "Export Sheet Music"}
          </Button>
        </div>

        {/* File Info */}
        <Card className="bg-muted/50">
          <CardContent className="pt-4">
            <div className="text-sm space-y-1">
              <div className="flex justify-between">
                <span>Format:</span>
                <Badge variant="secondary">{format.toUpperCase()}</Badge>
              </div>
              <div className="flex justify-between">
                <span>Layout:</span>
                <Badge variant="secondary">{layout}</Badge>
              </div>
              <div className="flex justify-between">
                <span>Transposition:</span>
                <Badge variant="secondary">{transposition} semitones</Badge>
              </div>
              <div className="flex justify-between">
                <span>Page Size:</span>
                <Badge variant="secondary">{pageSize.toUpperCase()}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </ScrollArea>
  );
};

export { SheetMusicExportPanel };