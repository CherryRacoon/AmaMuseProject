
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { ScoreDimension } from "@/types/rating";
import { HelpCircle } from "lucide-react";

interface ScoreBarsProps {
  structure: ScoreDimension;
  appeal: ScoreDimension;
  novelty: ScoreDimension;
  potential: ScoreDimension;
}

const getScoreColor = (score: number) => {
  if (score >= 8.5) return "bg-green-500";
  if (score >= 7.0) return "bg-yellow-500";
  if (score >= 5.5) return "bg-orange-500";
  return "bg-red-500";
};

const ScoreBar = ({ label, dimension }: { label: string; dimension: ScoreDimension }) => (
  <div className="space-y-2">
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <h4 className="font-semibold">{label}</h4>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger>
              <HelpCircle className="w-4 h-4 text-muted-foreground" />
            </TooltipTrigger>
            <TooltipContent>
              <p>{dimension.explanation}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      <span className="font-bold text-lg">{dimension.score.toFixed(1)}</span>
    </div>
    <Progress value={dimension.score * 10} indicatorClassName={getScoreColor(dimension.score)} />
  </div>
);

export const ScoreBars = ({ structure, appeal, novelty, potential }: ScoreBarsProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>AMEI Score Dimensions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <ScoreBar label="Structure" dimension={structure} />
        <ScoreBar label="Appeal" dimension={appeal} />
        <ScoreBar label="Novelty" dimension={novelty} />
        <ScoreBar label="Potential" dimension={potential} />
      </CardContent>
    </Card>
  );
};
