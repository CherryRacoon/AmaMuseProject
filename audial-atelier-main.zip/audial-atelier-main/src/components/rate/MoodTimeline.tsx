
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ResponsiveContainer, LineChart, CartesianGrid, XAxis, YAxis, Tooltip, Line, Legend } from 'recharts';
import { CyaniteFeatures } from "@/types/rating";

interface MoodTimelineProps {
  cyanite: CyaniteFeatures;
}

export const MoodTimeline = ({ cyanite }: MoodTimelineProps) => {
  const moodData = cyanite.moodOverTime.map(m => ({ time: m.time, mood: m.mood }));
  const movementData = cyanite.movement.map(m => ({ time: m.time, movement: m.value * 10 })); // Scale for visibility

  // A simple way to map string moods to numeric values for charting
  const moodMap = Array.from(new Set(moodData.map(m => m.mood))).reduce((acc, mood, i) => {
    acc[mood] = i + 1;
    return acc;
  }, {} as Record<string, number>);

  interface ChartData {
    time: number;
    moodValue?: number | null;
    movement?: number;
}

// ...

  const chartData: ChartData[] = moodData.map(m => ({
      time: m.time,
      moodValue: moodMap[m.mood]
  }));

  cyanite.movement.forEach(m => {
      const existing = chartData.find(d => d.time === m.time);
      if(existing) {
          existing.movement = m.value * 10;
      } else {
          chartData.push({time: m.time, movement: m.value * 10, moodValue: null});
      }
  });
  
  chartData.sort((a,b) => a.time - b.time);


  return (
    <Card>
      <CardHeader>
        <CardTitle>Mood & Movement Timeline</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" label={{ value: 'Time (s)', position: 'insideBottom', offset: -5 }} />
            <YAxis yAxisId="left" label={{ value: 'Movement', angle: -90, position: 'insideLeft' }} />
            <YAxis yAxisId="right" orientation="right" label={{ value: 'Mood', angle: -90, position: 'insideRight' }} />
            <Tooltip />
            <Legend />
            <Line yAxisId="left" type="monotone" dataKey="movement" stroke="#8884d8" name="Movement" />
            <Line yAxisId="right" type="step" dataKey="moodValue" stroke="#82ca9d" name="Mood" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
