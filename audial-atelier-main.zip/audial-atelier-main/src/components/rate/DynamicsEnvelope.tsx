
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ResponsiveContainer, AreaChart, CartesianGrid, XAxis, YAxis, Tooltip, Area, Legend } from 'recharts';
import { SoundStatFeatures } from "@/types/rating";

interface DynamicsEnvelopeProps {
  soundstat: SoundStatFeatures;
}

export const DynamicsEnvelope = ({ soundstat }: DynamicsEnvelopeProps) => {
  // Mocking envelope data for visualization purposes
  const envelopeData = [
    { time: 0, loudness: -20 },
    { time: 15, loudness: -12 },
    { time: 30, loudness: -9 },
    { time: 45, loudness: -9.5 },
    { time: 60, loudness: -18 },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Loudness & Dynamics</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={envelopeData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" label={{ value: 'Time (s)', position: 'insideBottom', offset: -5 }} />
            <YAxis label={{ value: 'Loudness (LUFS)', angle: -90, position: 'insideLeft' }} />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="loudness" stroke="#8884d8" fill="#8884d8" />
          </AreaChart>
        </ResponsiveContainer>
        <div className="mt-4 text-center text-sm text-muted-foreground">
          Integrated Loudness: {soundstat.loudness_integrated.toFixed(1)} LUFS | Dynamic Range: {soundstat.dynamic_range.toFixed(1)}
        </div>
      </CardContent>
    </Card>
  );
};
