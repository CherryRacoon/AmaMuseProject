
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from 'recharts';
import { SpotifyFeatures } from "@/types/rating";

interface PopularityRadarProps {
  spotify: Partial<SpotifyFeatures>;
}

const POPULAR_BASELINE = {
    danceability: 0.65,
    energy: 0.7,
    valence: 0.5,
    tempo: 120,
    loudness: -8,
};

export const PopularityRadar = ({ spotify }: PopularityRadarProps) => {
  const data = [
    { subject: 'Danceability', A: spotify.danceability, B: POPULAR_BASELINE.danceability, fullMark: 1 },
    { subject: 'Energy', A: spotify.energy, B: POPULAR_BASELINE.energy, fullMark: 1 },
    { subject: 'Valence', A: spotify.valence, B: POPULAR_BASELINE.valence, fullMark: 1 },
    { subject: 'Tempo', A: spotify.tempo ? (spotify.tempo - 60) / 100 : 0.5, B: (POPULAR_BASELINE.tempo - 60) / 100, fullMark: 1 },
    { subject: 'Loudness', A: spotify.loudness ? (spotify.loudness + 20) / 20 : 0.5, B: (POPULAR_BASELINE.loudness + 20) / 20, fullMark: 1 },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Comparison to Popular Baseline</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
            <PolarGrid />
            <PolarAngleAxis dataKey="subject" />
            <PolarRadiusAxis />
            <Radar name="This Song" dataKey="A" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
            <Radar name="Popular Baseline" dataKey="B" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
            <Legend />
          </RadarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
