
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RateReport, ScoreDimension } from "@/types/rating";
import { Lightbulb } from "lucide-react";

interface ConclusionCardProps {
  report: RateReport;
}

const getThresholdVariant = (threshold: RateReport['threshold']) => {
    switch (threshold) {
        case 'Publish-ready': return 'success';
        case 'Good but polish hooks': return 'default';
        case 'OK but not memorable': return 'secondary';
        case 'Rework structure/mix': return 'destructive';
    }
};

const DimensionTips = ({ label, dimension }: { label: string; dimension: ScoreDimension }) => (
    <div>
        <h4 className="font-semibold">{label}</h4>
        <ul className="list-disc pl-5 mt-1 text-sm text-muted-foreground">
            {dimension.tips.map((tip, i) => <li key={i}>{tip}</li>)}
        </ul>
    </div>
);

export const ConclusionCard = ({ report }: ConclusionCardProps) => {
  return (
    <Card className="bg-card/80">
      <CardHeader>
        <div className="flex items-center justify-between">
            <CardTitle>Final Analysis & Recommendations</CardTitle>
            <Badge variant={getThresholdVariant(report.threshold)}>{report.threshold}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
            <p className="text-muted-foreground">Overall AMEI Score</p>
            <p className="text-6xl font-bold">{report.ameiScore.toFixed(1)}</p>
            <p className="mt-2 text-lg">{report.conclusion}</p>
        </div>

        <div className="p-4 bg-muted/50 rounded-lg space-y-4">
            <div className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-primary" />
                <h3 className="text-lg font-semibold">What this means & How to improve</h3>
            </div>
            <DimensionTips label="Structure" dimension={report.structure} />
            <DimensionTips label="Appeal" dimension={report.appeal} />
            <DimensionTips label="Novelty" dimension={report.novelty} />
            <DimensionTips label="Potential" dimension={report.potential} />
        </div>
      </CardContent>
    </Card>
  );
};
