import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GeminiConfig } from "@/components/api-config/GeminiConfig";
import { LyriaConfig } from "@/components/api-config/LyriaConfig";
import { SunoConfig } from "@/components/api-config/SunoConfig";
import { Sparkles, Cloud, Music } from "lucide-react";

export const ApiSettings = () => {
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-foreground mb-2">API Configuration</h2>
        <p className="text-muted-foreground">
          Configure and test your API connections for AI-powered music generation
        </p>
      </div>

      <Tabs defaultValue="gemini" className="w-full">
        <TabsList className="grid w-full grid-cols-3 h-auto p-1">
          <TabsTrigger value="gemini" className="gap-2 py-3">
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">Gemini API</span>
          </TabsTrigger>
          <TabsTrigger value="lyria" className="gap-2 py-3">
            <Cloud className="w-4 h-4" />
            <span className="hidden sm:inline">Lyria Vertex AI</span>
          </TabsTrigger>
          <TabsTrigger value="suno" className="gap-2 py-3">
            <Music className="w-4 h-4" />
            <span className="hidden sm:inline">Suno API</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="gemini" className="mt-6">
          <GeminiConfig />
        </TabsContent>

        <TabsContent value="lyria" className="mt-6">
          <LyriaConfig />
        </TabsContent>

        <TabsContent value="suno" className="mt-6">
          <SunoConfig />
        </TabsContent>
      </Tabs>
    </div>
  );
};
