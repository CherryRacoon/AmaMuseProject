import { useEffect, useRef, useState } from "react";
import WaveSurfer from "wavesurfer.js";
// RegionsPlugin path for wavesurfer v7
import RegionsPlugin from "wavesurfer.js/dist/plugins/regions.esm.js";
import { Button } from "@/components/ui/button";
import { Play, Pause, RotateCcw } from "lucide-react";
import { useDebugLog } from "@/hooks/useDebugLog";

interface AudioWaveformProps {
  audioBlob?: Blob;
  audioUrl?: string;
  height?: number;
  className?: string;
}

export const AudioWaveform = ({ 
  audioBlob, 
  audioUrl, 
  height = 80,
  className = "" 
}: AudioWaveformProps) => {
  const { addLog } = useDebugLog();
  const waveformRef = useRef<HTMLDivElement>(null);
  const wavesurferRef = useRef<WaveSurfer | null>(null);
  const createdUrlRef = useRef<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<number>(0);

  useEffect(() => {
    if (!waveformRef.current) return;

    // Initialize WaveSurfer with Regions plugin enabled so users can select segments
    const wavesurfer = WaveSurfer.create({
      container: waveformRef.current,
      waveColor: 'hsl(var(--muted-foreground))',
      progressColor: 'hsl(var(--primary))',
      cursorColor: 'hsl(var(--primary))',
      barWidth: 2,
      barRadius: 3,
      cursorWidth: 1,
      height: height,
      barGap: 2,
      normalize: true,
      backend: 'WebAudio',
      plugins: [RegionsPlugin.create()],
    });

    wavesurferRef.current = wavesurfer;

    // Event listeners
    wavesurfer.on('ready', () => {
      const audioDuration = wavesurfer.getDuration();
      setDuration(audioDuration);
      addLog("INFO", "System", "Waveform Ready", "Audio waveform loaded", {
        duration: audioDuration
      });
    });

    wavesurfer.on('play', () => setIsPlaying(true));
    wavesurfer.on('pause', () => setIsPlaying(false));
    wavesurfer.on('finish', () => setIsPlaying(false));
    
    wavesurfer.on('audioprocess', (time) => {
      setCurrentTime(time);
    });

    // Regions events
    (wavesurfer as any).on('region-created', (region: any) => {
      setRegionStart(region.start);
      setRegionEnd(region.end);
    });

    (wavesurfer as any).on('region-updated', (region: any) => {
      setRegionStart(region.start);
      setRegionEnd(region.end);
    });

    (wavesurfer as any).on('region-removed', () => {
      setRegionStart(null);
      setRegionEnd(null);
    });

    wavesurfer.on('error', (error) => {
      addLog("ERROR", "System", "Waveform Error", "Failed to load waveform", { error });
    });

    // Load audio
    if (audioBlob) {
      const url = URL.createObjectURL(audioBlob);
      createdUrlRef.current = url;
      wavesurfer.load(url);
    } else if (audioUrl) {
      wavesurfer.load(audioUrl);
    }

    return () => {
      wavesurfer.destroy();
      if (createdUrlRef.current) {
        try {
          URL.revokeObjectURL(createdUrlRef.current);
        } catch (e) {
          // ignore
        }
        createdUrlRef.current = null;
      }
    };
  }, [audioBlob, audioUrl, height, addLog]);

  // Local region state
  const [regionStart, setRegionStart] = useState<number | null>(null);
  const [regionEnd, setRegionEnd] = useState<number | null>(null);

  const handlePlayPause = () => {
    if (wavesurferRef.current) {
      wavesurferRef.current.playPause();
    }
  };

  const handleRestart = () => {
    if (wavesurferRef.current) {
      wavesurferRef.current.seekTo(0);
      setCurrentTime(0);
    }
  };

  const handleClearRegion = () => {
    if (!wavesurferRef.current) return;
    const regions = (wavesurferRef.current as any).regions.list || {};
    Object.values(regions).forEach((r: any) => r.remove());
    setRegionStart(null);
    setRegionEnd(null);
  };

  const handleUseSelection = () => {
    if (regionStart == null || regionEnd == null) return;
    if (typeof (AudioWaveform as any).onUseSelection === 'function') {
      // noop - kept for compatibility
    }
    // Trigger external callback if provided via DOM event
    const event = new CustomEvent('waveform-selection', { detail: { start: regionStart, end: regionEnd } });
    window.dispatchEvent(event);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`space-y-2 ${className}`}>
      <div ref={waveformRef} className="w-full rounded-lg bg-muted/30" />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={handlePlayPause}
            className="h-8 w-8 p-0"
          >
            {isPlaying ? (
              <Pause className="w-4 h-4" />
            ) : (
              <Play className="w-4 h-4" />
            )}
          </Button>
          
          <Button
            size="sm"
            variant="ghost"
            onClick={handleRestart}
            className="h-8 w-8 p-0"
          >
            <RotateCcw className="w-3 h-3" />
          </Button>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-xs text-muted-foreground">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handleClearRegion} className="text-xs text-muted-foreground px-2 py-1 rounded-md hover:bg-secondary">Clear</button>
            <button onClick={handleUseSelection} className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded-md">Use Selection</button>
          </div>
        </div>
      </div>
      {regionStart != null && regionEnd != null && (
        <div className="text-xs text-muted-foreground">Selection: {formatTime(regionStart)} — {formatTime(regionEnd)}</div>
      )}
    </div>
  );
};
