import { useState, useEffect } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Sparkles, Loader2, CopyIcon } from "lucide-react";
import { useProjectStore } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { useApiStore } from "@/stores/useApiStore";
import { toast } from "sonner";

interface LyricsEditorProps {
  projectId: string;
}

export const LyricsEditor = ({ projectId }: LyricsEditorProps) => {
  const { currentProject, updateLyrics } = useProjectStore();
  const { addLog } = useDebugLog();
  const [isLoading, setIsLoading] = useState(false);
  
  // Get Gemini API configuration from the API store
  const apiKey = useApiStore((s) => s.geminiApiKey);
  const model = useApiStore((s) => s.geminiModel);
  const temperature = useApiStore((s) => s.geminiTemperature);
  const maxTokens = useApiStore((s) => s.geminiMaxOutputTokens);
  const topP = useApiStore((s) => s.geminiTopP);
  
  const [content, setContent] = useState(currentProject?.lyrics?.content || "");

  useEffect(() => {
    if (content && projectId) {
      // Check if content has actually changed to prevent unnecessary updates
      const currentLyrics = currentProject?.lyrics;
      if (currentLyrics?.content !== content) {
        // Basic structure tagging for type compliance
        const lines = content.split("\n").filter(l => l.trim());
        const structure = lines.map(line => ({ type: "verse" as const, text: line }));
        updateLyrics(projectId, { content, structure });

        addLog("DEBUG", "System", "Lyrics Input", "Lyrics updated", {
          lineCount: lines.length,
          characterCount: content.length,
        });
      }
    }
  }, [content, currentProject?.lyrics, updateLyrics, addLog, projectId]);

  const generateWithGemini = async () => {
    if (!apiKey) {
      toast.error("Please configure your Gemini API key first");
      return;
    }

    setIsLoading(true);
    addLog("INFO", "Gemini", "Lyric Generation", "Requesting lyric generation");

    const mood = currentProject?.textPrompt?.mood;
    const moodString = Array.isArray(mood) ? mood[0] : mood;
    const userPrompt = currentProject?.textPrompt?.text || "";

    // Build assistant prompt per product requirement
    const assistantPrompt = `You are a lyric assistant helping users create songs with SUNO AI.
Based on the following user input, generate clear, singable, emotionally expressive lyrics.

User input: "${userPrompt.replace(/"/g, '\\"')}"
Genre: ${currentProject?.textPrompt?.genre || "Pop"}
Mood: ${moodString || "Uplifting"}
Style: ${currentProject?.textPrompt?.style || ""}

Instructions:
- Write lyrics in the language that they wrote their prompt
- The lyrics should have a clear structure with sections (#verse1, #chorus, etc.)
- Keep it poetic, align with the prompt's emotion but understandable
- Maintain rhythmic phrasing (2–4 lines per block)
- Output only the song text. No comments, no emojis`;

    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{
              role: "user",
              parts: [{ text: assistantPrompt }]
            }],
            generationConfig: {
              temperature,
              maxOutputTokens: maxTokens,
              topP,
            }
          })
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      const generatedText = data.candidates[0].content.parts[0].text;
      
      setContent(generatedText);
      addLog("INFO", "Gemini", "Lyrics Generated", "Successfully generated lyrics", {
        lyricsLength: generatedText.length,
      });

      toast.success("Lyrics generated successfully!");
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      addLog("ERROR", "Gemini", "Lyrics Generation Failed", errorMessage);
      toast.error(`Failed to generate lyrics: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  const copyFromPrompt = () => {
    const promptText = currentProject?.textPrompt?.text;
    if (promptText) {
      setContent((current) => {
        const newContent = current ? `${current}\n\n${promptText}` : promptText;
        toast.success("Text prompt content copied to lyrics");
        return newContent;
      });
    } else {
      toast.error("No text prompt content to copy");
    }
  };

  return (
    <div className="space-y-6">
      {/* Lyrics Textarea */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label>Lyrics</Label>
          <div className="flex gap-2">
            <Button
              onClick={copyFromPrompt}
              variant="outline"
              size="sm"
              className="gap-1"
            >
              <CopyIcon className="w-3 h-3" />
              Copy from Text
            </Button>
            <Button
              onClick={generateWithGemini}
              variant="outline"
              size="sm"
              className="gap-2"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Generate with AI
                </>
              )}
            </Button>
          </div>
        </div>
        <Textarea
          placeholder="Write your lyrics here..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={12}
          className="resize-none font-mono text-sm"
        />
        <div className="space-y-1">
          <p className="text-xs text-muted-foreground">
            {content.length} characters
          </p>
          <p className="text-xs text-muted-foreground">
            Tip: Use section labels like [Verse 1], [Chorus], [Bridge] to organize your lyrics.
            Aim for 2-4 lines per section with consistent rhyme and rhythm.
          </p>
        </div>
      </div>
    </div>
  );
};
