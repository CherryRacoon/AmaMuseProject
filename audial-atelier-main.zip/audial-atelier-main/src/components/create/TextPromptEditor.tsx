import { useState, useEffect } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useProjectStore } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";

interface TextPromptEditorProps {
  projectId: string;
}

const MOOD_KEYWORDS = [
  "Happy", "Sad", "Energetic", "Calm", "Dark", "Bright", "Melancholic", "Uplifting",
  "Mysterious", "Romantic", "Aggressive", "Peaceful"
];

const GENRES = [
  "Pop", "Rock", "Classical", "Jazz", "Electronic", "Hip Hop", "R&B", "Country",
  "Folk", "Blues", "Metal", "Ambient", "Lo-fi", "Indie"
];

const STYLES = [
  "Cinematic", "Lo-fi", "Upbeat", "Melancholic", "Epic", "Minimal", "Retro", "Modern"
];

export const TextPromptEditor = ({ projectId }: TextPromptEditorProps) => {
  const { currentProject, updateTextPrompt } = useProjectStore();
  const { addLog } = useDebugLog();
  
  const [text, setText] = useState(currentProject?.textPrompt?.text || "");
  const [selectedMoods, setSelectedMoods] = useState<string[]>(currentProject?.textPrompt?.mood || []);
  const [genre, setGenre] = useState(currentProject?.textPrompt?.genre || "");
  const [tempo, setTempo] = useState<"slow" | "medium" | "fast">(
    currentProject?.textPrompt?.tempo || "medium"
  );
  const [style, setStyle] = useState(currentProject?.textPrompt?.style || "");

  useEffect(() => {
    if ((text || selectedMoods.length > 0 || genre || style) && projectId) {
      // Check if any values have actually changed to prevent unnecessary updates
      const currentPrompt = currentProject?.textPrompt;
      const hasChanged =
        currentPrompt?.text !== text ||
        JSON.stringify(currentPrompt?.mood || []) !== JSON.stringify(selectedMoods) ||
        currentPrompt?.genre !== genre ||
        currentPrompt?.tempo !== tempo ||
        currentPrompt?.style !== style;

      if (hasChanged) {
        updateTextPrompt(projectId, {
          text,
          mood: selectedMoods,
          genre,
          tempo,
          style,
        });

        addLog("DEBUG", "System", "Text Input", "Prompt updated", {
          textLength: text.length,
          moods: selectedMoods,
          genre,
          tempo,
          style,
        });
      }
    }
  }, [text, selectedMoods, genre, tempo, style, currentProject?.textPrompt, updateTextPrompt, addLog, projectId]);

  const toggleMood = (mood: string) => {
    setSelectedMoods((prev) =>
      prev.includes(mood) ? prev.filter((m) => m !== mood) : [...prev, mood]
    );
  };

  return (
    <div className="space-y-6">
      {/* Text Prompt */}
      <div className="space-y-2">
        <Label>Describe your inspiration</Label>
        <Textarea
          placeholder="write down anything, your mood, your story, your grumpy words..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          maxLength={500}
          rows={6}
          className="resize-none"
        />
        <p className="text-xs text-muted-foreground text-right">
          {text.length} / 500 characters
        </p>
      </div>

      {/* Mood Keywords */}
      <div className="space-y-2">
        <Label>Mood Tags</Label>
        <div className="flex flex-wrap gap-2">
          {MOOD_KEYWORDS.map((mood) => (
            <Badge
              key={mood}
              variant={selectedMoods.includes(mood) ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => toggleMood(mood)}
            >
              {mood}
            </Badge>
          ))}
        </div>
      </div>

      {/* Genre */}
      <div className="space-y-2">
        <Label>Genre</Label>
        <Select value={genre} onValueChange={setGenre}>
          <SelectTrigger>
            <SelectValue placeholder="Select genre" />
          </SelectTrigger>
          <SelectContent>
            {GENRES.map((g) => (
              <SelectItem key={g} value={g}>
                {g}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Tempo */}
      <div className="space-y-2">
        <Label>Tempo</Label>
        <div className="grid grid-cols-3 gap-2">
          {(["slow", "medium", "fast"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTempo(t)}
              className={`px-4 py-2 rounded-md border transition-colors ${
                tempo === t
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background border-border hover:bg-secondary"
              }`}
            >
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Style */}
      <div className="space-y-2">
        <Label>Style Preset</Label>
        <Select value={style} onValueChange={setStyle}>
          <SelectTrigger>
            <SelectValue placeholder="Select style" />
          </SelectTrigger>
          <SelectContent>
            {STYLES.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};
