import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mic, Square, Upload, Youtube } from "lucide-react";
import { useProjectStore } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { AudioWaveform } from "./AudioWaveform";
import { toast } from "sonner";
import { saveAudioBlob, getAudioBlob } from "@/lib/storage/localAudioStore";

interface AudioRecorderProps {
  projectId: string;
}

export const AudioRecorder = ({ projectId }: AudioRecorderProps) => {
  const { updateAudioInput } = useProjectStore();
  const { addLog } = useDebugLog();
  const { getProject } = useProjectStore();
  const [isRecording, setIsRecording] = useState(false);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [duration, setDuration] = useState(0);
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedStart, setSelectedStart] = useState<number | null>(null);
  const [selectedEnd, setSelectedEnd] = useState<number | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Cleanup on unmount
  useEffect(() => {
    const handleWaveformSelection = (e: any) => {
      const detail = e.detail;
      if (detail && typeof detail.start === 'number' && typeof detail.end === 'number') {
        setSelectedStart(detail.start);
        setSelectedEnd(detail.end);
      }
    };

    window.addEventListener('waveform-selection', handleWaveformSelection as EventListener);

    // Load any persisted audio blob for preview
    (async () => {
      try {
        const p = getProject(projectId);
        const key = p?.audioInput?.blobKey;
        if (key) {
          const blob = await getAudioBlob(key);
          if (blob) {
            const url = URL.createObjectURL(blob);
            setPreviewUrl(url);
          }
        }
      } catch (e) {
        // ignore
      }
    })();

    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      window.removeEventListener('waveform-selection', handleWaveformSelection as EventListener);
      if (previewUrl) {
        try { URL.revokeObjectURL(previewUrl); } catch (e) {}
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      // Request microphone access
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        } 
      });
      
      streamRef.current = stream;
      audioChunksRef.current = [];

      // Determine best supported MIME type
      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : 'audio/mp4';

      const mediaRecorder = new MediaRecorder(stream, { 
        mimeType,
        audioBitsPerSecond: 128000
      });
      
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        setIsProcessing(true);
        
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        setRecordedBlob(blob);
        
        // Create file from blob
        const file = new File([blob], `recording-${Date.now()}.webm`, { type: mimeType });
        
          // Persist the recording blob to IndexedDB and update project with blobKey
          try {
            const key = await saveAudioBlob(blob);
            updateAudioInput(projectId, {
              type: "recording",
              blobKey: key,
              duration,
            });
            setPreviewUrl(URL.createObjectURL(blob));
          } catch (err) {
            // fallback to in-memory file
            updateAudioInput(projectId, {
              type: "recording",
              file,
              duration,
            });
          }

        addLog("INFO", "System", "Audio Recording", "Recording completed and processed", {
          duration,
          size: blob.size,
          mimeType,
          chunks: audioChunksRef.current.length
        });

        toast.success(`Recording saved! Duration: ${duration}s`);
        setIsProcessing(false);
        
        // Cleanup
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
          streamRef.current = null;
        }
      };

      mediaRecorder.onerror = (error) => {
        addLog("ERROR", "System", "MediaRecorder Error", "Recording error occurred", { error });
        toast.error("Recording error occurred");
        setIsRecording(false);
      };

      // Start recording with data chunks every second
      mediaRecorder.start(1000);
      setIsRecording(true);
      setDuration(0);

      // Timer for recording duration
      timerRef.current = setInterval(() => {
        setDuration((prev) => {
          const newDuration = prev + 1;
          // Auto-stop at 120 seconds (2 minutes)
          if (newDuration >= 120) {
            stopRecording();
            return 120;
          }
          return newDuration;
        });
      }, 1000);

      addLog("INFO", "System", "Audio Recording", "Recording started", { mimeType });
      toast.success("Recording started!");
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      addLog("ERROR", "System", "Audio Recording", "Failed to start recording", { 
        error: errorMessage,
        name: error instanceof Error ? error.name : "UnknownError"
      });
      
      if (errorMessage.includes("Permission denied")) {
        toast.error("Microphone access denied. Please allow microphone permissions.");
      } else if (errorMessage.includes("not found")) {
        toast.error("No microphone found. Please connect a microphone.");
      } else {
        toast.error("Failed to access microphone");
      }
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);

      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const validTypes = ['audio/mp3', 'audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/webm'];
      if (!validTypes.includes(file.type)) {
        toast.error("Invalid file type. Please upload MP3, WAV, or OGG files.");
        return;
      }

      // Validate file size (max 50MB)
      const maxSize = 50 * 1024 * 1024; // 50MB
      if (file.size > maxSize) {
        toast.error("File too large. Maximum size is 50MB.");
        return;
      }

      setUploadedFile(file);
      setRecordedBlob(null); // Clear any recorded audio

      addLog("INFO", "System", "Audio Upload", "File uploaded successfully", {
        name: file.name,
        size: file.size,
        type: file.type,
      });

      // store uploaded file in project, full file is available immediately
      updateAudioInput(projectId, {
        type: "upload",
        file,
      });

      toast.success(`Audio file "${file.name}" uploaded successfully!`);
    }
  };

  const handleYoutubeFetch = () => {
    if (!youtubeUrl) {
      toast.error("Please enter a YouTube URL");
      return;
    }

    addLog("INFO", "System", "YouTube Fetch", "Fetching audio from YouTube", { url: youtubeUrl });

    // Mock implementation
    // store youtube url, selection can be provided later
    updateAudioInput(projectId, {
      type: "youtube",
      url: youtubeUrl,
    });

    toast.success("YouTube URL saved. You can select a time range to use.");
  };

  return (
    <div className="space-y-6">
      {/* Recording Section */}
      <div className="space-y-4">
        <Label>Record Audio</Label>
        <div className="flex items-center gap-4">
          <Button
            onClick={isRecording ? stopRecording : startRecording}
            variant={isRecording ? "destructive" : "default"}
            className="gap-2"
          >
            {isRecording ? (
              <>
                <Square className="w-4 h-4" />
                Stop Recording
              </>
            ) : (
              <>
                <Mic className="w-4 h-4" />
                Start Recording
              </>
            )}
          </Button>
          {isRecording && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
              <span className="text-sm text-muted-foreground">
                {duration}s / 30s
              </span>
            </div>
          )}
        </div>

        {recordedBlob && !isProcessing && (
          <div className="p-4 rounded-lg bg-secondary/50 border border-border space-y-2">
            <Label className="text-sm text-muted-foreground">Recorded Audio</Label>
            <AudioWaveform audioBlob={recordedBlob} height={80} />

            <div className="flex items-center gap-2 mt-2">
              <div className="text-xs text-muted-foreground">
                Selected: {selectedStart != null ? `${selectedStart.toFixed(1)}s` : "-"} — {selectedEnd != null ? `${selectedEnd.toFixed(1)}s` : "-"}
              </div>
              <Button
                size="sm"
                onClick={async () => {
                  if (selectedStart == null || selectedEnd == null) {
                    toast.error("Please select a region on the waveform first.");
                    return;
                  }
                  if (!recordedBlob) return;
                  try {
                    const key = await saveAudioBlob(recordedBlob);
                    updateAudioInput(projectId, {
                      type: "recording",
                      blobKey: key,
                      start: selectedStart,
                      end: selectedEnd,
                    });
                    setPreviewUrl(URL.createObjectURL(recordedBlob));
                    toast.success("Selection saved as audio input");
                  } catch (e) {
                    toast.error("Failed to save audio locally");
                  }
                }}
              >
                Use Selection
              </Button>
            </div>
          </div>
        )}

        {isProcessing && (
          <div className="p-4 rounded-lg bg-secondary/50 border border-border">
            <p className="text-sm text-muted-foreground text-center">Processing recording...</p>
          </div>
        )}
      </div>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-2 text-muted-foreground">Or</span>
        </div>
      </div>

      {/* File Upload */}
      <div className="space-y-4">
        <Label>Upload Audio File</Label>
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <input
              ref={fileInputRef}
              type="file"
              accept="audio/mp3,audio/mpeg,audio/wav,audio/ogg,audio/webm"
              onChange={handleFileUpload}
              className="hidden"
            />
            <Button
              onClick={() => fileInputRef.current?.click()}
              variant="outline"
              className="gap-2"
              disabled={isRecording}
            >
              <Upload className="w-4 h-4" />
              Upload Audio File
            </Button>
            {uploadedFile && (
              <span className="text-sm text-muted-foreground">
                {uploadedFile.name}
              </span>
            )}
          </div>

          {uploadedFile && (
            <div className="p-4 rounded-lg bg-secondary/50 border border-border space-y-2">
              <Label className="text-sm text-muted-foreground">Uploaded Audio</Label>
              <AudioWaveform audioUrl={URL.createObjectURL(uploadedFile)} height={80} />

              <div className="flex items-center gap-2 mt-2">
                <div className="text-xs text-muted-foreground">
                  Selected: {selectedStart != null ? `${selectedStart.toFixed(1)}s` : "-"} — {selectedEnd != null ? `${selectedEnd.toFixed(1)}s` : "-"}
                </div>
                <Button
                  size="sm"
                  onClick={async () => {
                    if (selectedStart == null || selectedEnd == null) {
                      toast.error("Please select a region on the waveform first.");
                      return;
                    }
                    if (!uploadedFile) return;
                    try {
                      const key = await saveAudioBlob(uploadedFile);
                      updateAudioInput(projectId, {
                        type: "upload",
                        blobKey: key,
                        start: selectedStart,
                        end: selectedEnd,
                      });
                      setPreviewUrl(URL.createObjectURL(uploadedFile));
                      toast.success("Selection saved as audio input");
                    } catch (e) {
                      toast.error("Failed to save audio locally");
                    }
                  }}
                >
                  Use Selection
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-2 text-muted-foreground">Or</span>
        </div>
      </div>

      {/* YouTube URL */}
      <div className="space-y-4">
        <Label>YouTube URL</Label>
        <div className="flex gap-2">
          <Input
            placeholder="https://youtube.com/watch?v=..."
            value={youtubeUrl}
            onChange={(e) => setYoutubeUrl(e.target.value)}
          />
          <Button onClick={handleYoutubeFetch} variant="outline" className="gap-2">
            <Youtube className="w-4 h-4" />
            Fetch
          </Button>
        </div>
        {/* YouTube time selector */}
        <div className="flex items-center gap-2 mt-2">
          <Label className="text-sm">Start (s)</Label>
          <Input type="number" value={selectedStart ?? ''} onChange={(e) => setSelectedStart(e.target.value ? Number(e.target.value) : null)} className="w-24" />
          <Label className="text-sm">End (s)</Label>
          <Input type="number" value={selectedEnd ?? ''} onChange={(e) => setSelectedEnd(e.target.value ? Number(e.target.value) : null)} className="w-24" />
          <Button
            size="sm"
            onClick={() => {
              if (!youtubeUrl) return toast.error("Set a YouTube URL first");
              updateAudioInput(projectId, {
                type: "youtube",
                url: youtubeUrl,
                start: selectedStart ?? undefined,
                end: selectedEnd ?? undefined,
              });
              toast.success("YouTube selection saved");
            }}
          >
            Use Selection
          </Button>
        </div>
      </div>
    </div>
  );
};
