import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Music } from "lucide-react";
import { useProjectStore } from "@/stores/useProjectStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import { getAudioBlob } from "@/lib/storage/localAudioStore";
import { AudioWaveform } from "@/components/create/AudioWaveform";

interface PreviewPanelProps {
  projectId: string;
}

export const PreviewPanel = ({ projectId }: PreviewPanelProps) => {
  const { currentProject, updateAnalysis } = useProjectStore();
  const { addLog } = useDebugLog();
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const key = currentProject?.audioInput?.blobKey;
        if (key) {
          const blob = await getAudioBlob(key);
          if (mounted && blob) {
            setPreviewUrl(URL.createObjectURL(blob));
          }
        } else {
          setPreviewUrl(null);
        }
      } catch (e) {
        // ignore
      }
    })();
    return () => {
      mounted = false;
      if (previewUrl) {
        try { URL.revokeObjectURL(previewUrl); } catch (e) {}
      }
    };
  }, [currentProject?.audioInput?.blobKey]);

  const analyzeWithGemini = () => {
    addLog("INFO", "Gemini", "Audio Analysis", "Analyzing audio metadata");

    // Mock analysis
    setTimeout(() => {
      const mockMetadata = {
        key: "C Major",
        bpm: 120,
        mood: ["Uplifting", "Energetic", "Bright"],
        confidence: 0.87,
      };

      updateAnalysis(projectId, mockMetadata);
      
      addLog("INFO", "Gemini", "Audio Analysis", "Analysis complete", mockMetadata);
      toast.success("Audio analyzed!");
    }, 1500);
  };

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border h-fit sticky top-24">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Music className="w-5 h-5 text-accent" />
          Live Preview
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Audio Waveform */}
        {currentProject?.audioInput && (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Audio Waveform</p>
            {previewUrl ? (
              <AudioWaveform audioUrl={previewUrl} height={80} />
            ) : (
              <div className="h-24 bg-secondary/50 rounded-lg flex items-center justify-center">
                <div className="flex gap-1 items-end h-16">
                  {Array.from({ length: 40 }).map((_, i) => (
                    <div
                      key={i}
                      className="w-1 bg-primary rounded-full animate-pulse"
                      style={{
                        height: `${20 + Math.random() * 80}%`,
                        animationDelay: `${i * 50}ms`,
                      }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Metadata */}
        {currentProject?.analysisMetadata && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">Detected Metadata</p>
              <Badge variant="secondary">
                {Math.round((currentProject.analysisMetadata.confidence || 0) * 100)}% confidence
              </Badge>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {currentProject.analysisMetadata.key && (
                <div className="p-3 rounded-lg bg-secondary/50">
                  <p className="text-xs text-muted-foreground">Key</p>
                  <p className="text-sm font-medium">{currentProject.analysisMetadata.key}</p>
                </div>
              )}
              {currentProject.analysisMetadata.bpm && (
                <div className="p-3 rounded-lg bg-secondary/50">
                  <p className="text-xs text-muted-foreground">BPM</p>
                  <p className="text-sm font-medium">{currentProject.analysisMetadata.bpm}</p>
                </div>
              )}
            </div>

            {currentProject.analysisMetadata.mood && (
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground">Mood Tags</p>
                <div className="flex flex-wrap gap-2">
                  {currentProject.analysisMetadata.mood.map((mood, idx) => (
                    <Badge key={idx} variant="outline">
                      {mood}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Analysis Button */}
        {currentProject?.audioInput && !currentProject.analysisMetadata && (
          <Button
            onClick={analyzeWithGemini}
            variant="outline"
            className="w-full gap-2"
          >
            <Sparkles className="w-4 h-4" />
            Analyze with AI
          </Button>
        )}

        {/* Text Summary */}
        {currentProject?.textPrompt?.text && (
          <div className="p-4 rounded-lg bg-secondary/50 space-y-2">
            <p className="text-xs text-muted-foreground">Text Prompt</p>
            <p className="text-sm line-clamp-3">{currentProject.textPrompt.text}</p>
            <div className="flex flex-wrap gap-2 mt-2">
              {currentProject.textPrompt.mood && currentProject.textPrompt.mood.length > 0 && (
                <div className="flex items-center gap-2">
                  {currentProject.textPrompt.mood.map((m, idx) => (
                    <Badge key={`mood-${idx}`} variant="outline">{m}</Badge>
                  ))}
                </div>
              )}
              {currentProject.textPrompt.genre && (
                <Badge variant="secondary">{currentProject.textPrompt.genre}</Badge>
              )}
              {currentProject.textPrompt.tempo && (
                <Badge variant="outline">{currentProject.textPrompt.tempo}</Badge>
              )}
              {currentProject.textPrompt.style && (
                <Badge variant="outline">{currentProject.textPrompt.style}</Badge>
              )}
            </div>
          </div>
        )}

        {/* Lyrics Preview */}
        {currentProject?.lyrics?.content && (
          <div className="p-4 rounded-lg bg-secondary/50 space-y-2">
            <p className="text-xs text-muted-foreground">Lyrics Preview</p>
            <p className="text-sm font-mono line-clamp-4 whitespace-pre-wrap">
              {currentProject.lyrics.content}
            </p>
          </div>
        )}

        {/* Image Prompt */}
        {currentProject?.imageInspiration?.extractedPrompt && (
          <div className="p-4 rounded-lg bg-secondary/50 space-y-2">
            <p className="text-xs text-muted-foreground">Image-Derived Prompt</p>
            <p className="text-sm line-clamp-3">
              {currentProject.imageInspiration.extractedPrompt}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
