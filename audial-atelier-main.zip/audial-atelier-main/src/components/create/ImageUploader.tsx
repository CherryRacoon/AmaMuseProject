import { useState, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Upload, Sparkles, Info, ExternalLink } from "lucide-react";
import { useProjectStore } from "@/stores/useProjectStore";
import { useApiStore } from "@/stores/useApiStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { analyzeImageWithGemini } from "@/lib/providers/gemini";
import { toast } from "sonner";

interface ImageUploaderProps {
  projectId: string;
}

export const ImageUploader = ({ projectId }: ImageUploaderProps) => {
  const { currentProject, updateImageInspiration } = useProjectStore();
  const geminiApiKey = useApiStore((s) => s.geminiApiKey);
  const geminiModel = useApiStore((s) => s.geminiModel);
  const geminiTemperature = useApiStore((s) => s.geminiTemperature);
  const geminiTopP = useApiStore((s) => s.geminiTopP);
  const geminiMaxTokens = useApiStore((s) => s.geminiMaxOutputTokens);
  const { addLog } = useDebugLog();
  const [imagePreview, setImagePreview] = useState<string | null>(
    currentProject?.imageInspiration?.url || null
  );
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageAnalysis = currentProject?.imageInspiration?.analysis;
  const geminiConfigured = Boolean(geminiApiKey);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setImagePreview(url);

      addLog("INFO", "System", "Image Upload", "Image uploaded", {
        name: file.name,
        size: file.size,
        type: file.type,
      });

      updateImageInspiration(projectId, {
        file,
        url,
        analysis: undefined,
        extractedPrompt: undefined,
        colors: undefined,
        analyzedAt: undefined,
      });

      toast.success("Image uploaded! Click 'Analyze' to extract prompt.");
    }
  };

  const analyzeWithGemini = async () => {
    if (!imagePreview) {
      toast.error("Please upload an image first");
      return;
    }

    if (!geminiApiKey) {
      toast.error("Add your Gemini API key in API Settings before analyzing.");
      addLog("WARN", "Gemini", "Image Analysis", "Skipped analysis - Gemini API key missing");
      return;
    }

    setIsAnalyzing(true);
    addLog("INFO", "Gemini", "Image Analysis", "Analyzing image with Gemini Vision");

    try {
      let blob: Blob | null = null;
      let mimeType: string | undefined = currentProject?.imageInspiration?.file?.type;

      if (currentProject?.imageInspiration?.file) {
        blob = currentProject.imageInspiration.file;
      } else if (imagePreview) {
        const response = await fetch(imagePreview);
        blob = await response.blob();
        mimeType = response.headers.get("Content-Type") || blob.type || mimeType;
      }

      if (!blob) {
        throw new Error("Image data unavailable for analysis. Please re-upload the image.");
      }

      const analysis = await analyzeImageWithGemini(blob, {
        apiKey: geminiApiKey,
        model: geminiModel,
        temperature: geminiTemperature,
        topP: geminiTopP,
        maxOutputTokens: geminiMaxTokens,
        mimeType,
      });

      let storedFile = currentProject?.imageInspiration?.file;
      if (!storedFile) {
        if (blob instanceof File) {
          storedFile = blob;
        } else if (typeof File !== "undefined") {
          storedFile = new File([blob], "inspiration-image.png", { type: mimeType || "image/png" });
        }
      }

      updateImageInspiration(projectId, {
        file: storedFile,
        url: imagePreview,
        extractedPrompt: analysis.prompt,
        colors: analysis.colorPalette,
        analysis,
        analyzedAt: new Date().toISOString(),
      });

      addLog("INFO", "Gemini", "Image Analysis", "Analysis complete", {
        promptLength: analysis.prompt.length,
        colorsExtracted: analysis.colorPalette.length,
        emotionsDetected: analysis.emotions.length,
      });

      toast.success("Image analyzed! Gemini insights captured.");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unexpected error";
      addLog("ERROR", "Gemini", "Image Analysis", "Analysis failed", { error: message });
      toast.error(message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <div className="space-y-2">
        <Label>Upload Inspiration Image</Label>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png,image/jpeg,image/jpg,image/webp"
          onChange={handleImageUpload}
          className="hidden"
        />
        
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-border rounded-lg p-12 text-center cursor-pointer hover:bg-secondary/50 transition-colors"
        >
          {imagePreview ? (
            <img
              src={imagePreview}
              alt="Uploaded"
              className="max-h-64 mx-auto rounded-lg"
            />
          ) : (
            <div className="flex flex-col items-center gap-4">
              <Upload className="w-12 h-12 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Click to upload image</p>
                <p className="text-xs text-muted-foreground">PNG, JPG, WEBP up to 10MB</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Analysis Button */}
      {imagePreview && (
        <Button
          onClick={analyzeWithGemini}
          disabled={isAnalyzing}
          className="w-full gap-2"
        >
          <Sparkles className="w-4 h-4" />
          {isAnalyzing ? "Analyzing with AI..." : "Analyze with Gemini Vision"}
        </Button>
      )}

      {!geminiConfigured && (
        <Alert className="border-primary/40 bg-primary/10">
          <Info className="h-4 w-4 text-primary" />
          <AlertTitle className="text-sm font-semibold">Add your Gemini API key</AlertTitle>
          <AlertDescription className="space-y-2 text-sm">
            <p>
              Image understanding uses Google Gemini. Add your key in{" "}
              <Link to="/settings" className="font-medium underline underline-offset-4">
                API Settings
              </Link>{" "}
              from the sidebar before running an analysis.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild size="sm" variant="outline">
                <Link to="/settings">Open API Settings</Link>
              </Button>
              <Button
                asChild
                size="sm"
                variant="link"
                className="px-0 text-primary"
              >
                <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer">
                  Get a Gemini API key
                  <ExternalLink className="ml-1 h-3 w-3" />
                </a>
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Keys are stored locally on this device and never leave your browser.
            </p>
          </AlertDescription>
        </Alert>
      )}

      {/* Extracted Prompt */}
      {currentProject?.imageInspiration?.extractedPrompt && imageAnalysis && (
        <Card className="p-5 space-y-5 bg-secondary/40">
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground uppercase tracking-wide">Vision Summary</Label>
            <p className="text-sm leading-relaxed">{imageAnalysis.description}</p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {imageAnalysis.emotions.length > 0 && (
              <div>
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">Emotions</Label>
                <div className="mt-2 flex flex-wrap gap-2">
                  {imageAnalysis.emotions.map((emotion) => (
                    <Badge key={emotion} variant="secondary">
                      {emotion}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {imageAnalysis.style.length > 0 && (
              <div>
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">Style</Label>
                <div className="mt-2 flex flex-wrap gap-2">
                  {imageAnalysis.style.map((style) => (
                    <Badge key={style} variant="outline">
                      {style}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {imageAnalysis.timing && (
              <div>
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">Timing</Label>
                <div className="mt-2">
                  <Badge variant="outline">{imageAnalysis.timing}</Badge>
                </div>
              </div>
            )}
            {imageAnalysis.feeling && (
              <div>
                <Label className="text-xs text-muted-foreground uppercase tracking-wide">Feeling</Label>
                <p className="mt-2 text-sm leading-relaxed">{imageAnalysis.feeling}</p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground uppercase tracking-wide">Prompt Starter</Label>
            <p className="text-sm leading-relaxed">
              {currentProject.imageInspiration.extractedPrompt}
            </p>
          </div>

          {currentProject.imageInspiration.colors && currentProject.imageInspiration.colors.length > 0 && (
            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground uppercase tracking-wide">Color Palette</Label>
              <div className="flex flex-wrap gap-2">
                {currentProject.imageInspiration.colors.map((color) => (
                  <div
                    key={color}
                    className="flex h-12 w-12 flex-col items-center justify-center rounded-lg border border-border text-[10px] font-medium text-foreground/80"
                    style={{ backgroundColor: color }}
                    title={color}
                  >
                    <span className="px-1 py-0.5 backdrop-blur-sm bg-background/70 rounded">{color}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>
      )}

      {currentProject?.imageInspiration?.extractedPrompt && !imageAnalysis && (
        <Card className="p-4 bg-secondary/40">
          <Label className="text-xs text-muted-foreground uppercase tracking-wide">Prompt Starter</Label>
          <p className="mt-2 text-sm leading-relaxed">
            {currentProject.imageInspiration.extractedPrompt}
          </p>
        </Card>
      )}
    </div>
  );
};
