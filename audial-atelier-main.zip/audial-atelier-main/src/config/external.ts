export const SHEET_MUSIC_URL = "https://studio.klang.io/en/file?id=3b95aa48-5a8d-4570-bc40-5bbafa00a109";
