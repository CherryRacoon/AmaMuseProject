import { useNavigate, useLocation } from "react-router-dom";
import { useProjectStore } from "@/stores/useProjectStore";
import { useNavigationStore, NavigationMethod } from "@/stores/useNavigationStore";
import { useDebugLog } from "@/hooks/useDebugLog";
import { useState, useCallback } from "react";

export interface NavigationItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  route: string;
  shortcut: string;
  requiresProject: boolean;
  requiresInput?: boolean;
  requiresRefinedPrompt?: boolean;
  requiresGeneratedAudio?: boolean;
  requiresFinalizedAudio?: boolean;
  phase: string | null;
  description: string;
  badge?: string | null;
}

export const useNavigationGuard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentProject } = useProjectStore();
  const {
    hasUnsavedChanges,
    setCurrentRoute,
    addToHistory,
    setLastVisitedRoute,
  } = useNavigationStore();
  const { addLog } = useDebugLog();
  
  const [showUnsavedModal, setShowUnsavedModal] = useState(false);
  const [pendingRoute, setPendingRoute] = useState<string | null>(null);

  const canNavigateTo = useCallback((item: NavigationItem): [boolean, string | null] => {
    // Allow access to all pages for unrestricted navigation
    return [true, null];
  }, []);

  const requestNavigation = useCallback((
    targetRoute: string,
    method: NavigationMethod = "click",
    shortcut?: string,
    skipUnsavedCheck = false
  ) => {
    const startTime = Date.now();
    
    addLog("INFO", "System", "Navigation Attempt", `Attempting navigation to ${targetRoute}`, {
      fromRoute: location.pathname,
      toRoute: targetRoute,
      method,
      shortcut,
      hasActiveProject: !!currentProject,
      projectId: currentProject?.id,
      hasUnsavedChanges,
    });

    // Check for unsaved changes
    if (!skipUnsavedCheck && hasUnsavedChanges) {
      setPendingRoute(targetRoute);
      setShowUnsavedModal(true);
      
      addLog("WARN", "System", "Unsaved Changes Detected", "Showing confirmation modal", {
        targetRoute,
      });
      
      return;
    }

    // Perform navigation
    const navigationDuration = Date.now() - startTime;
    
    setCurrentRoute(targetRoute);
    addToHistory(targetRoute);
    setLastVisitedRoute(targetRoute);
    navigate(targetRoute);
    
    addLog("INFO", "System", "Navigation Completed", `Successfully navigated to ${targetRoute}`, {
      fromRoute: location.pathname,
      toRoute: targetRoute,
      method,
      navigationDuration,
      projectId: currentProject?.id,
    });
  }, [
    location.pathname,
    currentProject,
    hasUnsavedChanges,
    addLog,
    setCurrentRoute,
    addToHistory,
    setLastVisitedRoute,
    navigate,
  ]);

  const confirmNavigation = useCallback(() => {
    if (pendingRoute) {
      setShowUnsavedModal(false);
      
      addLog("INFO", "System", "Unsaved Changes Confirmed", "User chose to leave without saving", {
        targetRoute: pendingRoute,
      });
      
      requestNavigation(pendingRoute, "programmatic", undefined, true);
      setPendingRoute(null);
    }
  }, [pendingRoute, addLog, requestNavigation]);

  const cancelNavigation = useCallback(() => {
    if (pendingRoute) {
      addLog("INFO", "System", "Navigation Cancelled", "User chose to stay and save changes", {
        targetRoute: pendingRoute,
      });
    }
    
    setShowUnsavedModal(false);
    setPendingRoute(null);
  }, [pendingRoute, addLog]);

  return {
    canNavigateTo,
    requestNavigation,
    showUnsavedModal,
    confirmNavigation,
    cancelNavigation,
  };
};
