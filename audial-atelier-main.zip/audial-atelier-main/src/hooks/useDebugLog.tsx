import { create } from "zustand";

export type LogLevel = "DEBUG" | "INFO" | "WARN" | "ERROR";
export type LogSource = "ACE-Step" | "Gemini" | "Lyria" | "Suno" | "System" | "Network" | "AI";

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  source: LogSource;
  action: string;
  message: string;
  details?: Record<string, unknown>;
}

interface DebugLogStore {
  logs: LogEntry[];
  lastLogTime: number;
  addLog: (
    level: LogLevel,
    source: LogSource,
    action: string,
    message: string,
    details?: Record<string, unknown>
  ) => void;
  clearLogs: () => void;
}

export const useDebugLog = create<DebugLogStore>((set, get) => ({
  logs: [],
  lastLogTime: 0,
  addLog: (level, source, action, message, details) => {
    const now = Date.now();
    const state = get();

    // Throttle logging to prevent excessive updates (max 10 logs per second)
    if (now - state.lastLogTime < 100) {
      return;
    }

    set((state) => ({
      logs: [
        ...state.logs,
        {
          timestamp: new Date().toISOString(),
          level,
          source,
          action,
          message,
          details,
        },
      ].slice(-500), // Keep last 500 logs
      lastLogTime: now,
    }));
  },
  clearLogs: () => set({ logs: [], lastLogTime: 0 }),
}));
