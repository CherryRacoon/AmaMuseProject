import { useEffect } from "react";
import { useDebugLog } from "./useDebugLog";
import { NavigationItem } from "./useNavigationGuard";

interface UseKeyboardShortcutsProps {
  navigationItems: NavigationItem[];
  onNavigate: (route: string, shortcut: string) => void;
  onToggleDebug: () => void;
  onSave?: () => void;
}

export const useKeyboardShortcuts = ({
  navigationItems,
  onNavigate,
  onToggleDebug,
  onSave,
}: UseKeyboardShortcutsProps) => {
  const { addLog } = useDebugLog();

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const modKey = isMac ? event.metaKey : event.ctrlKey;

      // Ignore if user is typing in an input
      const target = event.target as HTMLElement;
      if (
        target.tagName === "INPUT" ||
        target.tagName === "TEXTAREA" ||
        target.isContentEditable
      ) {
        // Allow Ctrl+S even in inputs
        if (modKey && event.key === "s") {
          event.preventDefault();
          if (onSave) {
            addLog("INFO", "System", "Keyboard Shortcut", "Save triggered via Ctrl+S");
            onSave();
          }
        }
        return;
      }

      // Navigation shortcuts (Ctrl+1 through Ctrl+7)
      if (modKey && event.key >= "1" && event.key <= "7") {
        event.preventDefault();
        const index = parseInt(event.key) - 1;
        if (index < navigationItems.length) {
          const item = navigationItems[index];
          addLog("INFO", "System", "Keyboard Shortcut", `Navigation to ${item.label} via ${item.shortcut}`, {
            shortcut: item.shortcut,
            targetRoute: item.route,
          });
          onNavigate(item.route, item.shortcut);
        }
        return;
      }

      // Ctrl+D - Toggle debug console
      if (modKey && event.key === "d") {
        event.preventDefault();
        addLog("INFO", "System", "Keyboard Shortcut", "Debug console toggled via Ctrl+D");
        onToggleDebug();
        return;
      }

      // Ctrl+S - Save
      if (modKey && event.key === "s") {
        event.preventDefault();
        if (onSave) {
          addLog("INFO", "System", "Keyboard Shortcut", "Save triggered via Ctrl+S");
          onSave();
        }
        return;
      }

      // Escape - Close modals (handled by individual components)
      if (event.key === "Escape") {
        addLog("DEBUG", "System", "Keyboard Shortcut", "Escape key pressed");
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    
    addLog("DEBUG", "System", "Keyboard Shortcuts", "Keyboard shortcut listener registered");

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [navigationItems, onNavigate, onToggleDebug, onSave, addLog]);
};
