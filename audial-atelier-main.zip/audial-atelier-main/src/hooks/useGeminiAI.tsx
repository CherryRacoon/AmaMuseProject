import { useState } from "react";
import { useDebugLog } from "./useDebugLog";
import { toast } from "sonner";

interface EnhancePromptParams {
  prompt: string;
  mood?: string;
  genre?: string;
  tempo?: number;
  instruments?: string[];
  vocalsType?: string;
}

interface GenerateLyricsParams {
  theme?: string;
  mood?: string;
  genre?: string;
  style?: string;
  existingLyrics?: string;
  userInput?: string;
  artistRef?: string;
}

export const useGeminiAI = () => {
  const { addLog } = useDebugLog();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const enhancePrompt = async (params: EnhancePromptParams): Promise<string | null> => {
    setIsLoading(true);
    setError(null);

    try {
      const ENHANCE_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/enhance-prompt`;
      
      addLog("INFO", "Gemini", "Prompt Enhancement", "Requesting prompt enhancement", {
        promptLength: params.prompt.length,
        mood: params.mood,
        genre: params.genre
      });

      const response = await fetch(ENHANCE_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify(params),
      });

      if (!response.ok) {
        const errorData = await response.json();
        if (response.status === 429) {
          toast.error("Rate limit exceeded. Please try again in a moment.");
        } else if (response.status === 402) {
          toast.error("AI credits depleted. Please add credits to your workspace.");
        }
        throw new Error(errorData.error || "Failed to enhance prompt");
      }

      const data = await response.json();
      
      addLog("INFO", "Gemini", "Prompt Enhanced", "Successfully enhanced prompt", {
        originalLength: params.prompt.length,
        enhancedLength: data.enhancedPrompt.length,
        tokenUsage: data.tokenUsage
      });

      toast.success("Prompt enhanced successfully!");
      return data.enhancedPrompt;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      setError(errorMessage);
      
      addLog("ERROR", "Gemini", "Prompt Enhancement Failed", errorMessage, {
        prompt: params.prompt.substring(0, 100)
      });
      
      toast.error(`Failed to enhance prompt: ${errorMessage}`);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const generateLyrics = async (params: GenerateLyricsParams): Promise<string | null> => {
    setIsLoading(true);
    setError(null);

    try {
  const LYRICS_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-lyrics`;
      
      // Build assistant prompt per product requirement
      const assistantPrompt = `You are a lyric assistant helping users create songs with SUNO AI.
Based on the following user input, generate clear, singable, emotionally expressive lyrics.

User input: "${(params.userInput || "").replace(/"/g, '\\"')}"
Preferred style or artist: "${(params.artistRef || "").replace(/"/g, '\\"')}"(optional, based on user's wording)

Instructions:
- Write lyrics in the language that they wrote their prompt
- The lyrics should have a clear structure with sections (#verse1, #chorus, etc.). but also based on user's input, see if there's anything related to structure already, if not, feel free to output the best you can think of.
- Keep it poetic, align with the prompt's emotion but understandable.
- Maintain rhythmic phrasing (2–4 lines per block).
- Output only the song text. No comments, no emojis.`;

      addLog("INFO", "Gemini", "Lyrics Generation", "Requesting lyrics generation", {
        theme: params.theme,
        mood: params.mood,
        genre: params.genre
      });

      const response = await fetch(LYRICS_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ prompt: assistantPrompt, existingLyrics: params.existingLyrics }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        if (response.status === 429) {
          toast.error("Rate limit exceeded. Please try again in a moment.");
        } else if (response.status === 402) {
          toast.error("AI credits depleted. Please add credits to your workspace.");
        }
        throw new Error(errorData.error || "Failed to generate lyrics");
      }

      const data = await response.json();
      
      addLog("INFO", "Gemini", "Lyrics Generated", "Successfully generated lyrics", {
        lyricsLength: data.lyrics.length,
        tokenUsage: data.tokenUsage
      });

      toast.success("Lyrics generated successfully!");
      return data.lyrics;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      setError(errorMessage);
      
      addLog("ERROR", "Gemini", "Lyrics Generation Failed", errorMessage, {
        theme: params.theme,
        mood: params.mood,
        genre: params.genre,
        style: params.style,
        hasExistingLyrics: !!params.existingLyrics
      });
      
      toast.error(`Failed to generate lyrics: ${errorMessage}`);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    enhancePrompt,
    generateLyrics,
    isLoading,
    error,
  };
};
