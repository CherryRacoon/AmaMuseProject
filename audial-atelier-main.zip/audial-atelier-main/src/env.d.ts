interface ImportMetaEnv {
  readonly VITE_ACESTEP_API_URL: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}